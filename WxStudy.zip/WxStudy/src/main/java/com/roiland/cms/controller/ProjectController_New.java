package com.roiland.cms.controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.roiland.cms.constant.CMSConstant;
import com.roiland.cms.entity.ProjectNew;
import com.roiland.cms.entity.Project_state_new;
import com.roiland.cms.entity.TbTeam;
import com.roiland.cms.entity.TbUsers;
import com.roiland.cms.entity.User;
import com.roiland.cms.service.ProjectService_New;

/**
* <p>com.roiland.cms.controller.ProjectController.java</p>
* <p>Description:项目管理 </p>
* <p>Copyright: runlin groups 2017年2月24日</p>
* <p>Company: runlin </p>
* @author email: King.jin@runlin.com
* @date 2017年2月24日
* @version 1.0
*/
@Controller
public class ProjectController_New{
	
	/**注入Service对象**/
	@Resource
	private ProjectService_New projectService_New;
	
	/**
	 * 
	* <p>projectManagement</p>
	* <p>Description: 点击项目管理菜单，进入项目管理列表页面。在页面上方显示该人员的项目数量，页面中间显示所有的列表。</p>
	* <p>Copyright: runlin groups 2017-3-3</p>
	* <p>Company: runlin </p>
	* @author changrui.pan  email:changrui.pan@runlin.cn
	* @date 2018-06-01 
	* @version 1.0
	* @param mv
	* @param request
	* @return
	* @throws IOException
	 */
	@RequestMapping(value = "/projectManagement.html")
	public Object projectManagement(ModelAndView mv,HttpServletRequest request) throws IOException {
	
		List<ProjectNew> projects = projectService_New.getUserProjects();
		List<ProjectNew> projectlist = projectService_New.selectDistinctProjectNm();
		mv.addObject("projects", projects);
		mv.addObject("projectlist", projectlist);
		mv.setViewName("/view/projectManagement_New");// 返回指定页面(首页)	
		return mv;
	}

	/**
	 * 
	* <p>delProject</p>
	* <p>Description: 删除项目</p>
	* <p>Copyright: runlin groups 2017-3-3</p>
	* <p>Company: runlin </p>
	* @author huan.yu  email:huan.yu@runlin.cn
	* @date 2017-3-3 下午4:53:32
	* @version 1.0
	* @param request
	* @return
	* @throws UnsupportedEncodingException
	 */
	@ResponseBody
	@RequestMapping(value = "/delProject.do")
	public int delProject(HttpServletRequest request) {
		// 创建变量返回状态
		int id=Integer.valueOf(request.getParameter("id"));
		
		int result=projectService_New.delProject(id);
		return result;
	}
	/**
	 * 
	* <p>updProjectInfo</p>
	* <p>Description: 跳转至更新项目信息页面</p>
	* <p>Copyright: runlin groups 2017-3-5</p>
	* <p>Company: runlin </p>
	* @author changrui.pan  email:changrui.pan@runlin.cn
	* @date 2017-3-5 上午11:02:23
	* @version 1.0
	* @param request
	* @return
	* @throws IOException
	 */

	@RequestMapping(value = "/updProjectInfo_New.do", method = {RequestMethod.GET, RequestMethod.POST })
	public ModelAndView updProjectInfo(ModelAndView mv,
			@RequestParam(value="projectdepartment",required=false,defaultValue="0") int projectdepartment,
			@RequestParam(value="projecttem",required=false,defaultValue="0") int projecttem,
			@RequestParam(value="projectstate",required=false,defaultValue="0") int projectstate,
			@RequestParam(value="id",required=false,defaultValue="0") int id,
			@RequestParam(value="projectmanager",required=false,defaultValue="0") int projectmanager,
			@RequestParam(value="projectnumber",required=false,defaultValue="") String projectnumber,
			@RequestParam(value="projectname",required=false,defaultValue="") String projectname,
			@RequestParam(value="subprojectname",required=false,defaultValue="") String subprojectname,
			@RequestParam(value="subprojectcode",required=false,defaultValue="") String subprojectcode,
			@RequestParam(value="projectvalue",required=false,defaultValue="") String projectvalue,
			@RequestParam(value="purchaseamount",required=false,defaultValue="") String purchaseamount,
			@RequestParam(value="projectdate",required=false,defaultValue="") String projectdate) throws IOException {
			
		List<TbUsers> userList=null;
		List<Project_state_new> stateList = projectService_New.selectStateList();
	    List<TbTeam> teamList = projectService_New.selectTeamList(projectdepartment);
	    if(projecttem !=0){
	    	 userList = projectService_New.selectUserList(projecttem,projectdepartment);
	    }
	    List<ProjectNew> projectList = projectService_New.selectDistinctProjectNm();
	    List<ProjectNew> subProjectList = projectService_New.selectSubProjectList(projectname);
	    

	    mv.addObject("teamList", teamList);
	    mv.addObject("userList", userList);
	    mv.addObject("projectList", projectList);
	    mv.addObject("stateList", stateList);
	    mv.addObject("subProjectList", subProjectList);
	    mv.addObject("projectdepartment", projectdepartment);
	    mv.addObject("subprojectcode", subprojectcode);
	    mv.addObject("projecttem", projecttem);
	    mv.addObject("projectvalue", projectvalue);
	    mv.addObject("purchaseamount", purchaseamount);
	    mv.addObject("projectstate", projectstate);
	    mv.addObject("id", id);
	    mv.addObject("projectmanager", projectmanager);
	    mv.addObject("projectnumber", projectnumber);
	    mv.addObject("projectname", projectname);
	    mv.addObject("subprojectname", subprojectname);
	    mv.addObject("projectdate", projectdate);
	    mv.setViewName("admin/exportProject/editProject");
	     
		return mv;
	}
	/**
	 * 
	* <p>addProject_new</p>
	* <p>Description: 插入项目</p>
	* <p>Copyright: runlin groups 2017-3-3</p>
	* <p>Company: runlin </p>
	* @author changrui.pan  email:changrui.pan@runlin.cn
	* @date 2018-06-01 
	* @version 1.0
	* @param mv
	* @param request
	* @return
	* @throws IOException
	 */
	@ResponseBody
	@RequestMapping(value = "/addProject_new.do")
	public Object addProject_new(ModelAndView mv,HttpServletRequest request) throws IOException {
		User user = (User) request.getAttribute(CMSConstant.SESSIONUSER);
		
	    String id= request.getParameter("id");
		 int result=0;
		
		 String projectnumber = request.getParameter("projectnumber");
		
		String subprojectname = request.getParameter("subprojectname");
		String projectdate = request.getParameter("projectdate");
		int projectdepartment = Integer.valueOf(request.getParameter("projectdepartment"));
		int projecttem =Integer.valueOf(request.getParameter("projecttem"));
		int projectmanager = Integer.valueOf(request.getParameter("projectmanager"));
		int projectstate = Integer.valueOf(request.getParameter("projectstate"));
		float projectvalue = (request.getParameter("projectvalue")==""?0:Float.valueOf(request.getParameter("projectvalue")));
		float purchaseamount = (request.getParameter("purchaseamount")==""?0:Float.valueOf(request.getParameter("purchaseamount")));
		
		ProjectNew  pn = new ProjectNew();
		pn.setProjectnumber(projectnumber);
		pn.setSubprojectname(subprojectname);
		pn.setProjectdate(projectdate);
		pn.setProjectdepartment(projectdepartment);
		pn.setProjecttem(projecttem);
		pn.setProjectmanager(projectmanager);
		pn.setProjectstate(projectstate);
		pn.setProjectvalue(projectvalue);
		pn.setPurchaseamount(purchaseamount);
		pn.setAdduser(user.getTbUsers().getId());
		
		 if (id==null || Integer.valueOf(id)==0){
			 String addProjectname = request.getParameter("addProjectname");
			 pn.setAddProjectname(addProjectname);
		//int count = projectService_New.selectProjectNewById(id);
			 
		List<ProjectNew> pnList = projectService_New.selectProjectByName(pn);
	     int maxIndex = projectService_New.selectMaxIndex();
	     
	    if (pnList.size()>0){
	        pn.setProjectid(pnList.get(0).getProjectid());
	     }else{
	        pn.setProjectid(maxIndex+1);
	     }
	     
	     result = projectService_New.insertProjectNew(pn);
	
		}else{	
			String projectname = request.getParameter("projectname");
			pn.setProjectname(projectname);
			/*List<ProjectNew> pnList = projectService_New.selectProjectByName(pn);
			
			 if (pnList.size()>0){
				  pn.setProjectid(pnList.get(0).getProjectid());
			 }
			 */
			pn.setId(Integer.valueOf(id));
			result = projectService_New.uploadProjectNew(pn);
		}
		
		return result;
	}


	/**
	 * 
	* <p>selectTeamList</p>
	* <p>Description: 根据事业部取出部门</p>
	* <p>Copyright: runlin groups 2017-3-3</p>
	* <p>Company: runlin </p>
	* @author changrui.pan  email:changrui.pan@runlin.cn
	* @date 2018-06-01 
	* @version 1.0
	* @param mv
	* @param request
	* @return
	* @throws IOException
	 */
	@ResponseBody
	@RequestMapping(value = "/selectTeamList.do")
	public Object selectTeamList(ModelAndView mv,HttpServletRequest request) throws IOException {
		
		int projectdepartment = Integer.valueOf(request.getParameter("projectdepartment"));

		List<TbTeam> teamList = projectService_New.selectTeamList(projectdepartment);
		return teamList;
	}
	/**
	 * 
	 * <p>selectUsersList</p>
	 * <p>Description: 根据部门取人员</p>
	 * <p>Copyright: runlin groups 2017-3-3</p>
	 * <p>Company: runlin </p>
	 * @author changrui.pan  email:changrui.pan@runlin.cn
	 * @date 2018-06-01 
	 * @version 1.0
	 * @param mv
	 * @param request
	 * @return
	 * @throws IOException
	 */
	@ResponseBody
	@RequestMapping(value = "/selectUsersList.do")
	public Object selectUsersList(ModelAndView mv,HttpServletRequest request) throws IOException {
		
		int projecttem = Integer.valueOf(request.getParameter("projecttem"));
		int projectdepartment = Integer.valueOf(request.getParameter("projectdepartment"));
		
		 List<TbUsers> userList = projectService_New.selectUserList(projecttem,projectdepartment);
		return userList;
	}
	/**
	 * 
	 * <p>selectSubProjectList</p>
	 * <p>Description: 根据项目名取出子项目</p>
	 * <p>Copyright: runlin groups 2017-3-3</p>
	 * <p>Company: runlin </p>
	 * @author changrui.pan  email:changrui.pan@runlin.cn
	 * @date 2018-06-01 
	 * @version 1.0
	 * @param mv
	 * @param request
	 * @return
	 * @throws IOException
	 */
	@ResponseBody
	@RequestMapping(value = "/selectSubProjectList.do")
	public Object selectSubProjectList(ModelAndView mv,HttpServletRequest request) throws IOException {
		
		String projectname = request.getParameter("projectname");
		
		List<ProjectNew> subProjectList = projectService_New.selectSubProjectList(projectname);
		return subProjectList;
	}
	/**
	 * 
	 * <p>selectProjectByName</p>
	 * <p>Description:根据关键字模糊查询</p>
	 * <p>Copyright: runlin groups 2017-3-3</p>
	 * <p>Company: runlin </p>
	 * @author changrui.pan  email:changrui.pan@runlin.cn
	 * @date 2018-06-01 
	 * @version 1.0
	 * @param mv
	 * @param request
	 * @return
	 * @throws IOException
	 */
	@ResponseBody
	@RequestMapping(value = "/selectProjectByName.do")
	public Object selectProjectByName(ModelAndView mv,HttpServletRequest request) throws IOException {
		
		String projectname = request.getParameter("projectname");
		
		List<ProjectNew> projectList = projectService_New.selectProjectList(projectname);
		return projectList;
	}
	
	
}
