package com.roiland.cms.service;

import java.util.List;

import com.roiland.cms.entity.ProjectNew;
import com.roiland.cms.entity.Project_state_new;
import com.roiland.cms.entity.TbTeam;
import com.roiland.cms.entity.TbUsers;


/**
* <p>com.roiland.cms.service.ProjectService.java</p>
* <p>Description:项目管理Service接口 </p>
* <p>Copyright: runlin groups 2018年06月01日</p>
* <p>Company: runlin </p>
* @author email: changrui.pan@runlin.com
* @date 2017年2月24日
* @version 1.0
*/

public interface ProjectService_New {

	/**
	 * 
	* <p>delProject</p>
	* <p>Description: 删除项目</p>
	* <p>Copyright: runlin groups 2017-3-3</p>
	* <p>Company: runlin </p>
	* @author changrui.pan  email:changrui.pan@runlin.cn
	* @date 2017-3-3 下午4:55:07
	* @version 1.0
	* @param id 项目ID
	 */
	public int delProject(int id);
	/**
	 * 
	 * <p>selectDistinctProjectNm</p>
	 * <p>Description: 删除项目</p>
	 * <p>Copyright: runlin groups 2017-3-3</p>
	 * <p>Company: runlin </p>
	 * @author changrui.pan  email:changrui.pan@runlin.cn
	 * @date 2017-3-3 下午4:55:07
	 * @version 1.0
	 * @param id 项目ID
	 */
	public List<ProjectNew> selectDistinctProjectNm();
	
	/**
	 * 
	 * <p>selectProjectList</p>
	 * <p>Description: 项目列表</p>
	 * <p>Copyright: runlin groups 2017-3-3</p>
	 * <p>Company: runlin </p>
	 * @author changrui.pan  email:changrui.pan@runlin.cn
	 * @date 2017-3-3 下午4:55:07
	 * @version 1.0
	 */
	public  List<ProjectNew> selectProjectList(String projectname);
	
	/**
	 * 
	* <p>getUserProjects</p>
	* <p>Description: 项目列表</p>
	* <p>Copyright: runlin groups 2017-3-3</p>
	* <p>Company: runlin </p>
	* @author changrui.pan  email:changrui.pan@runlin.cn
	* @date 2017-3-3 下午4:55:07
	* @version 1.0
	* @param id 项目ID
	 */
	List<ProjectNew> getUserProjects();
	/**
	 * 
	 * <p>selectStateList</p>
	 * <p>Description: 项目状态列表</p>
	 * <p>Copyright: runlin groups 2017-3-3</p>
	 * <p>Company: runlin </p>
	 * @author changrui.pan  email:changrui.pan@runlin.cn
	 * @date 2017-3-3 下午4:55:07
	 * @version 1.0
	 * @param id 项目ID
	 */
	List<Project_state_new> selectStateList();
	/**
	 * 
	 * <p>selectTeamList</p>
	 * <p>Description: 部门列表</p>
	 * <p>Copyright: runlin groups 2017-3-3</p>
	 * <p>Company: runlin </p>
	 * @author changrui.pan  email:changrui.pan@runlin.cn
	 * @date 2017-3-3 下午4:55:07
	 * @version 1.0
	 * @param id 项目ID
	 */
	List<TbTeam> selectTeamList(int projectdepartment);
	/**
	 * 
	 * <p>selectUserList</p>
	 * <p>Description: 组员列表</p>
	 * <p>Copyright: runlin groups 2017-3-3</p>
	 * <p>Company: runlin </p>
	 * @author changrui.pan  email:changrui.pan@runlin.cn
	 * @date 2017-3-3 下午4:55:07
	 * @version 1.0
	 * @param id 项目ID
	 */
	List<TbUsers> selectUserList(int projecttem,int projectdepartment);
	
	/**
	 * 
	 * <p>selectSubProjectList</p>
	 * <p>Description: 子项目列表</p>
	 * <p>Copyright: runlin groups 2017-3-3</p>
	 * <p>Company: runlin </p>
	 * @author changrui.pan  email:changrui.pan@runlin.cn
	 * @date 2017-3-3 下午4:55:07
	 * @version 1.0
	 * @param id 项目ID
	 */
	List<ProjectNew> selectSubProjectList(String projectname);
	
	/**
	 * 
	 * <p>insertProjectNew</p>
	 * <p>Description: 添加项目</p>
	 * <p>Copyright: runlin groups 2017-3-3</p>
	 * <p>Company: runlin </p>
	 * @author changrui.pan  email:changrui.pan@runlin.cn
	 * @date 2017-3-3 下午4:55:07
	 * @version 1.0
	 * @param id 项目ID
	 */
	int insertProjectNew(ProjectNew pn);
	/**
	 * 
	 * <p>uploadProjectNew</p>
	 * <p>Description: 添加项目</p>
	 * <p>Copyright: runlin groups 2017-3-3</p>
	 * <p>Company: runlin </p>
	 * @author changrui.pan  email:changrui.pan@runlin.cn
	 * @date 2017-3-3 下午4:55:07
	 * @version 1.0
	 * @param id 项目ID
	 */
	int uploadProjectNew(ProjectNew pn);
	/**
	 * 
	 * <p>selectProjectNewById</p>
	 * <p>Description: 添加项目</p>
	 * <p>Copyright: runlin groups 2017-3-3</p>
	 * <p>Company: runlin </p>
	 * @author changrui.pan  email:changrui.pan@runlin.cn
	 * @date 2017-3-3 下午4:55:07
	 * @version 1.0
	 * @param id 项目ID
	 */
	int selectProjectNewById(int id);
	
	List<ProjectNew> selectProjectByName(ProjectNew pn);
	
	int selectMaxIndex();
	
}
