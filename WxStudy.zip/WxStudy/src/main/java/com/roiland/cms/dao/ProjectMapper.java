package com.roiland.cms.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.roiland.cms.entity.ProjectNew;
import com.roiland.cms.entity.Project_state_new;
import com.roiland.cms.entity.TbTeam;
import com.roiland.cms.entity.TbUsers;

/**
* <p>com.roiland.cms.dao.ProjectMapper.java</p>
* <p>Description:项目管理 </p>
* <p>Copyright: runlin groups 2017年2月24日</p>
* <p>Company: runlin </p>
* @author email: King.jin@runlin.com
* @date 2017年2月24日
* @version 1.0
*/

public interface ProjectMapper {
	
	/**
	 * 
	* <p>delProject</p>
	* <p>Description: 删除项目</p>
	* <p>Copyright: runlin groups 2017-3-3</p>
	* <p>Company: runlin </p>
	* @author huan.yu  email:huan.yu@runlin.cn
	* @date 2017-3-3 下午4:57:08
	* @version 1.0
	* @param projectName 项目名称
	* @param projectcode 项目编号
	 */
	public int delProject(@Param("id") int id);
	
	/**
	 * 
	 * <p>selectDistinctProjectNm</p>
	 * <p>Description: 删除项目</p>
	 * <p>Copyright: runlin groups 2017-3-3</p>
	 * <p>Company: runlin </p>
	 * @author changrui.pan  email:changrui.pan@runlin.cn
	 * @date 2017-3-3 下午4:55:07
	 * @version 1.0
	 * @param id 项目ID
	 */
	public List<ProjectNew> selectDistinctProjectNm();
	
	/**
	 * 
	 * <p>selectProjectList</p>
	 * <p>Description: 项目列表</p>
	 * <p>Copyright: runlin groups 2017-3-3</p>
	 * <p>Company: runlin </p>
	 * @author changrui.pan  email:changrui.pan@runlin.cn
	 * @date 2017-3-3 下午4:55:07
	 * @version 1.0
	 */
	public  List<ProjectNew> selectProjectList(@Param("projectname") String projectname);
	
	/**
	 * 
	 * <p>selectSubProjectList</p>
	 * <p>Description: 子项目列表</p>
	 * <p>Copyright: runlin groups 2017-3-3</p>
	 * <p>Company: runlin </p>
	 * @author changrui.pan  email:changrui.pan@runlin.cn
	 * @date 2017-3-3 下午4:55:07
	 * @version 1.0
	 * @param id 项目ID
	 */
	List<ProjectNew> selectSubProjectList(@Param("projectname") String projectname);
	
	/**
	 * 
	* <p>getUserProjects</p>
	* <p>Description: 项目列表</p>
	* <p>Copyright: runlin groups 2017-3-3</p>
	* <p>Company: runlin </p>
	* @author changrui.pan  email:changrui.pan@runlin.cn
	* @date 2017-3-3 下午4:55:07
	* @version 1.0
	* @param id 项目ID
	 */
	List<ProjectNew> getUserProjects();
	
	/**
	 * 
	 * <p>selectStateList</p>
	 * <p>Description: 项目状态列表</p>
	 * <p>Copyright: runlin groups 2017-3-3</p>
	 * <p>Company: runlin </p>
	 * @author changrui.pan  email:changrui.pan@runlin.cn
	 * @date 2017-3-3 下午4:55:07
	 * @version 1.0
	 * @param id 项目ID
	 */
	List<Project_state_new> selectStateList();
	/**
	 * 
	 * <p>selectTeamList</p>
	 * <p>Description: 部门列表</p>
	 * <p>Copyright: runlin groups 2017-3-3</p>
	 * <p>Company: runlin </p>
	 * @author changrui.pan  email:changrui.pan@runlin.cn
	 * @date 2017-3-3 下午4:55:07
	 * @version 1.0
	 * @param id 项目ID
	 */
	List<TbTeam> selectTeamList(@Param("projectdepartment") int projectdepartment);
	/**
	 * 
	 * <p>selectUserList</p>
	 * <p>Description: 组员列表</p>
	 * <p>Copyright: runlin groups 2017-3-3</p>
	 * <p>Company: runlin </p>
	 * @author changrui.pan  email:changrui.pan@runlin.cn
	 * @date 2017-3-3 下午4:55:07
	 * @version 1.0
	 * @param id 项目ID
	 */
	List<TbUsers> selectUserList(@Param("projecttem") int projecttem,@Param("projectdepartment") int projectdepartment);
	
	/**
	 * 
	 * <p>insertProjectNew</p>
	 * <p>Description: 添加项目</p>
	 * <p>Copyright: runlin groups 2017-3-3</p>
	 * <p>Company: runlin </p>
	 * @author changrui.pan  email:changrui.pan@runlin.cn
	 * @date 2017-3-3 下午4:55:07
	 * @version 1.0
	 * @param id 项目ID
	 */
	int insertProjectNew(@Param("pn") ProjectNew pn);
	
	/**
	 * 
	 * <p>uploadProjectNew</p>
	 * <p>Description: 添加项目</p>
	 * <p>Copyright: runlin groups 2017-3-3</p>
	 * <p>Company: runlin </p>
	 * @author changrui.pan  email:changrui.pan@runlin.cn
	 * @date 2017-3-3 下午4:55:07
	 * @version 1.0
	 * @param id 项目ID
	 */
	int uploadProjectNew(@Param("pn") ProjectNew pn);
	
	/**
	 * 
	 * <p>selectProjectNewById</p>
	 * <p>Description: 添加项目</p>
	 * <p>Copyright: runlin groups 2017-3-3</p>
	 * <p>Company: runlin </p>
	 * @author changrui.pan  email:changrui.pan@runlin.cn
	 * @date 2017-3-3 下午4:55:07
	 * @version 1.0
	 * @param id 项目ID
	 */
	int selectProjectNewById(@Param("id") int id);
	
	List<ProjectNew> selectProjectByName(@Param("pn") ProjectNew pn);
	
	int selectMaxIndex();
	
}
