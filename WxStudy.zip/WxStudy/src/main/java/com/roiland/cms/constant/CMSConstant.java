package com.roiland.cms.constant;


/**
 * <p>Title: CrmConstant.java</p>
 * <p>Description: </p>
 * <p>Copyright: roiland groups 2013-4-23</p>
 * <p>Company: roiland </p>
 * @author srchen email:jackson.song@roiland.com
 * @date 2013-4-23 上午9:49:31
 * @version 1.0
 */
public class CMSConstant {
	public static final String ITEM="item_prefix";					//站点
	
	public static final String CMS_COOKIE_SK="cms_cookie_sk";		//标识
	
	public static final String CMS_COOKIE_PATH="cms_cookie_path";	//路径
	
	public static final String CMS_COOKIE_DOMAIN="cms_cookie_domain";//域
	
	public static final String CMS_COOKIE_SECURITYKEY="cms_cookie_securitykey";//秘钥
	
	public static final String FRONT_EDITIMAGE_PATH = "front_editimage_path";
	
	public static final String SESSIONUSER="user_data";				//用户信息
	
	public static final String TABLEPREFIX="tb_dynamic_";			//动态表前缀
	
	public static final String TABLELONGPOSTFIX="longvalue";		//动态表大型信息存储后缀
	
	public static final String TABLESHORTPOSTFIX="shortvalue";		//动态表小型信息存储后缀
	
	public static final String SESSIONVERIFYCODE ="verifyCode";		//验证码
	
	public static final String BASEPATH ="basepath";				//全局路径
	
	public static final String FTBFLAG ="ftbflag";					//全局路径
	
	public static final String RANDOM ="random";					//奥迪之家后台注册变量（时间戳+随机字母）
	
	public static final String COMPLAINEMAIL ="complain_email";		//投诉email
	
	public static final String SECURITYKEY = "cmsS0I>O";			//秘钥
	
	public static final String URI_PATH = "uri_path";
	
	public static final String CMS_COOKIE_CK = "cms_cookie_ck";		//秘钥

	public static final String CMS_LOCATION_KEY="cms_location_key";	//当前访问位置，只区分前台，经销商后台，系统后台
	
	public static final String SURVEY_FILE = "survey_file";
	
	
	public static enum Location{
		ADMIN,
		MANAGER,
		FRONT
	}
}

