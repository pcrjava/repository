package com.roiland.cms.entity;  

import java.io.Serializable;

/** 
 * <p>package com.roiland.cms.entity;</p> 
 * <p>public class TbTeam{ }</p>
 * <p>com.roiland.cms.entity.TbTeam.java</p>
 * <p>Description: 工时系统组别实体类</p>
 * <p>Copyright: runlin groups 2017-2-28</p>
 * <p>Company: runlin </p>
 * @author huan.yu  email:huan.yu@runlin.cn
 * @date 2017-2-28
 * @version 1.0
 */
public class TbTeam implements Serializable{

	private Integer id;//组ID
	private String deptid;//部门ID
	private String name;//组名
	private String addtime;//添加人员
	private String adduser;//添加人员
	private static final long serialVersionUID = 1L;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getDeptid() {
		return deptid;
	}
	public void setDeptid(String deptid) {
		this.deptid = deptid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddtime() {
		return addtime;
	}
	public void setAddtime(String addtime) {
		this.addtime = addtime;
	}
	public String getAdduser() {
		return adduser;
	}
	public void setAdduser(String adduser) {
		this.adduser = adduser;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}
  