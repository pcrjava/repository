package com.roiland.cms.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.roiland.cms.dao.ProjectMapper;
import com.roiland.cms.entity.ProjectNew;
import com.roiland.cms.entity.Project_state_new;
import com.roiland.cms.entity.TbTeam;
import com.roiland.cms.entity.TbUsers;
import com.roiland.cms.service.ProjectService_New;

/**
* <p>com.roiland.cms.service.impl.ProjectServiceImpl.java</p>
* <p>Description: </p>
* <p>Copyright: runlin groups 2017年2月24日</p>
* <p>Company: runlin </p>
* @author email: King.jin@runlin.com
* @date 2017年2月24日
* @version 1.0
*/
@Service
public class ProjectServiceImpl_New implements ProjectService_New{

	
	/** 注入mapper **/
	@Resource
	private ProjectMapper projectMapper_New;

	/**
	 * 删除项目
	 * TODO  
	 * @see com.roiland.cms.service.ProjectService#delProject(java.lang.String, java.lang.String)
	 */
	@Override
	public int delProject(int id) {
		int result =projectMapper_New.delProject(id);
		return result;
	}

	/**
	 * 项目列表
	 * TODO  
	 * @see com.roiland.cms.service.ProjectService#getUserProjects()
	 */
	@Override
	public List<ProjectNew> getUserProjects() {
		List<ProjectNew> projects = projectMapper_New.getUserProjects();
		return projects;
	}


	/**
	 * 项目状态列表
	 * TODO  
	 * @see com.roiland.cms.service.ProjectService#selectStateList()
	 */
	@Override
	public List<Project_state_new> selectStateList() {
		List<Project_state_new> stateList = projectMapper_New.selectStateList();
		return stateList;
	}

	/**
	 * 部门列表
	 * TODO  
	 * @see com.roiland.cms.service.ProjectService#selectTeamList()
	 */
	@Override
	public List<TbTeam> selectTeamList(int projectdepartment) {
		 List<TbTeam> teamList = projectMapper_New.selectTeamList(projectdepartment);
		return teamList;
	}

	/**
	 * 员工列表
	 * TODO  
	 * @see com.roiland.cms.service.ProjectService#selectUserList()
	 */
	@Override
	public List<TbUsers> selectUserList(int projecttem,int projectdepartment) {
		 List<TbUsers> userList = projectMapper_New.selectUserList(projecttem,projectdepartment);
		return userList;
	}

	/**
	 * 添加项目
	 * TODO  
	 * @see com.roiland.cms.service.ProjectService#insertProjectNew()
	 */
	@Override
	public int insertProjectNew(ProjectNew pn) {
		int result= projectMapper_New.insertProjectNew(pn);
		return result;
	}

	@Override
	public int selectProjectNewById(int id) {
		int count = projectMapper_New.selectProjectNewById(id);
		return count;
	}

	@Override
	public int uploadProjectNew(ProjectNew pn) {
		int result= projectMapper_New.uploadProjectNew(pn);
		return result;
	}

	@Override
	public  List<ProjectNew> selectProjectList(String projectname) {
		List<ProjectNew> projectList = projectMapper_New.selectProjectList(projectname);
		return projectList;
	}

	@Override
	public List<ProjectNew> selectSubProjectList(String projectname) {
		List<ProjectNew> subProjectList = projectMapper_New.selectSubProjectList(projectname);
		return subProjectList;
	}

	@Override
	public List<ProjectNew> selectDistinctProjectNm() {
		List<ProjectNew> projectlist = projectMapper_New.selectDistinctProjectNm();
		return projectlist;
	}

	@Override
	public List<ProjectNew> selectProjectByName(ProjectNew pn) {
		List<ProjectNew> projectlist= projectMapper_New.selectProjectByName(pn);
		return projectlist;
	}

	@Override
	public int selectMaxIndex() {
		 int a = projectMapper_New.selectMaxIndex();
		return a;
	}

}
