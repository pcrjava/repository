package com.roiland.cms.entity;  

import java.io.Serializable;

/** 
 * <p>package com.roiland.cms.entity;</p> 
 * <p>public class TbUsers{ }</p>
 * <p>com.roiland.cms.entity.TbUsers.java</p>
 * <p>Description: 用户信息实体类</p>
 * <p>Copyright: runlin groups 2017-2-20</p>
 * <p>Company: runlin </p>
 * @author huan.yu  email:huan.yu@runlin.cn
 * @date 2017-2-20
 * @version 1.0
 */
public class TbUsers implements Serializable {

	private Integer id;	//ID	
	private Integer teamid;//所属组ID
	private String account;//登录名
	private String pwd;//登录密码
	private String name;//姓名
	private String email;//邮箱
	private String deptid;//部门ID
	private String isdel;//是否离职（默认0-在职；1-离职）
	private Integer usergroupid;//用户组（角色）ID
	private int pid; // 上级ID
	private String deptName;//部门名称
	private String teamName;//组名
	private String addTime;//添加时间
	private Integer adduser;//添加人
	private String newDeptid; // 选择的部门Id
	private String usertype; // 员工类型
	
	public String getUsertype() {
		return usertype;
	}

	public void setUsertype(String usertype) {
		this.usertype = usertype;
	}

	private static final long serialVersionUID = 1L;
	
	public String getNewDeptid() {
		return newDeptid;
	}

	public void setNewDeptid(String newDeptid) {
		this.newDeptid = newDeptid;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getTeamid() {
		return teamid;
	}

	public void setTeamid(Integer teamid) {
		this.teamid = teamid;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	

	public String getDeptid() {
		return deptid;
	}

	public void setDeptid(String deptid) {
		this.deptid = deptid;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getIsdel() {
		return isdel;
	}

	public void setIsdel(String isdel) {
		this.isdel = isdel;
	}

	public Integer getUsergroupid() {
		return usergroupid;
	}

	public void setUsergroupid(Integer usergroupid) {
		this.usergroupid = usergroupid;
	}

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getTeamName() {
		return teamName;
	}

	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}

	public String getAddTime() {
		return addTime;
	}

	public void setAddTime(String addTime) {
		this.addTime = addTime;
	}

	public Integer getAdduser() {
		return adduser;
	}

	public void setAdduser(Integer adduser) {
		this.adduser = adduser;
	}
	
	
}
  