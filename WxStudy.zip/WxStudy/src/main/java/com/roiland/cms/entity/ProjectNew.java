package com.roiland.cms.entity;

public class ProjectNew {
  private int id;
  private String projectnumber;
  private String projectname;
  private String addProjectname;
  private String subprojectname;
  private String projectdate;
  private int projectdepartment;
  private String subprojectcode;
  private int projecttem;
  private int projectmanager;
  private int projectstate;
  private double projectvalue;
  private double purchaseamount;
  private int isdelete;
  private String createtime;
  private int adduser;
  private String updatetime;
  private int updateuser;
  private String deptname;
  private String LeaderNm;
  private String stateNm;
  private String teamname;
  private int projectid;
  
public int getProjectid() {
	return projectid;
}
public void setProjectid(int projectid) {
	this.projectid = projectid;
}
public String getAddProjectname() {
	return addProjectname;
}
public void setAddProjectname(String addProjectname) {
	this.addProjectname = addProjectname;
}
public String getSubprojectcode() {
	return subprojectcode;
}
public void setSubprojectcode(String subprojectcode) {
	this.subprojectcode = subprojectcode;
}
public String getTeamname() {
	return teamname;
}
public void setTeamname(String teamname) {
	this.teamname = teamname;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getProjectnumber() {
	return projectnumber;
}
public void setProjectnumber(String projectnumber) {
	this.projectnumber = projectnumber;
}
public String getProjectname() {
	return projectname;
}
public void setProjectname(String projectname) {
	this.projectname = projectname;
}
public String getSubprojectname() {
	return subprojectname;
}
public void setSubprojectname(String subprojectname) {
	this.subprojectname = subprojectname;
}
public String getProjectdate() {
	return projectdate;
}
public void setProjectdate(String projectdate) {
	this.projectdate = projectdate;
}
public int getProjectdepartment() {
	return projectdepartment;
}
public void setProjectdepartment(int projectdepartment) {
	this.projectdepartment = projectdepartment;
}
public int getProjecttem() {
	return projecttem;
}
public void setProjecttem(int projecttem) {
	this.projecttem = projecttem;
}
public int getProjectmanager() {
	return projectmanager;
}
public void setProjectmanager(int projectmanager) {
	this.projectmanager = projectmanager;
}
public int getProjectstate() {
	return projectstate;
}
public void setProjectstate(int projectstate) {
	this.projectstate = projectstate;
}
public double getProjectvalue() {
	return projectvalue;
}
public void setProjectvalue(double projectvalue) {
	this.projectvalue = projectvalue;
}
public double getPurchaseamount() {
	return purchaseamount;
}
public void setPurchaseamount(double purchaseamount) {
	this.purchaseamount = purchaseamount;
}
public int getIsdelete() {
	return isdelete;
}
public void setIsdelete(int isdelete) {
	this.isdelete = isdelete;
}
public String getCreatetime() {
	return createtime;
}
public void setCreatetime(String createtime) {
	this.createtime = createtime;
}
public int getAdduser() {
	return adduser;
}
public void setAdduser(int adduser) {
	this.adduser = adduser;
}
public String getUpdatetime() {
	return updatetime;
}
public void setUpdatetime(String updatetime) {
	this.updatetime = updatetime;
}
public int getUpdateuser() {
	return updateuser;
}
public void setUpdateuser(int updateuser) {
	this.updateuser = updateuser;
}
public String getDeptname() {
	return deptname;
}
public void setDeptname(String deptname) {
	this.deptname = deptname;
}
public String getLeaderNm() {
	return LeaderNm;
}
public void setLeaderNm(String leaderNm) {
	LeaderNm = leaderNm;
}
public String getStateNm() {
	return stateNm;
}
public void setStateNm(String stateNm) {
	this.stateNm = stateNm;
}

}
