// JavaScript Document

$(document).ready(function(){
	var nav = $('#f-lf-nav');
	nav.click(function(){
	  nav.closest("li").addClass("crt");
	  nav.closest("li").children(".nav-bd").slideDown();
	});
	
	$('#add').click(function(){
		$(".z-show").fadeIn();
	});
	$('#addcar').click(function(){
		$(".z-showcar").fadeIn();
	});
	$('#addcarguanlian').click(function(){
		$(".z-showcarguanlian").fadeIn();
	});
	$('#addguanlian').click(function(){
		$(".z-showguanlian").fadeIn();
	});
	
//	$('#addfwhd').click(function(){
//		$("#fwhdadd").fadeIn();
//	});
	
//	$('#update').click(function(){
//		$("#updtopic").fadeIn();
//	});
	
	$('.lyclose').click(function(){
		$(".z-show").fadeOut();
	});
	$('.lyclosecar').click(function(){
		$(".z-showcar").fadeOut();
	});
	$('.lyclosecarguanlian').click(function(){
		$(".z-showcarguanlian").fadeOut();
	});
	$('.lycloseguanlian').click(function(){
		$(".z-showguanlian").fadeOut();
	});
	
	$('#xiala_show').click(function(){
		$(".u-btns").children(".u-menu").toggle();
	});
	//roy.meng
	$('#cancelroy1').click(function(){
		$("#fwhdadd").fadeOut();
		$("#updtopic").fadeOut();
	});
	$('#cancelroy2').click(function(){
		$("#fwhdadd").fadeOut();
		$("#updtopic").fadeOut();
	});
	//alin
	$('#shezhiadh').click(function(){
		$(".z-show2").fadeIn()
	});
	$('#lycloseadh').click(function(){
		$(".z-show2").fadeOut()
	});
	$('#lycloseadh2').click(function(){
		$(".z-show2").fadeOut()
	});
	$('#addadh').click(function(){
		$('#id').val(0);
		$('#jobnameadd').val('');
		$('#experience').val('');
		$('#number').val('');
		$('#education').val('');
		$('#jobdescription').val('');
		$('#workplace').val('');
		$('#jobtype1').attr("checked",true);
		$(".z-show").fadeIn()
	});
});