/*
 * 主JS文件
 * 日期: 2017-02-06
 * By Endfish
 * 
*/

//所有页面
function initPage () {
	
	//左侧导航开启
	$('div.page-top .menu-left').on("click",function() {
		$('div.left-nav').removeClass("left-nav-hide");
	})
	//左侧导航关闭
	$('div.left-nav .btn-close').on("click",function() {
		$('div.left-nav').addClass("left-nav-hide");
	});
	//右侧导航开启
	$('div.page-top .menu-right').on("click",function() {
		$('div.right-nav').removeClass("right-nav-hide");
	})
	
}