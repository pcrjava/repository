/** 定义全局变量* */
var URI = '';
var flag = false;

/** 页面加载时加载部门信息* */
function loadDepInfo(uri,depID) {
	URI = uri;
	$.ajax({
		type : "POST",
		dataType : "text",
		url : uri + 'loadDepInfo.do',
		async : false,
		dataType : "text",
		success : function(data) {
			// alert(data);
			$(eval("(" + data + ")")).each(function() {
							if (depID == this.id) {
								$("#depID").html('');
								$("#depID").append("<option value='" + this.id + "'>"+ this.deptName + "</option>");
								loadTeamInfo();
							}
			});
		}
	});
}
/** 美工JS中赋值* */
/*
 * function loadTeamInfo(nowValue){ //获取选中的值 //alert(nowValue); if(nowValue ==
 * 0){ $("#projectName_team").val('无'); return false; } }
 */
/** 根据部门ID查询对应组信息* */
function loadTeamInfo() {
	// 获取选择部门ID
	var deptid = $("#depID").find("option:selected").val();
	$.ajax({
		type : "POST",
		url : URI + 'loadTeamInfo.do?deptid=' + deptid,
		async : false,
		dataType : "text",
		success : function(data) {
			// alert(data);
			$("#teamID").html("");
			$("#teamID").append("<option value='0'>请选择</option>");
			$(eval("(" + data + ")")).each(
					function() {
						// alert(this.name);
							$("#teamID").append(
									"<option value='" + this.id + "'>"
											+ this.name + "</option>");
			});
			
			// author pcr
			$("#pid").empty();
			
			$.ajax({
				url:"selectEmployeeNm.do",
				type:"post",
				data:{
					teamid:$("#teamID").find("option:selected").val()
				},
				success:function(data){
					var aa="<option value='0'>请选择</option>";
					for(var i= 0;i<data.length;i++){
						aa+= "<option value='"+data[i].id+"'>"+data[i].name+"</option>";
					}
					$("#pid").append(aa);
				}
			});
		}
	});

	if (deptid == 0) {
		$("#teamID").html("<option value='0'>无</option>");
	}

}
/** 英文名和邮箱联动效果* */
$("#accountID").on("input", function(e) {
	
	$(this).parent().next().children().next().val($(this).val() + '@runlin.cn');
}); 

// 检索出对应组组员
function loadEmployeeNm(e){
	var teamid = $(e).find("option:selected").val();
	$.ajax({
		type:"post",
		url:"selectEmployeeNm.do",
		data:{
			teamid:teamid
		},
		success:function(data){
			var aa="<option value='0'>请选择</option>";
		
			for(var i= 0;i<data.length;i++){
				aa+= "<option value='"+data[i].id+"'>"+data[i].name+"</option>";
			}
			$(e).parent().next().find("select#pid").empty();
			$(e).parent().next().find("select#pid").append(aa);
		}	
	});
	
}

/**对英文名进行校验**/
function cheakaccount(account){
	//校验英文名
	$.ajax({
		type : "POST",
		url : URI + 'cheakaccount.do?account=' + account,
		async : false,
		success : function(data) {
			//alert(data);
			if (data != "0") {
				//alert("英文名已被使用!");	
				flag =false;
				return flag;
			}else{
				flag = true;
				return flag;
			}
		}
	});
}
//


//最后一个模块的提交按钮
$('div.save-this').on('click',function(){
	// 获取所有用户模块信息
	 var UserList = UserLoop(); 
	 //alert(UserList);
	 //如果UserList等于false 返回
	 if(UserList==false){
		 return false;
	 }
	 //执行插入操作
	     $.ajax({
		type : "POST",
		url : URI + 'userM/addTbUsers.do',
		data : {
			a : UserList
		},
		success : function(data) {
			if (data == 1) {
				$('div.box-info-success:last').addClass("box-info-show");
				setTimeout(function() {
					$("#success01").removeClass("box-info-show");
				}, 1500);
				setTimeout(function() {
				window.location.href = URI + "userM/userManagement.html?";//再重新查询一下用户列表
				}, 1500);
			} else {
				$("#error01").addClass("box-info-show");
				setTimeout(function() {
					$("#error01").removeClass("box-info-show");
				}, 15000);
			}
		}
	});
});


// 获取所有用户模块信息 拼接用户信息
function UserLoop(){
	var index =0;
	var a="["
	var b="["
	$('div.user-main .user-ul .list').each(function(){
		// 验证页面元素非空
		if($('div.user-main .user-ul .list #nameID').eq(index).val()==''){
			alert("第"+(index+1)+"个用户姓名不能为空!");
			a="";
			b="";
			return false;
		}else if($('div.user-main .user-ul .list #depID').eq(index).find("option:selected").val()=='0'){
			alert("第"+(index+1)+"个用户部门不能为空!");
			a="";
			b="";
			return false;
		}else if($('div.user-main .user-ul .list #teamID').eq(index).find("option:selected").val()=='0'){
			alert("第"+(index+1)+"个用户组别不能为空!");
			a="";
			b="";
			return false;
		}else if($('div.user-main .user-ul .list #pid').eq(index).find("option:selected").val()=='0'){
			alert("第"+(index+1)+"个用户上级领导不能为空!");
			a="";
			b="";
			return false;
		}else if($('div.user-main .user-ul .list #accountID').eq(index).val()==''){
			alert("第"+(index+1)+"个用户英文名不能为空!");
			a="";
			b="";
			return false;
		}else if($('div.user-main .user-ul .list #emailID').eq(index).val()==''){
			alert("第"+(index+1)+"个用户邮箱不能为空!");
			a="";
			b="";
			return false;
		}else if($('div.user-main .user-ul .list #accountID').eq(index).val()!=''){
			//正则验证英文名标准
			var standard = /^([A-Za-z]+\.[A-Za-z]+)$/;
			// 再校验登录名称是否合法
			if (!standard.test($('div.user-main .user-ul .list #accountID').eq(index).val())) {
				alert("第"+(index+1)+"个用户英文名格式不正确!(英文名.姓的全拼)");
				a="";
				b="";
				return false;
			}
			if (b.indexOf($('div.user-main .user-ul .list #accountID').eq(index).val()) != -1) {
				alert("第"+(index+1)+"个用户英文名重复!");
				a="";
				b="";
				return false;
			}
			if ($('div.user-main .user-ul .list #accountID').eq(index).val().length > 50) {
				alert("第"+(index+1)+"个用户英文名过长（英文名不能超过50个字符）!");
				a="";
				b="";
				return false;
			}
		}
		if($('div.user-main .user-ul .list #nameID').eq(index).val()!=''){
			//正则验证用户姓名标准
			var standard_name = /^[\u4E00-\u9FA5]+$/;
			// 再校验姓名是否合法
			if (!standard_name.test($('div.user-main .user-ul .list #nameID').eq(index).val())) {
				alert("第"+(index+1)+"个用户姓名格式不正确!(中文)");
				a="";
				b="";
				return false;
			}
			if ($('div.user-main .user-ul .list #nameID').eq(index).val().length > 10) {
				alert("第"+(index+1)+"个用户姓名超长（姓名不能超过10个字符）！");
				a="";
				b="";
				return false;
			}
		}
		
		cheakaccount($('div.user-main .user-ul .list #accountID').eq(index).val());
		//alert(flag);
		if (!flag) {
			alert("第"+(index+1)+"个用户英文名已被使用!");
			a="";
			return false;
		}
		 a=a+"{\"name\":\""+$('div.user-main .user-ul .list #nameID').eq(index).val()+
         "\",\"deptid\":\""+$('div.user-main .user-ul .list #depID').eq(index).find("option:selected").val()+
         "\",\"teamid\":\""+$('div.user-main .user-ul .list #teamID').eq(index).find("option:selected").val()+
		 "\",\"account\":\""+$('div.user-main .user-ul .list #accountID').eq(index).val()+
		 "\",\"email\":\""+$('div.user-main .user-ul .list #emailID').eq(index).val()+
		 "\",\"usertype\":\""+$('div.user-main .user-ul .list #userType').eq(index).val()+
		 "\",\"pid\":\""+$('div.user-main .user-ul .list #pid').eq(index).find("option:selected").val()+"\"},";	
		 
		 b = b + "{" + $('div.user-main .user-ul .list #accountID').eq(index).val() + "},";
		     index++;
		if (index ==$('div.user-main .user-ul .list:last').index()){
			return false;
		}
	});
	
   a=a.substring(0,a.length-1)+"]";
   b=b.substring(0,a.length-1)+"]";
   
   if (a=="]"){
	   return false;
   }  
	return a;
}