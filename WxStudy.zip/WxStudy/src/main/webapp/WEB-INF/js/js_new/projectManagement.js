/** 定义全局变量* */
var URI = '';
/** 修改项目信息* */
function updProjectInfo(uri, projectName, projectcode, projectLeader, departmentid, teamid ,count,projectuserid,projectID,startDate,endDate) {
	//alert(endDate);
	URI = uri;
	//alert(uri+projectName+ projectcode+projectLeader+ departmentid+teamid+projectuserid + projectID);
	window.location.href = URI + "project/updProjectInfo.do?projectName=" + encodeURI(encodeURI(projectName))
			+ "&projectcode=" + projectcode + "&projectLeader=" + encodeURI(encodeURI(projectLeader))
			+ "&departmentid=" +departmentid + "&teamid=" + teamid + "&count=" + count + "&projectuserid=" + projectuserid + "&projectID=" + projectID
			+ "&startDate=" + startDate + "&endDate=" + endDate;
}

/*//changrui.pan
function loadDepInfo(uri){
	URI = uri;
	loadTeamInfo();
}
*/
/** 页面加载时加载部门信息* */
function loadDepInfo(uri,depid) {
	// 获取隐藏域中的部门ID
	var hiddenDeptid = $("#hiddenDeptid").val();
	// alert(hiddenDeptid);
	URI = uri;
	$.ajax({
		type : "POST",
		dataType : "text",
		url : uri + 'loadDepInfo.do',
		async : false,
		dataType : "text",
		success : function(data) {
			// alert(data);
			$(eval("(" + data + ")")).each(
					function() {
						//if (this.id=='2' || this.id=='5'){
							if (this.id == hiddenDeptid) {
								$("#depID").append(
										"<option selected = 'selected' value='"
												+ this.id + "'>" + this.deptName
												+ "</option>");
								loadTeamInfo();
							} else {
								$("#depID").append(
										"<option value='" + this.id + "'>"
												+ this.deptName + "</option>");
							}
						//}
					});
		}
	});
}

/** 根据部门ID查询对应组信息* */
function loadTeamInfo() {
	// 获取选择部门ID
	var deptid = $("#depID").val();
	// 获取隐藏域中的组信息(组别id)
	var teamid = $("#hiddenteamid").val().trim();
	 //alert(teamid);
	$.ajax({
		type : "POST",
		url : URI + 'loadTeamInfo.do?deptid=' + deptid,
		async : false,
		dataType : "text",
		success : function(data) {
			// alert(data);
			$("#teamID").html("");
			$(eval("(" + data + ")")).each(
					function() {
						// alert(this.name);
						if (this.id == teamid) {
							$("#teamID").append(
									"<option selected = 'selected' value='"
											+ this.id + "'>" + this.name
											+ "</option>");
						} else {
							$("#teamID").append(
									"<option value='" + this.id + "'>"
											+ this.name + "</option>");
						}
					});
			loadTbUsers();
		}
	});

	if (deptid == 0) {
		$("#teamID").html("<option value='0'>无</option>");
	}

}
/**加载全部人员**/
function loadTbUsers(){
	//alert("1");
	//页面加载的时候加载项目经理
	var seldeptid = $("#depID").val();
	var selteamID = $("#teamID").val();

	var hiddenprojectuserid = $("#hiddenprojectuserid").val().trim();//获取隐藏域中项目经理ID
	//alert(hiddenprojectuserid);
	//页面加载的时候获取隐藏域中项目经理ID
	$.ajax({
		type : "POST",
		dataType : "text",
		url : URI + 'loadTbUsers.do?',
		data:{
			 seldeptid : $("#depID").val(),
			 selteamID : $("#teamID").val()
		},
		async : false,
		dataType : "text",
		success : function(data) {
			// alert(data);
			$("#projectLeaderID").html("");

			$(eval("(" + data + ")")).each(
					function() {
						if (this.id == hiddenprojectuserid) {
							$("#projectLeaderID").append("<option selected = 'selected' value='"+ this.id + "'>" + this.name+ "</option>");
						} else {
							/*$("#projectLeaderID").append("<option value='" + this.id + "'>"+ this.name + "</option>");*/
							
							if(seldeptid == this.deptid && selteamID == this.teamid){ 
								$("#projectLeaderID").append("<option value='" + this.id + "'>"+ this.name + "</option>");
							}
						}
						
					});
		}
	});
}


/** 开始更新项目信息* */
function startUpdProjectInfo() {
	//获取项目ID
	var projectID = $("#hiddenprojectID").val().trim();
	// 获取项目名
	var projectName = $("#projectNameID").val().trim();
	// 获取选中的部门ID
	var deptid = $("#depID").find("option:selected").val();
	// 获取选中的组别ID
	var teamID = $("#teamID").find("option:selected").val();
	// 获取项目编号
	var projectcode = $("#projectcodeID").val().trim();
	// 获取项目经理ID
	var projectLeaderID = $("#projectLeaderID").find("option:selected").val();
	// 获取项目经理姓名
	var projectLeader = $("#projectLeaderID").find("option:selected").text();
	// 获取项目开始时间   
	var startDate = $("#beginTime").val().trim();
	// 获取项目结束时间
	var endDate = $("#endTime").val().trim();
	
	if ("" == projectName || null == projectName) {// 校验项目名称
		$("#error02").addClass("box-info-show");
		setTimeout(function() {
			$("#error02").removeClass("box-info-show");
		}, 1500);
		return false;
	}
	if ("" == deptid || null == deptid) {// 校验部门ID
		$("#error03").addClass("box-info-show");
		setTimeout(function() {
			$("#error03").removeClass("box-info-show");
		}, 1500);
		return false;
	}
	if ("" == teamID || null == teamID) {// 校验组别ID
		$("#error04").addClass("box-info-show");
		setTimeout(function() {
			$("#error04").removeClass("box-info-show");
		}, 1500);
		return false;
	}
	if ("" == projectcode || null == projectcode) {// 校验项目编号
		$("#error05").addClass("box-info-show");
		setTimeout(function() {
			$("#error05").removeClass("box-info-show");
		}, 1500);
		return false;
	}
	if ("" == projectLeaderID || null == projectLeaderID) {// 校验项目经理ID
		$("#error06").addClass("box-info-show");
		setTimeout(function() {
			$("#error06").removeClass("box-info-show");
		}, 1500);
		return false;
	}
	
	if (projectName.indexOf("\'") >0 || projectName.indexOf("\"") > 0 || projectName.indexOf("&") > 0) {//项目名称不能输入单引和双引号和&
		$("#error08").addClass("box-info-show");
		setTimeout(function() {
			$("#error08").removeClass("box-info-show");
		}, 1500);
		return false;
	}
	if (projectcode.indexOf("\'") >0 || projectcode.indexOf("\"") >0 || projectcode.indexOf("&") >0) {//项目编号不能输入单引和双引号
		$("#error09").addClass("box-info-show");
		setTimeout(function() {
			$("#error09").removeClass("box-info-show");
		}, 1500);
		return false;
	}
	if (projectName.length >200) {//项目名称不能超过200字符
		$("#error10").addClass("box-info-show");
		setTimeout(function() {
			$("#error10").removeClass("box-info-show");
		}, 1500);
		return false;
	}
	if (projectcode.length >50) {//项目编号不能超过50字符
		$("#error11").addClass("box-info-show");
		setTimeout(function() {
			$("#error11").removeClass("box-info-show");
		}, 1500);
		return false;
	}
	/*
	 * changrui.pan 修改 2017/03/15
	 * if ("" == startDate || null == startDate) {//项目开始时间
		$("#error12").addClass("box-info-show");
		setTimeout(function() {
			$("#error12").removeClass("box-info-show");
		}, 1500);
		return false;
	}
	if ("" == endDate || null == endDate) {//项目结束时间
		$("#error13").addClass("box-info-show");
		setTimeout(function() {
			$("#error13").removeClass("box-info-show");
		}, 1500);
		return false;
	}
	if (startDate > endDate) {
		$("#error14").addClass("box-info-show");
		setTimeout(function() {
			$("#error14").removeClass("box-info-show");
		}, 1500);
		return false;
	}*/
	// 获取隐藏域中的项目名，校验项目名称是否改动
	var hiddenprojectName = $("#hiddenprojectNameID").val().trim();
	// 获取隐藏域中的项目编号，校验项目编号是否改动
	var hiddenprojectcode = $("#hiddenprojectcodeID").val().trim();
	
	if (hiddenprojectName == projectName) { // 此次操作项目名称都没有改变
		// 不需要针对项目名去验重，可执行更新操作
		$.ajax({
			type : "POST",
			url : URI + 'startUpdProjectInfo.do',
			data:{
				projectName:projectName,
				deptid:deptid,
				teamID:teamID,
				projectcode:projectcode,
				projectLeaderID:projectLeaderID,
				projectID:projectID,
				projectLeader:projectLeader,
                startDate:startDate,
				endDate:endDate
			},
			async : false,
			success : function(data) {
				//alert(data);
				if (data == "0") {// 更新成功
					$("#success01").addClass("box-info-show");
					setTimeout(function() {
						$("#success01").removeClass("box-info-show");
					}, 1500);
					setTimeout(function() {
					window.location.href = URI + "project/projectManagement.html?";//再重新查询一下项目列表
					}, 1500);
				} else {
					$("#error01").addClass("box-info-show");
					setTimeout(function() {
						$("#error01").removeClass("box-info-show");
					}, 15000);
				}
			}
		});
	} else {// 证明用户修改了项目名称或者修改了项目编号，或者二者都进行了修改
		$.ajax({//针对项目名称和项目编号进行验重操作
			type : "POST",
			url : URI + 'cheakProNameOrProCode.do?',
			async : false,
			data : {
				projectName:projectName,
				/*projectcode:projectcode*/
			},
			success : function(data) {
				//alert(data);
				if (data == "0") {// 可以对项目进行更新
					$.ajax({
						type : "POST",
						url : URI + 'startUpdProjectInfo.do',
						data:{
							projectName:projectName,
							deptid:deptid,
							teamID:teamID,
							projectcode:projectcode,
							projectLeaderID:projectLeaderID,
							projectID:projectID,
							projectLeader:projectLeader,
							startDate:startDate,
							endDate:endDate
						},
						async : false,
						success : function(data) {
							//alert(data);
							if (data == "0") {// 更新成功
								$("#success01").addClass("box-info-show");
								setTimeout(function() {
									$("#success01").removeClass("box-info-show");
								}, 1500);
								setTimeout(function() {
								window.location.href = URI + "project/projectManagement.html?";//再重新查询一下项目列表
								}, 1500);
							} else {
								$("#error01").addClass("box-info-show");
								setTimeout(function() {
									$("#error01").removeClass("box-info-show");
								}, 15000);
							}
						}
					});
				} else {// 提示当前项目存在
					$("#error07").addClass("box-info-show");
					setTimeout(function() {
						$("#error07").removeClass("box-info-show");
					}, 1500);
					return false;
				}
			}
		});
	}

}

/**删除项目（更新项目表中isdel状态 ）**/
function delProject(projectName,projectcode){
	if (!confirm("是否删除项目" + projectName + "?")) {
		return false;
	}
	$.ajax({
		type : "POST",
		url :'delProject.do',
		data:{
			projectName:projectName,
			projectcode:projectcode
		},
		async : false,
		success : function(data) {
			if (data == 0) {
				$("#success02").addClass("box-info-show");
				setTimeout(function() {
					$("#success02").removeClass("box-info-show");
				}, 1500);
				setTimeout(function() {
					window.location.href = "projectManagement.html?";//再重新查询一下项目列表
				}, 1500);
			}else{
				$("#error01").addClass("box-info-show");
				setTimeout(function() {
					$("#error01").removeClass("box-info-show");
				}, 15000);
			}
		}
	});
}
// 根据项目名称模糊查询
$('.form-group input.form-ipt').on('input',function(e){
    // 获取输入的项目名称值
	var projectName = $('.form-group input.form-ipt').val();
	$.ajax({
		url:"selectProjectName.do",
		data:{
			projectName:projectName.trim()
		},
		success:function(data){
			$('.table tbody').empty();
			var classpath=$('#classpath').val();
			var str = "";
			for(var i = 0;i<data.length;i++){
				str +="<tr><td width='5%'>"+(i+1)+"</td>";
				str +="<td width='20%'>"+(data[i].projectName==null?'':data[i].projectName)+"</td>";
				str +="<td width='15%'>"+(data[i].projectcode==null?'':data[i].projectcode)+"</td>";
				str +="<td width='15%'>"+(data[i].deptname==null?'':data[i].deptname)+"</td>";
				str +="<td width='15%'>"+(data[i].teamname==null?'':data[i].teamname)+"</td>";
				str +="<td width='15%'>"+(data[i].projectLeader==null?'':data[i].projectLeader)+"</td>";
				str +="<td width='20%'><a href='#' onclick=\"updProjectInfo('"+classpath+"','"+data[i].projectName+"','"+data[i].projectcode+"','"+data[i].projectLeader+"','"+data[i].departmentid+"','"+data[i].teamid+"','"+$("#projectCount").val()+"','"+data[i].projectuserid+"','"+data[i].id+"','"+(data[i].startDate==null?'':data[i].startDate)+"','"+(data[i].endDate==null?'':data[i].endDate)+"');\"><div class='box-table-edit' title='编辑'><i class='icon'></i></div></a><a href='#' onclick=\"delProject('"+(data[i].projectName==null?'':data[i].projectName)+"','"+(data[i].projectcode==null?'':data[i].projectcode)+"');\"><div class='box-table-del' title='删除'><i class='icon'></i></div></a></td></tr>";
						
			}
			$('.table tbody').append(str);
		}
	});
});


