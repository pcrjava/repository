
// 添加
function addHr(){
	window.location.href="forwardHrDetailPage.do";
}

//根据项目名模糊查询
function selectHrInfo(){
	$.ajax({
		url:"selectHrInfo.do",
		data:{
			projectname:$('#projectname').find('option:selected').val()
		},
		success:function(data){
			var a="";
			$('table tbody').empty();
			for(var i=0;i<data.length;i++){
				a+="<tr align='center'><td style='display: none' >"+(data[i].projectid==null?'':data[i].projectid)+"</td>"+
				"<td style='display: none' >"+(data[i].subprojectcode==null?'':data[i].subprojectcode)+"</td>"+ 
				"<td style='display: none' >"+(data[i].projectmanager==null?'':data[i].projectmanager)+"</td>"+
				"<td width='10%'>"+(i+1)+"</td>"+
				"<td  width='10%'>"+(data[i].projectnumber==null?'':data[i].projectnumber)+"</td>"+
				"<td width='25%'>"+(data[i].projectname==null?'':data[i].projectname)+"</td>"+
				"<td  width='25%'>"+(data[i].subprojectname==null?'':data[i].subprojectname)+"</td>"+
				"<td  width='10%'>"+(data[i].leaderNm==null?'':data[i].leaderNm)+"</td>"+
				"<td  width='10%'>"+(data[i].contractvalue==null?'':data[i].contractvalue)+"</td>"+
				"<td style='display: none' >"+(data[i].contractname==null?'':data[i].contractname)+"</td>"+
				"<td  width='10%'><a href='#' onclick='lookDetailHrInfo(this)'>查看</a>"+
				"</td></tr>";					
			}	
			
			$('table tbody').append(a);
		}
	});	
}

//提交表单
function aaa(){

	var projectname =$('#projectname').find("option:selected").val();
	var subprojectcode =$('#subprojectname').find("option:selected").val();
	var projectid =$('#projectid').val();
	var projectnumber =$('#projectnumber').val();
	var projectmanager =$('#projectmanager').val();
	var contractname =$('#contractname').val();
	var contractvalue =$('#contractvalue').val();
	var remark =$('#remark').val();
	
	if (projectname ==""){
		alert("请选择项目名称!");
		return
	}
	if (subprojectcode ==""){
		alert("请选择子项目名称!");
		return
	}
	if (projectnumber ==""){
		alert("请输入项目编号!");
		return
	}
	
	if (projectmanager == 0){
		alert("请输入项目经理!");
		return
	}
	
	if (contractvalue == 0){
		alert("请输入合同金额!");
		return
	}
	
	if (contractname == 0){
		alert("请输入合同名称!");
		return
	}

	/*if (remark ==""){
		alert("请输入描述!");
		return
	}*/
	
	$.ajax({
		type:"Post",
		url:"addHr.do",
		data:$("form").serialize(),
		success:function(data){
			
				if (data>0){
					alert("添加成功!");
					window.location.href="HrPage.html";
				}else{
					alert("添加失败!");
				}
		}
	});
	
}

function lookDetailHrInfo(e){
	var  projectid = $(e.parentNode).parent().find("td").eq(0).text();  // 项目ID
	var  subprojectcode = $(e.parentNode).parent().find("td").eq(1).text();  // 子项目编码
	var  projectnumber = $(e.parentNode).parent().find("td").eq(4).text();  // 项目编码
	var  projectname = $(e.parentNode).parent().find("td").eq(5).text();  // 项目名称
	var  subprojectname = $(e.parentNode).parent().find("td").eq(6).text();  // 子项目名称
	var  LeaderNm = $(e.parentNode).parent().find("td").eq(7).text();  // 项目经理名称
	var  contractvalue = $(e.parentNode).parent().find("td").eq(8).text();  // 合同金额
	var  contractname = $(e.parentNode).parent().find("td").eq(9).text();  // 合同金额
	
	window.location.href = "lookDetailHrInfo.do?subprojectcode="+ subprojectcode+
	"&projectnumber="+ projectnumber+"&projectname="+projectname+"&subprojectname="
	+subprojectname+"&LeaderNm="+LeaderNm+"&contractvalue="+contractvalue+"&contractname="+contractname+"&projectid="+projectid;
}

function deleteHr(e){
	var  id = $(e.parentNode).parent().find("td").eq(0).text();  // id
	var  subprojectcode = $('#subprojectcode').val();  // id
	var  projectid = $('#projectid').val();  // projectid

	if(!confirm("是否删除!")){
	  return 
	}
	
	$.ajax({
		type:"POST",
		url:"deleteHr.do",
		data:{
			id:id,
			subprojectcode:subprojectcode,
			projectid:projectid
		},
		success:function(data){
			if(data>0){
				alert("删除成功!");
				window.location.href="HrPage.html";
			}else{
				alert("删除失败!");
			}
		}
	});
}
