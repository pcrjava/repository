/** 定义全局变量* */
var URI = '';
/** 修改用户信息* */
function updUserInfo(uri, userID, email, name, deptName, teamid, account,
		deptid,usertype,pid) {
	window.location.href = uri + "userM/updUserInfo.html?userID=" + userID
			+ "&email=" + email + "&name=" + encodeURI(encodeURI(name))
			+ "&deptName=" + encodeURI(encodeURI(deptName)) + "&teamid="
			+ teamid + "&account=" + account
			+ "&deptid=" + deptid +"&usertype="+usertype+"&pid="+pid;
}
/** 页面加载时加载部门信息* */
function loadDepInfo(uri) {
	// 获取隐藏域中的部门ID
	var hiddenDeptid = $("#hiddenDeptid").val();
	// alert(hiddenDeptid);
	URI = uri;
	$.ajax({
		type : "POST",
		dataType : "text",
		url : uri + 'loadDepInfo.do',
		async : false,
		dataType : "text",
		success : function(data) {
			// alert(data);
			$(eval("(" + data + ")")).each(
					function() {
						if (this.id == hiddenDeptid) {
							$("#depID").append(
									"<option selected = 'selected' value='"
											+ this.id + "'>" + this.deptName
											+ "</option>");
							loadTeamInfo();
						} else {
							$("#depID").append(
									"<option value='" + this.id + "'>"
											+ this.deptName + "</option>");
						}
					});
		}
	});
	
}

$(function(){
	$.ajax({
		type:"POST",
		url:"selectNameByPid.do",
		data:{
			pid:$("#hiddenPid").val()
		},
		success:function(data){
	
			var aa="<option value='0'>请选择</option>";
	  		
  		    if (data !=""){
  		    	aa+="<option value='"+data.id+"' selected=selected>"+data.name+"</option>"
  		    }
  			$('#pid').append(aa);
			
		}

	});

});
/** 美工JS中赋值* */
/*
 * function loadTeamInfo(nowValue){ //获取选中的值 //alert(nowValue); if(nowValue ==
 * 0){ $("#projectName_team").val('无'); return false; } }
 */
/** 根据部门ID查询对应组信息* */
function loadTeamInfo() {
	// 获取选择部门ID
	var deptid = $("#depID").find("option:selected").val();
	// 获取隐藏域中的组信息
	var teamID = $("#hiddenteamid").val();
	// alert(teamName);
	
	if  (teamID == '0'){
		$("#teamID").append("<option value='0'>无</option>");
	}else{
		$.ajax({
			type : "POST",
			url : URI + 'loadTeamInfo.do?deptid=' + deptid,
			async : false,
			dataType : "text",
			success : function(data) {
				// alert(data);
				$("#teamID").html("");
				$(eval("(" + data + ")")).each(
						function() {
							// alert(this.name);
							if (this.id == teamID) {
								$("#teamID").append(
										"<option selected = 'selected' value='"
												+ this.id + "'>" + this.name
												+ "</option>");
							} else {
								$("#teamID").append(
										"<option value='" + this.id + "'>"
												+ this.name + "</option>");
							}
						});
			}
		});
	}

	if (deptid == 0) {
		$("#teamID").html("<option value='0'>无</option>");
	}

}
/** 英文名和邮箱联动效果* */
$("#accountID").on("input", function(e) {
	$("#emailID").val($(this).val() + '@runlin.cn');
});

/** 开始更新用户信息* */
function startUpdUserInfo() {

	// 正则验证英文名
	var standard = /^([A-Za-z]+\.[A-Za-z]+)$/;
	// 正则验证姓名（汉字）
	var standard_name = /^[\u4E00-\u9FA5]+$/;
	// 获取隐藏域中用户ID
	var UserID = $("#hiddenUserID").val().trim();
	// 获取姓名
	var name = $("#NameID").val().trim();
	// 获取选中的部门ID
	var deptid = $("#depID").find("option:selected").val();
	// 获取选中的组别ID
	var teamID = $("#teamID").find("option:selected").val();
	// 获取英文名称
	var account = $("#accountID").val().trim();
	// 获取邮箱信息
	var email = $("#emailID").val().trim();
	// 获取员工类型
	var usertype= $("#userType").find("option:selected").val();

	if ("" == UserID || null == UserID) {// 校验隐藏域中的UserID
		// $("#sub01").addClass("box-btn-down");
		$("#error01").addClass("box-info-show");
		setTimeout(function() {
			$("#error01").removeClass("box-info-show");
			// $("#sub01").removeClass("box-btn-down");
		}, 1500);
		return false;
	}
	if ("" == name || null == name) {// 校验用户姓名
		$("#error02").addClass("box-info-show");
		setTimeout(function() {
			$("#error02").removeClass("box-info-show");
		}, 1500);
		return false;
	}
	if (name.length > 10) {// 校验用户姓名长度
		$("#error07").addClass("box-info-show");
		setTimeout(function() {
			$("#error07").removeClass("box-info-show");
		}, 1500);
		return false;
	}
	if ("" == deptid || null == deptid) {// 校验部门ID
		$("#error03").addClass("box-info-show");
		setTimeout(function() {
			$("#error04").removeClass("box-info-show");
		}, 1500);
		return false;
	}
	if ("" == teamID || null == teamID) {// 校验组别ID
		$("#error04").addClass("box-info-show");
		setTimeout(function() {
			$("#error04").removeClass("box-info-show");
		}, 1500);
		return false;
	}
	
	// 检验英文名
	if (standard.test(account)) {
	} else {
		$("#error05").addClass("box-info-show");
		$("#sub01").removeClass("box-btn-down");
		setTimeout(function() {
			$("#error05").removeClass("box-info-show");
		}, 1500);
		return false;
	}
	// 检验姓名
	if (standard_name.test(name)) {
	} else {
		$("#error09").addClass("box-info-show");
		$("#sub01").removeClass("box-btn-down");
		setTimeout(function() {
			$("#error09").removeClass("box-info-show");
		}, 1500);
		return false;
	}
	if (account.length > 50) {// 校验用户英文名长度
		$("#error08").addClass("box-info-show");
		setTimeout(function() {
			$("#error08").removeClass("box-info-show");
		}, 1500);
		return false;
	}
	// 获取隐藏域中的英文名，校验英文名称是否改动
	var hiddenaccountID = $("#hiddenaccountID").val().trim();
	//alert(hiddenaccountID == account);
	if (hiddenaccountID == account) { // 此次操作用户没有改变英文名
		// 不需要对英文名去验重，可执行更新操作
		$.ajax({
			type : "POST",
			url : URI + 'startUpdUserInfo.do?UserID=' + UserID + '&name='
					+ encodeURI(encodeURI(name)) + '&deptid=' + deptid
					+ '&teamID=' + teamID + '&account=' + account + '&email='
					+ email +'&usertype='+usertype,
			async : false,
			success : function(data) {
				//alert(data);
				if (data == "0") {// 更新成功
					$("#success01").addClass("box-info-show");
					setTimeout(function() {
						$("#success01").removeClass("box-info-show");
					}, 1500);
					setTimeout(function() {
					window.location.href = URI + "userM/userManagement.html?";//再重新查询一下用户列表
					}, 1500);
				} else {
					$("#error01").addClass("box-info-show");
					setTimeout(function() {
						$("#error01").removeClass("box-info-show");
					}, 15000);
				}
			}
		});
	} else {// 证明用户修改了英文名 ，需要校验新英文名是否存在
		$.ajax({
			type : "POST",
			url : URI + 'cheakaccount.do?account=' + account,
			async : false,
			success : function(data) {
				//alert(data);
				if (data == "0") {// 可以对用户进行更新
					$.ajax({
						type : "POST",
						url : URI + 'startUpdUserInfo.do?UserID=' + UserID
								+ '&name=' + encodeURI(encodeURI(name))
								+ '&deptid=' + deptid + '&teamID=' + teamID
								+ '&account=' + account + '&email=' + email +'&usertype='+usertype,
						async : false,
						success : function(data) {
							//alert(data);
							if (data == "0") {//更新成功
								$("#success01").addClass("box-info-show");
								setTimeout(function() {
									$("#success01").removeClass("box-info-show");
								}, 1500);
								setTimeout(function() {
									window.location.href = URI + "userM/userManagement.html?";//再重新查询一下用户列表
								}, 1500);
							} else {
								$("#error01").addClass("box-info-show");
								setTimeout(function() {
									$("#error01").removeClass("box-info-show");
								}, 15000);
							}
						}
					});
				} else {// 提示当前英文名已被使用
					$("#error06").addClass("box-info-show");
					setTimeout(function() {
						$("#error06").removeClass("box-info-show");
					}, 1500);
					return false;
				}
			}
		});
	}

}

/**删除用户**/
function delUser(UserID,name){
	if (!confirm("是否确认删除" + name + "？")) {
		return false;
	}
	//alert(UserID);
	$.ajax({
		type : "POST",
		url : URI + 'delUser.do?UserID=' + UserID,
		async : false,
		success : function(data) {
			if (data == 0) {
				$("#success02").addClass("box-info-show");
				setTimeout(function() {
					$("#success02").removeClass("box-info-show");
				}, 1500);
				setTimeout(function() {
					window.location.href = "userManagement.html?";//再重新查询一下用户列表
				}, 1500);
			}else{
				$("#error01").addClass("box-info-show");
				setTimeout(function() {
					$("#error01").removeClass("box-info-show");
				}, 15000);
			}
		}
	});
}

/*
 *  重置密码
 * @author changrui.pan
 */  
  function ResetUserPwd(userid){
	if(!confirm("是否重置密码为  ABCabc123?")){
		return false;
	}
	
	$.ajax({
		url:"ResetUserPwd.do",
		data:{
			userid:userid
		}, 
		success:function(data){
		   if (data == 1){
			   alert("重置成功!");
		   }else{
			   alert("重置失败!");
		   }
		}
	});

  }
  
//检索出对应组组员
  function loadEmployeeNm(e){
  	var teamid = $(e).find("option:selected").val();
  	var pid = $('#hiddenPid').val();
  	$.ajax({
  		type:"post",
  		url:"selectEmployeeNm.do",
  		data:{
  			teamid:teamid
  		},
  		success:function(data){
  			var aa="<option value='0'>请选择</option>";
  		
  			for(var i= 0;i<data.length;i++){
  				 aa+= "<option value='"+data[i].id+"'>"+data[i].name+"</option>";
  			}
  			$(e).parent().next().find("select#pid").empty();
  			$(e).parent().next().find("select#pid").append(aa);
  		}	
  	});
  	
  }

