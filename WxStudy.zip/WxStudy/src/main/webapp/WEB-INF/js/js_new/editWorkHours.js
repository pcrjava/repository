/*
\ * 工时列表JS文件
 * 日期: 2017-02-22
 * By changrui.pan
 * 
*/
$(document).ready(function(){
	var maxTime =new Date();
	var begintime = $('#beginTime').val();
	
			//结束时间
			$('#endTime').datetimepicker({
				startDate: begintime,
				language: 'zh-CN',
				format: 'yyyy-mm-dd hh:ii',
				endDate:maxTime,
				minuteStep: 30,
				showMeridian: true,
				autoclose: true
			});
			
            // 提交按钮
			$('div.time-main .time-ul .list .box-btn-save').on('click',function(){
				 
		     // 获取工时模块信息
			 var b = editWorkinghoursLoop(); 
				//var b =workinghoursLoop.editWorkinghoursLoop();
			 
			 if(b==false){
				 return false;
			 }
			 
             $.ajax({
            	 type:"post",
            	 url:"updateWorkingHours.do",
            	 data:{
            		 a:b[0],
					 b:b[1],
            		 beginTime:$("#oldBegintime").val(),
            		 endTime:$("#oldEndtime").val(),
            		 projectid:$("#oldProjectid").val(),
            		 workTypeid:$("#oldWorkTypeid").val(),
            		 userid:$("#oldUserid").val()
            	 },
            	 success:function(data){
            		if (data==1){
            			alert("更新成功^_^!");
            			$(this).addClass("box-btn-down");
            			// 跳到工时列表页面
            			window.location.href="workingHours.html";
            		} else{
            			alert("更新失败!");
            		}
            	 }	 
             });
			});
			
			// 时间差
			$('div.time-main .time-ul .list .begin-time').add($('div.time-main .time-ul .list .end-time')).on('change',function(){
				
				var beginTime=$('div.time-main .time-ul .list .begin-time').val();  //开始时间
				var endTime=$('div.time-main .time-ul .list .end-time').val();    //结束时间
				
				var time1 = beginTime.toString(); 
				var time2 = endTime.toString();  
				var timestart = new Date(Date.parse(time1.replace(/-/g,"/"))).getTime(); 
				var timeend = new Date(Date.parse(time2.replace(/-/g,"/"))).getTime();
				var datecomparent=timeend-timestart;  //差的毫秒数
				var time3 = time1.substring(0,10)+" 11:30";
				var time4 = time1.substring(0,10)+" 12:30";
				var restTimeBegin = new Date(Date.parse(time3.replace(/-/g,"/"))).getTime();  
				var restTimeEnd = new Date(Date.parse(time4.replace(/-/g,"/"))).getTime();  
			
				// var date3=new Date(endTime).getTime()-new Date(beginTime).getTime();  //时间差的毫秒数
				
			    // 比较开始时间和结束时间
				if (datecomparent<0)
				{
					alert("结束时间必须大于开始时间!");
					$('div.time-main .time-ul .list .end-time').val('');
					$('div.time-main .time-ul .list #timedif').text('');
					return false;
				}
			
				if ((timestart<restTimeBegin||timestart==restTimeBegin) && (timeend>restTimeEnd||timeend==restTimeEnd)){
					var hours=(datecomparent-3600*1000)/(3600*1000);
					$('div.time-main .time-ul .list #timedif').html(hours);
				}else{
					//计算出小时数
					var hours=datecomparent/(3600*1000);
					$('div.time-main .time-ul .list #timedif').html(hours);
				}
				
				
			});
		});
   
   // 获取当前时间并且格式化 成 YYYY-MM-DD HH:mm:ss
		function getCurrentDate(){
			 var date = new Date();
			    var seperator1 = "-";
			    var seperator2 = ":";
			    var month = date.getMonth() + 1;
			    var strDate = date.getDate();
			    if (month >= 1 && month <= 9) {
			        month = "0" + month;
			    }
			    if (strDate >= 0 && strDate <= 9) {
			        strDate = "0" + strDate;
			    }
			    var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate
			            + " " + date.getHours() + seperator2 + date.getMinutes()
			            + seperator2 + date.getSeconds();
			    return currentdate;
		}
	
		// 循环工时模块
		function editWorkinghoursLoop(){
			
			var array=new Array(2);
			var c="";
			var a="";
			
			 var projectid = $('div.time-main .time-ul .list #subprojectname').find("option:selected").val();
			var worktypeVal = $('div.time-main .time-ul .list #workType').find('option:selected').text();
			 var worklog =$('div.time-main .time-ul .list #workLog').val().replace(/'/g,'\\\'').replace(/\n/g,'\\n');
			
				// 验证页面元素非空
				if($('div.time-main .time-ul .list #timedif').html()=='0'||$('div.time-main .time-ul .list #timedif').html()==''){
					alert("工时不能为空!");
					a="";
					return false;
				}else if($('div.time-main .time-ul .list #beginTime').val()==''){
					alert("开始时间不能为空!");
					a="";
					return false;
				}else if($('div.time-main .time-ul .list #endTime').val()==''){
					alert("结束时间不能为空!");
					a="";
					return false;
				}else if($('div.time-main .time-ul .list #projectname').val()==''){
					alert("项目名称不能为空!");
					a="";
					return false;
				}else if($('div.time-main .time-ul .list #subprojectname').val()=='0'){
					alert("子项目名不能为空!");
					a="";
					return false;
				}else if($('div.time-main .time-ul .list #workType').val()==''){
					alert("工作类型不能为空!");
					a="";
					return false;
				}else if($('div.time-main .time-ul .list #workLog').val().replace(/\n/g,"").trim()==''){
					alert("工作内容不能为空!");
					a="";
					return false;
				}
				
				 if('需求文档预审'==worktypeVal){
					 c="[{'workdate':'"+$('div.time-main .time-ul .list #beginTime').val().substring(0,10)+
	                 "','beginTime':'"+$('div.time-main .time-ul .list #beginTime').val()+
	                 "','timedif':'0"+
					   "','endTime':'"+$('div.time-main .time-ul .list #endTime').val()+
					   "','projectid':'"+projectid+
					   "','workTypeid':'"+$('div.time-main .time-ul .list #workType').val()+
					   "','numname':'需求预审问题数量"+
					   "','num':'"+worklog+"'}]";
					 a="{'id':'"+$('#workTypeid').val()+"','workdate':'"+$('div.time-main .time-ul .list #beginTime').val().substring(0,10)+
	                 "','beginTime':'"+$('div.time-main .time-ul .list #beginTime').val()+
	                 "','timedif':'"+$('div.time-main .time-ul .list #timedif').html()+
					   "','endTime':'"+$('div.time-main .time-ul .list #endTime').val()+
					   "','projectid':'"+projectid+
					   "','workTypeid':'"+$('div.time-main .time-ul .list #workType').val()+
					   "','workLog':'"+$('div.time-main .time-ul .list #workLog').val().replace(/'/g,'\\\'').replace(/\n/g,'\\n')+"'}";	 
				 }else if ('设计系统测试用例'==worktypeVal){
					 c="[{'workdate':'"+$('div.time-main .time-ul .list #beginTime').val().substring(0,10)+
	                 "','beginTime':'"+$('div.time-main .time-ul .list #beginTime').val()+
	                 // "','timedif':'"+$('div.time-main .time-ul .list #timedif').eq(index).html()+
	                 "','timedif':'0"+
					   "','endTime':'"+$('div.time-main .time-ul .list #endTime').val()+
					   "','projectid':'"+projectid+
					   "','workTypeid':'"+$('div.time-main .time-ul .list #workType').val()+
					   "','numname':'设计测试用例数量"+
					   "','num':'"+worklog+"'}]"; 
					 a="{'id':'"+$('#workTypeid').val()+"','workdate':'"+$('div.time-main .time-ul .list #beginTime').val().substring(0,10)+
	                 "','beginTime':'"+$('div.time-main .time-ul .list #beginTime').val()+
	                 "','timedif':'"+$('div.time-main .time-ul .list #timedif').html()+
					   "','endTime':'"+$('div.time-main .time-ul .list #endTime').val()+
					   "','projectid':'"+projectid+
					   "','workTypeid':'"+$('div.time-main .time-ul .list #workType').val()+
					   "','workLog':'"+$('div.time-main .time-ul .list #workLog').val().replace(/'/g,'\\\'').replace(/\n/g,'\\n')+"'}";

				 }else if ('修改系统测试用例'==worktypeVal){
					 c="[{'workdate':'"+$('div.time-main .time-ul .list #beginTime').val().substring(0,10)+
	                 "','beginTime':'"+$('div.time-main .time-ul .list #beginTime').val()+
	                 // "','timedif':'"+$('div.time-main .time-ul .list #timedif').eq(index).html()+
	                 "','timedif':'0"+
					   "','endTime':'"+$('div.time-main .time-ul .list #endTime').val()+
					   "','projectid':'"+projectid+
					   "','workTypeid':'"+$('div.time-main .time-ul .list #workType').val()+
					   "','numname':'修改测试用例数量"+
					   "','num':'"+worklog+"'}]"; 
					 a="{'id':'"+$('#workTypeid').val()+"','workdate':'"+$('div.time-main .time-ul .list #beginTime').val().substring(0,10)+
	                 "','beginTime':'"+$('div.time-main .time-ul .list #beginTime').val()+
	                 "','timedif':'"+$('div.time-main .time-ul .list #timedif').html()+
					   "','endTime':'"+$('div.time-main .time-ul .list #endTime').val()+
					   "','projectid':'"+projectid+
					   "','workTypeid':'"+$('div.time-main .time-ul .list #workType').val()+
					   "','workLog':'"+$('div.time-main .time-ul .list #workLog').val().replace(/'/g,'\\\'').replace(/\n/g,'\\n')+"'}"; 
				 }else if ('随机测试'==worktypeVal){
					 c="[{'workdate':'"+$('div.time-main .time-ul .list #beginTime').val().substring(0,10)+
	                 "','beginTime':'"+$('div.time-main .time-ul .list #beginTime').val()+
	                 // "','timedif':'"+$('div.time-main .time-ul .list #timedif').eq(index).html()+
	                 "','timedif':'0"+
					   "','endTime':'"+$('div.time-main .time-ul .list #endTime').val()+
					   "','projectid':'"+projectid+
					   "','workTypeid':'"+$('div.time-main .time-ul .list #workType').val()+
					   "','numname':'提交BUG数量"+
					   "','num':'"+worklog+"'}]"; 
					 a="{'id':'"+$('#workTypeid').val()+"','workdate':'"+$('div.time-main .time-ul .list #beginTime').val().substring(0,10)+
	                 "','beginTime':'"+$('div.time-main .time-ul .list #beginTime').val()+
	                 "','timedif':'"+$('div.time-main .time-ul .list #timedif').html()+
					   "','endTime':'"+$('div.time-main .time-ul .list #endTime').val()+
					   "','projectid':'"+projectid+
					   "','workTypeid':'"+$('div.time-main .time-ul .list #workType').val()+
					   "','workLog':'"+$('div.time-main .time-ul .list #workLog').val().replace(/'/g,'\\\'').replace(/\n/g,'\\n')+"'}";
				 }else if ('接收测试'==worktypeVal){
					 c="[{'workdate':'"+$('div.time-main .time-ul .list #beginTime').val().substring(0,10)+
	                 "','beginTime':'"+$('div.time-main .time-ul .list #beginTime').val()+
	                 "','timedif':'0"+
					   "','endTime':'"+$('div.time-main .time-ul .list #endTime').val()+
					   "','projectid':'"+projectid+
					   "','workTypeid':'"+$('div.time-main .time-ul .list #workType').val()+
					   "','numname':'执行测试用例数量 "+
					   "','num':'"+worklog.substring(0,worklog.indexOf(','))+"'},"; 
					 
					 c=c+"{'workdate':'"+$('div.time-main .time-ul .list #beginTime').val().substring(0,10)+
	                 "','beginTime':'"+$('div.time-main .time-ul .list #beginTime').val()+
	                 "','timedif':'0"+
					   "','endTime':'"+$('div.time-main .time-ul .list #endTime').val()+
					   "','projectid':'"+projectid+
					   "','workTypeid':'"+$('div.time-main .time-ul .list #workType').val()+
					   "','numname':'提交BUG数量"+
					   "','num':'"+worklog.substring(worklog.indexOf(',')+1)+"'}]"; 
					 
					 a="{'id':'"+$('#workTypeid').val()+"','workdate':'"+$('div.time-main .time-ul .list #beginTime').val().substring(0,10)+
	                 "','beginTime':'"+$('div.time-main .time-ul .list #beginTime').val()+
	                 "','timedif':'"+$('div.time-main .time-ul .list #timedif').html()+
					   "','endTime':'"+$('div.time-main .time-ul .list #endTime').val()+
					   "','projectid':'"+projectid+
					   "','workTypeid':'"+$('div.time-main .time-ul .list #workType').val()+
					   "','workLog':'"+$('div.time-main .time-ul .list #workLog').val().replace(/'/g,'\\\'').replace(/\n/g,'\\n')+"'}"; 
				 }else if ('执行系统测试'==worktypeVal){
					 c="[{'workdate':'"+$('div.time-main .time-ul .list #beginTime').val().substring(0,10)+
	                 "','beginTime':'"+$('div.time-main .time-ul .list #beginTime').val()+
	                 "','timedif':'0"+
					   "','endTime':'"+$('div.time-main .time-ul .list #endTime').val()+
					   "','projectid':'"+projectid+
					   "','workTypeid':'"+$('div.time-main .time-ul .list #workType').val()+
					   "','numname':'执行测试用例数量 "+
					   "','num':'"+worklog.substring(0,worklog.indexOf(','))+"'},"; 
					 
					 c=c+"{'workdate':'"+$('div.time-main .time-ul .list #beginTime').val().substring(0,10)+
	                 "','beginTime':'"+$('div.time-main .time-ul .list #beginTime').val()+
	                 "','timedif':'0"+
					   "','endTime':'"+$('div.time-main .time-ul .list #endTime').val()+
					   "','projectid':'"+projectid+
					   "','workTypeid':'"+$('div.time-main .time-ul .list #workType').val()+
					   "','numname':'提交BUG数量"+
					   "','num':'"+worklog.substring(worklog.indexOf(',')+1)+"'}]"; 
					 
					 a="{'id':'"+$('#workTypeid').val()+"','workdate':'"+$('div.time-main .time-ul .list #beginTime').val().substring(0,10)+
	                 "','beginTime':'"+$('div.time-main .time-ul .list #beginTime').val()+
	                 "','timedif':'"+$('div.time-main .time-ul .list #timedif').html()+
					   "','endTime':'"+$('div.time-main .time-ul .list #endTime').val()+
					   "','projectid':'"+projectid+
					   "','workTypeid':'"+$('div.time-main .time-ul .list #workType').val()+
					   "','workLog':'"+$('div.time-main .time-ul .list #workLog').val().replace(/'/g,'\\\'').replace(/\n/g,'\\n')+"'}";
				 }else if ('回归缺陷'==worktypeVal){
					 c="[{'workdate':'"+$('div.time-main .time-ul .list #beginTime').val().substring(0,10)+
	                 "','beginTime':'"+$('div.time-main .time-ul .list #beginTime').val()+
	                 "','timedif':'0"+
					   "','endTime':'"+$('div.time-main .time-ul .list #endTime').val()+
					   "','projectid':'"+projectid+
					   "','workTypeid':'"+$('div.time-main .time-ul .list #workType').val()+
					   "','numname':'回归BUG数量 "+
					   "','num':'"+worklog+"'}]"; 
					 
					 a="{'id':'"+$('#workTypeid').val()+"','workdate':'"+$('div.time-main .time-ul .list #beginTime').val().substring(0,10)+
	                 "','beginTime':'"+$('div.time-main .time-ul .list #beginTime').val()+
	                 "','timedif':'"+$('div.time-main .time-ul .list #timedif').html()+
					   "','endTime':'"+$('div.time-main .time-ul .list #endTime').val()+
					   "','projectid':'"+projectid+
					   "','workTypeid':'"+$('div.time-main .time-ul .list #workType').val()+
					   "','workLog':'"+$('div.time-main .time-ul .list #workLog').val().replace(/'/g,'\\\'').replace(/\n/g,'\\n')+"'}";
				 }else{
					 
					 if($('div.time-main .time-ul .list #workLog').val().replace(/\n|\s/g,"").trim().length<5){
							alert("工作内容长度不能小于5个字!");
							a="";
							return false;
						}
							 
					 a="{'id':'"+$('#workTypeid').val()+"','workdate':'"+$('div.time-main .time-ul .list #beginTime').val().substring(0,10)+
	                 "','timedif':'"+$('div.time-main .time-ul .list #timedif').html()+
	                 "','beginTime':'"+$('div.time-main .time-ul .list #beginTime').val()+
					   "','endTime':'"+$('div.time-main .time-ul .list #endTime').val()+
					   "','projectid':'"+projectid+
					   "','workTypeid':'"+$('div.time-main .time-ul .list #workType').val()+
					   "','workLog':'"+$('div.time-main .time-ul .list #workLog').val().replace(/'/g,'\\\'').replace(/\n/g,'\\n')+"'}";
				 }
				 
				 array[0]=a;
				 array[1]=c;
				
			return array;
		}
		
	// 根据项目名查出子项目
	function selectSubProject1(e){
		var a = $(e).find("option:selected").val();
		//alert(a.substring(a.indexOf(';')+1))
		$.ajax({
			url:"selectSubProjectList.do",
			data:{
				projectname:a.substring(0,a.indexOf(';'))
			},
			success:function(data){
				var a="";
				$(e).parent().next().find('#subprojectname:first').find("option").remove();
				$(e).parent().next().find('#subprojectname:first').append("<option value='0'>请选择</option>");
				for (var i=0;i<data.length;i++){
					a+="<option value="+data[i].id+">"+data[i].subprojectname+"</option>";
				}
				$(e).parent().next().find('#subprojectname:first').append(a);
			}
			
		});
	}