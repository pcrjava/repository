/*
\ * 工时图表JS文件
 * 日期: 2017-04-25
 * By changrui.pan
 * 
*/
$(function(){
	   
	if ($("#selectStatus").val()==""){
		var currentDate=getCurrentDate().substring(0,10);
		
		// 获取前一个月日期
		NextNow = addDate(new Date(),-1);
		
		var currentYear = new Date().getFullYear();
		var preMonth =new Date().getMonth();
		var pretDay =new Date().getDate()-1;
		var currentMonth = new Date().getMonth()+1;
		
		if (preMonth<10){
			preMonth="0"+preMonth;
		}
		
		if (currentMonth<10){
			currentMonth="0"+currentMonth;
		} 
		
		if (pretDay<10){
			pretDay="0"+pretDay;
		}
		
		$("#endTime").attr('value',currentYear+'-'+currentMonth+'-'+ pretDay);
		
		$('#beginTime').attr("value",currentYear+'-'+preMonth+'-'+ pretDay);
		
		 document.getElementById('from1').submit();
	}
	
	// 根据合计值降序
	var rowLen = $("#rowLen").val();
	var oTab=document.getElementById('table2');   //获取表格
	var arr=[];     //定义一个空的数组 
	
	var tdNum=$("#table2 tbody tr:first")[0].childElementCount-2 ;//行合计所在的单元格索引	
	
	 for(var i=0;i<oTab.tBodies[0].rows.length;i++){  
         arr[i]=oTab.tBodies[0].rows[i];     //把表格的所有行数都存到arr数组里  
     }  
	 arr.sort(function(tr1,tr2){     //这里传入两个参数用于比较  
         var n1=parseInt(tr1.cells[tdNum].innerHTML);    //这里取出表格里的行的第一个单元格，对应ID所在的单元格  
         var n2=parseInt(tr2.cells[tdNum].innerHTML);  
         return n2-n1;     
     });  
	 
	 for(var i=0;i<arr.length;i++){  
         oTab.tBodies[0].appendChild(arr[i]);    //把上面sort排好序的元素一行行地按顺序重新插入到表格中  
     }  
	
});
//查询
$("#select").on('click',function(){
	
	//非空验证
	var begintime = $("#beginTime").val(); // 开始时间
	var endtime = $("#endTime").val(); // 结束时间
	
	if(begintime==''){
		alert("开始时间不能为空");
		return false;
	}
	if(endtime==''){
		alert("结束时间不能为空");
		return false;
	}
	
	$("#selectStatus").val(1);
	$("#from1").submit();

});

//表格产生滚动条

$('div.box-table1-con').css("height","200px");
$('div.box-table1-con').mCustomScrollbar({
	theme: "minimal-dark"
});

/*$('div.newbox').css("height","700px");
$('div.newbox').mCustomScrollbar({
	theme: "minimal-dark"
});*/

var pageHeight = $(window).height(); //屏幕高度
var pageBoxHeight = pageHeight - $('div.page-box-con')[0].offsetHeight-145;//BOX高度
$('div#tab1div1').css("height",pageBoxHeight);
$('div#tab1div1').mCustomScrollbar({
	theme: "minimal-dark"
});

// 部门一级联动
$("#department").on('change',function(){
	var deptid= $("#department").val(); // 部门ID
	var t="";
	$.ajax({
		method:"post",
		url:"selectProject1.do",
		data:{
			deptid:deptid
		},
		success:function(data){
			$("#projectNm").empty();
			$("#projectNm").append("<option value=''>全选</option>");
		   for(var i =0; i<data.length;i++){
			   t+="<option value="+data[i].id+">"+data[i].projectName+"</option>"
		   } 
		   $("#projectNm").append(t);
		}
	});
});

// 导出
function exportProject1(){
    // 获取当前时间
    var currentDate=getCurrentDate().substring(0,10);
	method1('tab1div',currentDate+"_工时项目统计.xls");
}