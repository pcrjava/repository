/*------------------------------------------------按选择不同时间段显示时间区间 -------------------------------------------------------------------*/
		//获取当前日期
		 var curDate = new Date();
		 //获取当前年
		 var year = curDate.getFullYear();
		 //获取当前月
		 var month = curDate.getMonth() + 1; 
		 //获取当前日
		 var day = curDate.getDate();
		//获取当前周
		 var week = theWeek(year,month,day);
/*-------------------------------------------------------定义全局变量---------------------------------------------------------------------*/	
	//按选择不同时间段显示时间区间
	function cheak_Time_Unit(){
		
		
		
		 //获取选择显示时间段的类型 
		 var type = $("#TimeUnit").val();
		 //如果时间单位不是日的情况下  都需要获取当前年 循环到select下拉列表中
		 //获取当前年份，前四年的数据集（方法）
		 //如果type=2 证明选择的时间单位是周  需要显示年份和周的时间区间 隐藏日和月的时间区间 并获取当前年份循环插入select，计算当前日期是一年以来第几周依次循环插入到select中
		 if (type == 2) {
			 
			 //显示周和年控件
			 $("#YearSeMonth").show(); 
			 $("#labyear").show();
			 $("#WeekLiSeStar").show();
			 $("#WeekLiSeEnd").show();
			 $("#labweek").show();
			 
			//开始时间和结束时间隐藏
				$("#labbegindate").hide();
				$("#labenddate").hide();
				$("#beginTime").hide();
				$("#endTime").hide();
			//季度空间需要隐藏
				$("#q").hide();	
				$("#labq").hide();
			//隐藏月份	
				$("#MonthSeStar").hide();
				$("#MonthSeEnd").hide();
				$("#labmonth").hide();
				
			 
		//type为1的时候只需要显示日期的开始时间和结束时间 隐藏以时间单位为2和3的时间单位	 
		}else if(type == 1){
			//控制年份和季度控件隐藏
			$("#q").hide();	
			$("#labq").hide();
			$("#YearSeMonth").hide(); 
			$("#labyear").hide();
			//开始日期和结束日期显示
			$("#labbegindate").show();
			$("#labenddate").show();
			$("#beginTime").show();
			$("#endTime").show();
			//隐藏月份	
			$("#MonthSeStar").hide();
			$("#MonthSeEnd").hide();
			$("#labmonth").hide();
			//隐藏周
			$("#WeekLiSeStar").hide();
			 $("#WeekLiSeEnd").hide();
			 $("#labweek").hide();
			 var dateStar = $("#hidden_begindate").val().trim();
			 var dateEnd = $("#hidden_enddate").val().trim();
			 $("#beginTime").val(dateStar);
			 $("#endTime").val(dateEnd);
			 
		//隐藏以日和周为时间单位的查询条件显示时间单位一月的查询条件	
		}else if(type== 3){
			//显示年和月控件
			 $("#YearSeMonth").show(); 
			 $("#labyear").show();
			 $("#MonthSeStar").show();
			 $("#MonthSeEnd").show();
			 $("#labmonth").show();
			 
			//开始时间和结束时间隐藏
				$("#labbegindate").hide();
				$("#labenddate").hide();
				$("#beginTime").hide();
				$("#endTime").hide();
			//季度空间需要隐藏
				$("#q").hide();	
				$("#labq").hide();
			//隐藏月份	
				$("#labweek").hide();
				 $("#WeekLiSeStar").hide();
				 $("#WeekLiSeEnd").hide();
				//隐藏周
					$("#WeekLiSeStar").hide();
					 $("#WeekLiSeEnd").hide();
					 $("#labweek").hide();
			 
		}else if(type==4){
			//控制季度和年控件显示
			$("#q").show();	
			$("#labq").show();
			$("#YearSeMonth").show(); 
			$("#labyear").show();
			
			
			//开始时间和结束时间隐藏
			$("#labbegindate").hide();
			$("#labenddate").hide();
			$("#beginTime").hide();
			$("#endTime").hide();
			
			//隐藏月份	
			$("#MonthSeStar").hide();
			$("#MonthSeEnd").hide();
			$("#labmonth").hide();
			
			//隐藏周
			$("#WeekLiSeStar").hide();
			 $("#WeekLiSeEnd").hide();
			 $("#labweek").hide();
		}
		 cheak_YearSe_Week();
		 
		
			
			
			//表单产生滚动条
			$('div.box-form-scroll, div.box-list-scroll').mCustomScrollbar({
				theme: "minimal-dark"
			});
			
			
			
	}
/*******************获取当前日期为第几周STRAT*************************/
	function theWeek(a,b,c){
		var d1 = new Date(a, b-1, c), d2 = new Date(a, 0, 1), 
	    d = Math.round((d1 - d2) / 86400000); 
	    return Math.ceil((d + ((d2.getDay() + 1) - 1)) / 7); 
	}
	
/*******************获取当前日期为第几周End***************************/	
/*----------------------------------------清空查询条件js方法-----------------------------------------------------*/	
/*----------------------------------------清空查询条件 ---------------------------------------------------------*/
	//清空方法
	function clea(){
		$("#larger_region_name").val('');
		$("#small_region_name").val('');
		$("#dealer_name").val('');
		$("#source_media").val('');
		$("#KPI").val('1');
		$("#TimeUnit").val('1');
		$("#begindate").val('');
		$("#enddate").val('');
		cheak_Time_Unit();
	}
/*------------------------------------End --------------------------------------------------------------------*/
/*------------------------------------onchange事件-----------------------------------------------------------*/	
	//时间单位为周时，年份的onchange事件
	function cheak_YearSe_Week(){
		var YearSeWeek = $("#YearSeMonth").val().trim();
		var weekStar = $("#hidden_beginWeek").val().trim();
		var weekEnd = $("#hidden_endWeek").val().trim();
		if (YearSeWeek == "" || YearSeWeek == "0") {
			$("#WeekLiSeStar").html("");
			$("#WeekLiSeEnd").html("");
			$("#WeekLiSeStar").html("<option value=''>请选择</option>");
			$("#WeekLiSeEnd").html("<option value=''>请选择</option>");
		}else{
			$("#WeekLiSeStar").html("");
			$("#WeekLiSeEnd").html("");
			$("#WeekLiSeStar").html("<option value=''>请选择</option>");
			$("#WeekLiSeEnd").html("<option value=''>请选择</option>");
			
			 for ( var j = 1; j <= week; j++) {
				
				 if(weekStar==j){						
						 $("#WeekLiSeStar").append("<option value='"+j+"'selected='selected'>"+"第"+j+"周"+"</option>");
					}else{
						 $("#WeekLiSeStar").append("<option value='"+j+"'>"+"第"+j+"周"+"</option>");
					}
				 if(weekEnd==j){						
					 $("#WeekLiSeEnd").append("<option value='"+j+"'selected='selected'>"+"第"+j+"周"+"</option>");
				 }else{
					 $("#WeekLiSeEnd").append("<option value='"+j+"'>"+"第"+j+"周"+"</option>");
				 }
			}
		}
		
		
		var YearSeMonth = $("#YearSeMonth").val().trim();
		var MonthSeStar = $("#hidden_beginMonth").val().trim();
		var MonthSeEnd = $("#hidden_endMonth").val().trim();
		if (YearSeMonth == "" || YearSeMonth == "0") {
			$("#MonthSeStar").html("");
			$("#MonthSeEnd").html("");
			$("#MonthSeStar").html("<option value=''>请选择</option>");
			$("#MonthSeEnd").html("<option value=''>请选择</option>");
		}else{
			$("#MonthSeStar").html("");
			$("#MonthSeEnd").html("");
			$("#MonthSeStar").html("<option value=''>请选择</option>");
			$("#MonthSeEnd").html("<option value=''>请选择</option>");
			for ( var k = 1; k <= month ; k++) {
				if(MonthSeStar==k){
					$("#MonthSeStar").append("<option value='"+k+"' selected='selected' >"+"第"+k+"月"+"</option>");
				}else{
						$("#MonthSeStar").append("<option value='"+k+"' >"+"第"+k+"月"+"</option>");
				}
				if(MonthSeEnd==k){
					$("#MonthSeEnd").append("<option value='"+k+"' selected='selected' >"+"第"+k+"月"+"</option>");
				}else{
					$("#MonthSeEnd").append("<option value='"+k+"'>"+"第"+k+"月"+"</option>");	
				}
				 
				 
			}
		}
	}
	
	//时间单位为周的时候对周的开始时间和结束时间做约束，开始时间不得小于结束时间
	function cheak_WeekLiSeStar(){
		var WeekLiSeStar = $("#WeekLiSeStar").val().trim();
		var WeekLiSeEnd = $("#WeekLiSeEnd").val().trim();
		if (parseInt(WeekLiSeStar) + 24 >= week) {
			if (WeekLiSeEnd == "") {
				$("#WeekLiSeEnd").html("");
				$("#WeekLiSeEnd").html("<option value=''>请选择</option>");
				for ( var j = parseInt(WeekLiSeStar); j <= week; j++) {
					$("#WeekLiSeEnd").append("<option value='"+j+"'>"+"第"+j+"周"+"</option>");
				}
			}
		}else{
				$("#WeekLiSeEnd").html("");
				$("#WeekLiSeEnd").html("<option value=''>请选择</option>");
				for ( var i = parseInt(WeekLiSeStar); i <= (parseInt(WeekLiSeStar) + 24); i++) {
					$("#WeekLiSeEnd").append("<option value='"+i+"'>"+"第"+i+"周"+"</option>");
			}
		}
		if (WeekLiSeStar != "" && WeekLiSeEnd != "") {
			if (parseInt(WeekLiSeStar) > parseInt(WeekLiSeEnd)) {
				alert("开始时间不能大于结束时间");
				$("#WeekLiSeStar").get(0).selectedIndex = 0; 
			}
		}
	};
	
	//时间单位为周的时候对周的开始时间和结束时间做约束，开始时间不得小于结束时间
	function cheak_WeekLiSeEnd(){
		var WeekLiSeStar = $("#WeekLiSeStar").val().trim();
		var WeekLiSeEnd = $("#WeekLiSeEnd").val().trim();
		if (parseInt(WeekLiSeEnd) - 24 > 0) {
			if (WeekLiSeStar == "") {
				$("#WeekLiSeStar").html("");
				$("#WeekLiSeStar").html("<option value=''>请选择</option>");
				for ( var j = parseInt(WeekLiSeEnd-24); j <= WeekLiSeEnd; j++) {
					$("#WeekLiSeStar").append("<option value='"+j+"'>"+"第"+j+"周"+"</option>");
				}
			}
		}else{
			if (WeekLiSeStar == "") {
				$("#WeekLiSeStar").html("");
				$("#WeekLiSeStar").html("<option value=''>请选择</option>");
				for ( var i = 1; i <= parseInt(WeekLiSeEnd); i++) {
					$("#WeekLiSeStar").append("<option value='"+i+"'>"+"第"+i+"周"+"</option>");
				}
			}
		}
		
		if (WeekLiSeStar != "" && WeekLiSeEnd != "") {
			if (parseInt(WeekLiSeStar) > parseInt(WeekLiSeEnd)) {
				alert("结束时间不能小于开始时间");
				$("#WeekLiSeEnd").get(0).selectedIndex = 0; 
			}
		}
		
		

	};
	
/******************************************************************/
/**************************设置开始时间和结束时间****************************************/	
	
	//时间单位为周的时候对周的开始时间和结束时间做约束，开始时间不得小于结束时间
	function cheak_Date(){
		var dateSeStar = $("#beginTime").val().trim();
		var dateSeEnd = $("#endTime").val().trim();
		
		var stary = dateSeStar.substr(0,4);
		var endy = dateSeEnd.substr(0,4);
		
		if (dateSeStar != "" && dateSeEnd != "") {
			if (dateSeStar > dateSeEnd) {
				alert("开始时间不能大于结束时间!");
				$("#beginTime").val("");
				$("#endTime").val("");
			}else if(stary != endy){
				alert("开始时间和结束时间必须在同一年!");
				$("#beginTime").val("");
				$("#endTime").val("");
			}
			
			
		} 
	};
	
	
/***************************************************************/	
	//时间单位为月时，年份的onchange事件
	function cheak_YearSe_Month(){
		var YearSeMonth = $("#YearSeMonth").val().trim();
		if (YearSeMonth == "") {
			$("#MonthSeStar").html("");
			$("#MonthSeEnd").html("");
			$("#MonthSeStar").html("<option value=''>请选择</option>");
			$("#MonthSeEnd").html("<option value=''>请选择</option>");
		}else{
			$("#MonthSeStar").html("");
			$("#MonthSeEnd").html("");
			$("#MonthSeStar").html("<option value=''>请选择</option>");
			$("#MonthSeEnd").html("<option value=''>请选择</option>");
			for ( var k = 1; k <= month ; k++) {
				 $("#MonthSeStar").append("<option value='"+k+"'>"+"第"+k+"月"+"</option>");
				 $("#MonthSeEnd").append("<option value='"+k+"'>"+"第"+k+"月"+"</option>");	
			}
		}
	}
	//时间单位为月的时候对月份开始时间和结束时间做约束，开始时间不得小于结束时间
	function cheak_MonthSeStar(){
		var MonthSeStar = $("#MonthSeStar").val().trim();
		var MonthSeEnd = $("#MonthSeEnd").val().trim();
		if (MonthSeStar != "" && MonthSeEnd != "") {
			if (parseInt(MonthSeStar) > parseInt(MonthSeEnd)) {
				alert("开始时间不能大于结束时间");
				$("#MonthSeStar").get(0).selectedIndex = 0; 
			}
		}
	};
	
	//时间单位为月的时候对月份开始时间和结束时间做约束，开始时间不得小于结束时间
	function cheak_MonthSeEnd(){
		var MonthSeStar = $("#MonthSeStar").val().trim();
		var MonthSeEnd = $("#MonthSeEnd").val().trim();
		if (MonthSeStar != "" && MonthSeEnd != "") {
			if (parseInt(MonthSeStar) > parseInt(MonthSeEnd)) {
				alert("结束时间不能小于开始时间");
				$("#MonthSeEnd").get(0).selectedIndex = 0;
			}
		}
	};
	
/*****************************************************/	
	//检索方法
	function query(url){
		
		var TimeUnit = $("#TimeUnit").val().trim();
		
		alert(TimeUnit);
		var year = 0; 
		var beginWeek = 0; 
		var endWeek = 0; 
		var beginMonth =0; 
		var endMonth =0; 
		var beginTime =""; 
		var endTime =""; 
		//时间单位为周
		if (TimeUnit == 2) {
			year = $("#YearSeWeek").val().trim();
			beginWeek = $("#WeekLiSeStar").val().trim();
			endWeek = $("#WeekLiSeEnd").val().trim();
			if (year == "" ||  beginWeek == "" || endWeek == "") {
				alert("请选择年份、开始和结束周！");
				return false;
			}
		//时间单位为月	
		}else if(TimeUnit == 3){
			year = $("#YearSeMonth").val().trim();
			beginMonth = $("#MonthSeStar").val().trim();
			endMonth = $("#MonthSeEnd").val().trim();
			if (year == "" ||  beginMonth == "" || endMonth == "") {
				alert("请选择年份、开始月和结束月！");
				return false;
			}
		//时间单位为日 
		}else if(TimeUnit == 1){
			beginTime = $("#begindate").val().trim();
			endTime = $("#enddate").val().trim();
			if(beginTime == "" || endTime == ""){
				alert("请选择开始和结束时间！");
				return false;
			}
		}else if(TimeUnit == 4){
			beginTime = $("#begindate").val().trim();
			endTime = $("#enddate").val().trim();
			if(beginTime == "" || endTime == ""){
				alert("请选择开始和结束时间！");
				return false;
			}
		}
		//执行查询操作
		window.location.href = url+"getAllDdmp400ReportForm.do?LARGER_REGION_ID="
			+ larger_region_code + '&SMALL_REGION_ID='+ small_region_code 
			+ '&FK_DEALER_ID='+ fk_dealer_id + '&DEALER_NAME=' + encodeURI(encodeURI(DEALER_NAME))  + '&KPI=' + KPI
			+ '&beginTime='+ beginTime + '&endTime='+ endTime + '&SOURCE_MEDIA='+ source_media
			+ '&year=' + year + '&beginWeek='+ beginWeek + '&endWeek='+ endWeek + '&beginMonth=' + beginMonth
			+ '&endMonth=' + endMonth + '&TimeUnit=' + TimeUnit;
	}
	/*------------------------------------End -------------------------------------------------------------*/
	
	//查询项目名称
	function getUserByTeam(){
		//项目名称关键字
		var teamid=$("#team").val();
		$.ajax({
			type:"POST",
			//url:basepath+'serachProject.do',
			url:"getUserByTeam.do", //查询组下的员工
			data:{ 
				teamid:teamid
			},  
			success:function(data){
				$("#employee").empty();
				$("#employee").append("<option value='0'>全选</option>");
				
				for(i in data){
					$("#employee").append("<option value='" + data[i].id + "'  >" +data[i].name + "</option>");
				}
							
					
					
					 
			} 
		});	
	};

	var pageHeight = $(window).height(); //屏幕高度
	var pageBoxHeight = pageHeight - $('div.page-box-con')[0].offsetHeight-145;//BOX高度
	$('div#tab1div1').css("height",pageBoxHeight);
	$('div#tab1div1').mCustomScrollbar({
		theme: "minimal-dark"
	}); 
	
	$('#employee').on('change',function(){
		$.ajax({
			type:"POST",
			url:"selectProjectByuserId.do",
			data:{
				userid:$('#employee option:selected').val()
			},
			success:function(data){
				$("#project").empty();
				$("#project").append("<option value='0'>全选</option>");
				if(data.length>0){
					var a="";
					for(var i=0;i<data.length;i++){
						a+="<option value='" + data[i].projectid + "'  >" +data[i].projectname + "</option>"
					}
					$("#project").append(a);
				}
			}
		});
	});
	
	// 获取当前时间并且格式化 成 YYYY-MM-DD HH:mm:ss
	function getCurrentDate(){
		 var date = new Date();
		    var seperator1 = "-";
		    var seperator2 = ":";
		    var month = date.getMonth() + 1;
		    var strDate = date.getDate();
		    if (month >= 1 && month <= 9) {
		        month = "0" + month;
		    }
		    if (strDate >= 0 && strDate <= 9) {
		        strDate = "0" + strDate;
		    }
		    var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate
		            + " " + date.getHours() + seperator2 + date.getMinutes()
		            + seperator2 + date.getSeconds();
		    return currentdate;
	}
	
	// 导出
	function exportProject1(){
	    // 获取当前时间
	    var currentDate=getCurrentDate().substring(0,10);
		method1('tab1div',currentDate+"_项目奖励统计.xls");
	}