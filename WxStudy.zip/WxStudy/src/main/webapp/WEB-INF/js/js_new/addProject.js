/** 定义全局变量* */
var URI = '';
var flag = false;
/** 页面加载时加载部门信息* */
function loadDepInfo(uri,depID) {
	URI = uri;
	$.ajax({
		type : "POST",
		dataType : "text",
		url : uri + 'loadDepInfo.do',
		async : false,
		dataType : "text",
		success : function(data) {
			// alert(data);
			$(eval("(" + data + ")")).each(function() {
							if (depID == this.id) {
								$("#depID").html('');
								$("#depID").append("<option value='" + this.id + "'>"+ this.deptName + "</option>");							
								loadTeamInfo();
							}
			});
		}
	});
}

// changrui.pan
function loadDepInfo(uri){
	URI = uri;
	var e=$("#depID");
	loadTeamInfo(e);
}

/** 根据部门ID查询对应组信息* */
function loadTeamInfo(e) {
	  
	// 获取选择部门ID
	var deptid =$(e).val();// $("#depID").val();
	//alert(deptid);
	$.ajax({
		type : "POST",
		url : URI + 'loadTeamInfo.do?deptid=' + deptid,
		async : false,
		dataType : "text",
		success : function(data) {
			// alert(data);
			 
			 
			//$("#teamID").html("");
			$(e).parent("div").next("div").children("select").html("")
			$(eval("(" + data + ")")).each(
					function() {
						// alert(this.name);
					
						$(e).parent("div").next("div").children("select").append(
									"<option value='" + this.id + "'>"
											+ this.name + "</option>");
			});
		}
	});

	if (deptid == 0) {
		$("#teamID").html("<option value='0'>无</option>");
	}
	
	// 获取oem部门对应组人员
	//loadTbUsers(deptid,$("#teamID").val());
	var n = $(e).parent("div").next("div").children("select");
	loadTbUsers(n);

}

/**加载全部人员**/
function loadTbUsers(e){
	//页面加载的时候加载项目经理
	var seldeptid = "";
	var selteamID = "";
	if(e==undefined){
		 
		  seldeptid = $("#depID").val();
		  selteamID = $("#teamID").val();
	}else{
		
		seldeptid = $(e).parent("div").prev().children("select").val();
		selteamID = $(e).val();
	}
	 
	
	//
	
	$.ajax({
		type : "POST",
		data : {
			seldeptid:seldeptid,
			selteamID:selteamID
		},
		url : URI + 'loadTbUsers.do?',
		async : false,
		dataType : "text",
		success : function(data) {
			if(e==undefined){
				 
				$("#projectLeaderID").html("");
				 
			}else{
				$(e).parent("div").nextAll("div:last").children("select").html("");
			 
			}
			$(eval("(" + data + ")")).each(
					function() {
						if(e==undefined){
							 
							 
								$("#projectLeaderID").append("<option value='" + this.id + "'>"+ this.name + "</option>");
							 
						}else{
							 
							$(e).parent("div").nextAll("div:last").children("select").append("<option value='" + this.id + "'>"+ this.name + "</option>");
							 
						}
						
			});
		}
	});  
}

/**对项目名称和项目编号进行校验(验重)**/
function cheakProNameOrProCode(projectName,projectcode){
	if (projectName == "" || projectcode == "") {
		return false;
	}
	
	//根据项目名称和项目编号校验
	$.ajax({//针对项目名称和项目编号进行验重操作
		type : "POST",
		url : URI + 'cheakProNameOrProCode.do?',
		async : false,
		data : {
			projectName:projectName,
		/*	projectcode:projectcode*/
		},
		success : function(data) {
			//alert(data);
			if (data != "0") {
				//alert("该项目名已存在!");	
				flag =false;
				return flag;
			}else{
				flag = true;
				return flag;
			}
		}
	});
}
//

//


//最后一个模块的提交按钮
$('div.save-this-pro').on('click',function(){
	// 获取所有项目模块信息
	 var ProjectList = ProjectLoop(); 
	 //alert(ProjectList);
	 //如果ProjectList等于false 返回
	 if(ProjectList==false){
		 return false;
	 }
	 //执行插入操作
	    $.ajax({
		type : "POST",
		url : URI + 'project/addProject.do',
		data : {
			a : ProjectList
		},
		success : function(data) {
			if (data == 1) {
				$('div.box-info-success:last').addClass("box-info-show");
				setTimeout(function() {
					$("#success01").removeClass("box-info-show");
				}, 1500);
				setTimeout(function() {
				window.location.href = URI + "project/projectManagement.html?";//再重新查询一下项目列表
				}, 1500);
			} else {
				$("#error01").addClass("box-info-show");
				setTimeout(function() {
					$("#error01").removeClass("box-info-show");
				}, 15000);
			}
		}
	});
});


// 获取所有项目模块信息 拼接项目信息
function ProjectLoop(){
	var index =0;
	var a="["
	var b="["//拼接验证多个项目模块（项目名称和编号）信息拼接字符串，进行验重操作
	$('div.project-main .project-ul .list').each(function(){
		// 验证页面元素非空
		if($('div.project-main .project-ul .list #projectNameID').eq(index).val()==''){
			alert("第"+(index+1)+"个项目的项目名称不能为空!");
			a="";
			b="";
			return false;
		}else if($('div.project-main .project-ul .list #depID').eq(index).find("option:selected").val()==''){
			alert("第"+(index+1)+"个项目所属的部门不能为空!");
			a="";
			b="";
			return false;
		}else if($('div.project-main .project-ul .list #teamID').eq(index).find("option:selected").val()==''){
			alert("第"+(index+1)+"个项目所属的组别不能为空!");
			a="";
			b="";
			return false;
		}else if($('div.project-main .project-ul .list #projectcodeID').eq(index).val()==''){
			alert("第"+(index+1)+"个项目的项目编号不能为空!");
			a="";
			b="";
			return false;
		}else if($('div.project-main .project-ul .list #projectLeaderID').eq(index).find("option:selected").val()==''){
			alert("第"+(index+1)+"个项目的项目经理不能为空!");
			a="";
			b="";
			return false;
		}else if(b.indexOf($('div.project-main .project-ul .list #projectNameID').eq(index).val()) != -1){
			alert("第"+(index+1)+"个项目名重复!");
			a="";
			b="";
			return false;
		}/*
		 // changrui.pan  修改 2017/03/15
		else if($('div.project-main .project-ul .list #beginTime').eq(index).val()==''){
			alert("第"+(index+1)+"个项目的开始时间不能为空!");
			a="";
			b="";
			return false;
		}else if($('div.project-main .project-ul .list #endTime').eq(index).val()==''){
			alert("第"+(index+1)+"个项目的结束时间不能为空!");
			a="";
			b="";
			return false;
		}	*/
		if($('div.project-main .project-ul .list #projectNameID').eq(index).val().indexOf("\'") > 0 || $('div.project-main .project-ul .list #projectNameID').eq(index).val().indexOf("\"")>0 || $('div.project-main .project-ul .list #projectNameID').eq(index).val().indexOf("&") > 0 ){
			alert("第"+(index+1)+"个项目名不合法（不能输入单引或双引号和&等特殊字符）!");
			a="";
			b="";
			return false;
		}
		if($('div.project-main .project-ul .list #projectcodeID').eq(index).val().indexOf("\'") > 0 || $('div.project-main .project-ul .list #projectcodeID').eq(index).val().indexOf("\"")>0 || $('div.project-main .project-ul .list #projectcodeID').eq(index).val().indexOf("&")>0){
			alert("第"+(index+1)+"个项目编号不合法（不能输入单引或双引号和&等特殊字符）!");
			a="";
			b="";
			return false;
		}
		if ($('div.project-main .project-ul .list #projectNameID').eq(index).val().length > 200) {
			alert("第"+(index+1)+"个项目名称不能超过200字符!");
			a="";
			b="";
			return false;
		}
		if ($('div.project-main .project-ul .list #projectcodeID').eq(index).val().length > 50) {
			alert("第"+(index+1)+"个项目编号不能超过50字符!");
			a="";
			b="";
			return false;
		}
		cheakProNameOrProCode($('div.project-main .project-ul .list #projectNameID').eq(index).val(),$('div.project-main .project-ul .list #projectcodeID').eq(index).val());
		//alert(flag);
		if (!flag) {
			alert("第"+(index+1)+"个项目已经存在，新建失败!");
			a="";
			return false;
		}
		
		 a=a+"{'projectName':'"+$('div.project-main .project-ul .list #projectNameID').eq(index).val()+
         "','deptid':'"+$('div.project-main .project-ul .list #depID').eq(index).find("option:selected").val()+
         "','teamid':'"+$('div.project-main .project-ul .list #teamID').eq(index).find("option:selected").val()+
		 "','projectcode':'"+$('div.project-main .project-ul .list #projectcodeID').eq(index).val()+
		 "','projectuserid':'"+$('div.project-main .project-ul .list #projectLeaderID').eq(index).find("option:selected").val()+
		 "','projectLeader':'"+$('div.project-main .project-ul .list #projectLeaderID').eq(index).find("option:selected").text()+
		 "','startDate':'"+$('div.project-main .project-ul .list #beginTime').eq(index).val()+
		 "','endDate':'"+$('div.project-main .project-ul .list #endTime').eq(index).val()+
		 "'},";	
		 
		//拼接验证多个项目模块信息拼接字符串，进行验重操作
		 b = b +"{"+$('div.project-main .project-ul .list #projectNameID').eq(index).val()+"},";	
		 
		     index++;
		if (index ==$('div.project-main .project-ul .list:last').index()){
			return false;
		}
	});
	
   a=a.substring(0,a.length-1)+"]";
   b=b.substring(0,a.length-1)+"]";
   
   if (a=="]"){
	   return false;
   }  
	return a;
}