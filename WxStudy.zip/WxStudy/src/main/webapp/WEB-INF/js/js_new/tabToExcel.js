/************************************************tabToExcel.js Start*****************************************************/
	var idTmr;
        function  getExplorer() {
            var explorer = window.navigator.userAgent;
            //ie 
            if (!!window.ActiveXObject || "ActiveXObject" in window) {
                return 'ie';
            }else if (explorer.indexOf("Firefox") >= 0) {//firefox
                return 'Firefox';
            } else if(explorer.indexOf("Chrome") >= 0){//Chrome
                return 'Chrome';
            } else if(explorer.indexOf("Opera") >= 0){//Opera
                return 'Opera';
            }else if(explorer.indexOf("Safari") >= 0){//Safari
                return 'Safari';
            };
        }
        function method1(tableid1,filename) {//整个表格拷贝到EXCEL中
            if(getExplorer()=='ie'){
            	  window.document.write(document.getElementById(tableid1).outerHTML);    
                  window.document.execCommand("SaveAs",false,filename);    
                  history.go(-1);    
            }
            else
            {	
            	tableToExcel(tab1div,'name',filename);
            }
        }
        function Cleanup() {
            window.clearInterval(idTmr);
            CollectGarbage();
        }
        var tableToExcel = (function() {
        	
              var uri = 'data:application/vnd.ms-excel;base64,',
              template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:office" xmlns="http://www.w3.org/TR/REC-html40">'+
            	  '<head><!--[if gte mso 9]>'+'<meta charset="UTF-8">'+
            	  '<xml>'+
            	  '<x:ExcelWorkbook>'+
            	  	'<x:ExcelWorksheets>'+
            	  		'<x:ExcelWorksheet>'+
            	  			'<x:Name>{worksheet}</x:Name>'+
            	  			'<x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions>'+
        	  			'</x:ExcelWorksheet>'+
    	  			'</x:ExcelWorksheets>'+
	  			'</x:ExcelWorkbook></xml>'+
	  			'<![endif]--></head>'+
	  			'<body>{table}</body></html>',
                base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) },
                format = function(s, c) {
                    return s.replace(/{(\w+)}/g,
                    function(m, p) { return c[p]; }) }
                return function(table,name,filename) {
                if (!table.nodeType) table = document.getElementById(table)
                var ctx = {worksheet: name || 'Worksheet', table: table.innerHTML}
                //window.location.href = uri + base64(format(template, ctx))
                document.getElementById("dlink").href = uri + base64(format(template, ctx));
                document.getElementById("dlink").download = filename;//这里是关键所在,当点击之后,设置a标签的属性,这样就可以更改标签的标题了
                document.getElementById("dlink").click();
              }
            })()
       
        
            
/************************************************tabToExcel.js End*****************************************************/            
