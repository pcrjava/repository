/*
 * 主JS文件
 * 日期: 2017-02-06
 * By Endfish
 * 
*/

//所有页面
function initPage () {
	
	//左侧导航开启
	$('div.page-top .menu-left').on("click",function() {
		$('div.left-nav').removeClass("left-nav-hide");
	})
	//左侧导航关闭
	$('div.left-nav .btn-close').on("click",function() {
		$('div.left-nav').addClass("left-nav-hide");
	});
	//右侧导航开启
	$('div.page-top .menu-right').on("click",function() {
		$('div.right-nav').removeClass("right-nav-hide");
	})
	//右侧导航关闭
	$('div.right-nav .btn-close').on("click",function() {
		$(this).parent().addClass("right-nav-hide");
	});
	
	//计算页面高度分配给BOX
	var pageHeight = $(window).height(); //屏幕高度
	var pageBoxHeight = pageHeight - $('div.page-box')[0].offsetTop - 80; //BOX高度
	$('div.page-box').css("height",pageBoxHeight);

	//下拉菜单滚动
	$('div.box-form .box-pop').mCustomScrollbar({
		theme: "minimal-dark"
	});

	//选中下拉关闭
	$('div.box-title .box-pop li').on("click",function() {
		$('div.box-pop').removeClass("box-pop-show"); //关闭下拉列表
	});
	//表单产生滚动条
	$('div.box-form-scroll, div.box-list-scroll').mCustomScrollbar({
		theme: "minimal-dark",
		live: true
	});
	
}



 
 
  
