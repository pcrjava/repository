
if($('#projectdate').val()==''){
	var currentDate=getCurrentDate().substring(0,10);
	$("#projectdate").attr("value",currentDate);
}

 // 获取当前时间并且格式化 成 YYYY-MM-DD HH:mm:ss
function getCurrentDate(){
	 var date = new Date();
	    var seperator1 = "-";
	    var seperator2 = ":";
	    var month = date.getMonth() + 1;
	    var strDate = date.getDate();
	    if (month >= 1 && month <= 9) {
	        month = "0" + month;
	    }
	    if (strDate >= 0 && strDate <= 9) {
	        strDate = "0" + strDate;
	    }
	    var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate
	            + " " + date.getHours() + seperator2 + date.getMinutes()
	            + seperator2 + date.getSeconds();
	    return currentdate;
}

//编辑项目
function updProjectInfo(e) {
	var  id = $(e.parentNode).parent().find("td").eq(0).text();  // 项目ID
	var  projecttem = $(e.parentNode).parent().find("td").eq(1).text(); //部门ID
	var  projectstate = $(e.parentNode).parent().find("td").eq(2).text(); //项目状态ID
	var  projectdepartment = $(e.parentNode).parent().find("td").eq(3).text(); //事业部ID
	var  projectmanager = $(e.parentNode).parent().find("td").eq(4).text(); //项目经理ID
	var  projectnumber = $(e.parentNode).parent().find("td").eq(6).text();  //项目编号
	var  projectname = $(e.parentNode).parent().find("td").eq(7).text();   //项目名称
	var  subprojectname = $(e.parentNode).parent().find("td").eq(8).text(); //子项目名称
	var  deptname = $(e.parentNode).parent().find("td").eq(9).text(); //部门名称
	var  LeaderNm = $(e.parentNode).parent().find("td").eq(10).text(); //项目经理名字
	var  projectdate = $(e.parentNode).parent().find("td").eq(11).text();  //立项日期
	var  stateNm = $(e.parentNode).parent().find("td").eq(12).text();  //状态名称
	var  projectvalue = $(e.parentNode).parent().find("td").eq(13).text();   //项目合同金额
	var  purchaseamount = $(e.parentNode).parent().find("td").eq(14).text(); // 采购金额
	var  subprojectcode = $(e.parentNode).parent().find("td").eq(15).text(); // 子项目编号
	
	window.location.href = "updProjectInfo_New.do?projectdepartment=" + projectdepartment
			+ "&projecttem=" + projecttem + "&projectstate=" + projectstate+"&id="+id+"&projectmanager="
			+projectmanager+"&projectnumber="+projectnumber+"&projectname="+projectname+"&subprojectname="+subprojectname+
			"&projectdate="+projectdate+"&subprojectcode="+subprojectcode+"&projectvalue="+projectvalue+
			"&purchaseamount="+purchaseamount;

}

// 添加
function addProject(){
	window.location.href="updProjectInfo_New.do";
}

/**删除项目（更新项目表中isdel状态 ）
 * changrui.pan 2018-06-01
 * **/
function delProject(e){
	var  id = $(e.parentNode).parent().find("td").eq(0).text();
	var  projectname = $(e.parentNode).parent().find("td").eq(7).text();
	
	if (!confirm("是否删除项目" + projectname + "?")) {
		return false;
	}
	$.ajax({
		type : "POST",
		url :'delProject.do',
		data:{
			id:id
		},
		async : false,
		success : function(data) {
			if (data>0) {
				alert("删除成功!");
				window.location.href="projectManagement.html";
			}else{
			}
		}
	});
}
	//根据事业部查出部门
	function selectTeamList(){
		$.ajax({
			url:"selectTeamList.do",
			data:{
				projectdepartment:$("#projectdepartment").find("option:selected").val()
			},
			success:function(data){
				var a="";
				var b="";
				$("#projecttem").empty();
				$("#projecttem").append("<option value='0'>请选择</option>");
				for (var i=0;i<data.length;i++){
					a+="<option value="+data[i].id+">"+data[i].name+"</option>";
				}
				$("#projecttem").append(a);
			}
			
		});
	}
	
	//根据部门查出人员
	function selectUsersList(){
		$.ajax({
			url:"selectUsersList.do",
			data:{
				projecttem:$("#projecttem").find("option:selected").val(),
				projectdepartment:$("#projectdepartment").find("option:selected").val()
			},
			success:function(data){
				var a="";
				$("#projectmanager").find("option").remove();
				$("#projectmanager").append("<option value='0'>请选择</option>");
				for (var i=0;i<data.length;i++){
					a+="<option value="+data[i].id+">"+data[i].name+"</option>";
				}
				$("#projectmanager").append(a);
			}
			
		});
	}
	// 根据项目名查出子项目
	function selectSubProjectList(){
		
		$.ajax({
			url:"selectSubProjectList.do",
			data:{
				projectname:$("#projectname").find("option:selected").val()
			},
			success:function(data){
				var a="";
				if (data.length==1 && data[0].subprojectname=="无"){
					$("select#subprojectname").css("display","none");
					$("input#subprojectname").removeAttr("style");
				}else{
					$("select#subprojectname").removeAttr("style");
					$("input#subprojectname").css("display","none");
					
					$("select#subprojectname").find("option").remove();
					$("select#subprojectname").append("<option value='0'>请选择</option>");
					for (var i=0;i<data.length;i++){
						a+="<option value="+data[i].subprojectname+">"+data[i].subprojectname+"</option>";
					}
					$("select#subprojectname").append(a);
				}
			}
			
		});
	}


//根据项目名模糊查询
function selectProjectByName(){
	$.ajax({
		url:"selectProjectByName.do",
		data:{
			projectname:$('#projectname').find('option:selected').val()
		},
		success:function(data){
			var a="";
			$('table tbody').empty();
			for(var i=0;i<data.length;i++){
				a+="<tr align='center'>"+
				"<td style='display: none;'>"+data[i].id+"</td>"+
				"<td style='display: none;'>"+data[i].projecttem+"</td>"+
				"<td style='display: none;'>"+data[i].projectstate+"</td>"+
				"<td style='display: none;'>"+data[i].projectdepartment+"</td>"+
				"<td style='display: none;'>"+data[i].projectmanager+"</td>"+
				"<td  width='5%'>"+(i+1)+"</td>"+
				"<td  width='10%'>"+(data[i].projectnumber==null?'':data[i].projectnumber)+"</td>"+
				"<td  width='15%'>"+(data[i].projectname==null?'':data[i].projectname)+"</td>"+
				"<td  width='15%'>"+(data[i].subprojectname==null?'':data[i].subprojectname)+"</td>"+
				"<td  width='5%'>"+(data[i].teamname==null?'':data[i].teamname)+"</td>"+
				"<td  width='5%'>"+(data[i].leaderNm==null?'':data[i].leaderNm)+"</td>"+
				"<td  width='10%'>"+(data[i].projectdate==null?'':data[i].projectdate)+"</td>"+
				"<td  width='5%'>"+(data[i].stateNm==null?'':data[i].stateNm)+"</td>"+
				"<td  width='10%'>"+(data[i].projectvalue==null?'':data[i].projectvalue)+"</td>"+
				"<td  width='10%'>"+(data[i].purchaseamount==null?'':data[i].purchaseamount)+"</td>"+
				"<td  width='10%'><a href='#' onclick='updProjectInfo(this)';><div class='box-table-edit' title='编辑'><i class='icon'></i></div></a>"+
				"<a href='#' onclick='delProject(this);'><div class='box-table-del' title='删除'><i class='icon'></i></div></a></td></tr>";					
			}	
			
			$('table tbody').append(a);
		}
	});	
}

//提交表单
function bb(){

	var projectname =$('#projectname').find("option:selected").val();
	
	if($('#subprojectname').prop("tagName")=="INPUT"){
		var subprojectname=$('#subprojectname').val();
	}else{
	   var subprojectname =$('#subprojectname').find("option:selected").val();
	}
	var projectnumber =$('#projectnumber').val();
	var addProjectname =$('#addProjectname').val();
	var projectdate =$('#projectdate').val();
	var projectvalue =$('#projectvalue').val();
	var purchaseamount =$('#purchaseamount').val();
	var id =$('#id').val();
	var projectdepartment =$('#projectdepartment').find("option:selected").val();
	var projecttem =$('#projecttem').find("option:selected").val();
	var projectmanager =$('#projectmanager').find("option:selected").val();
	var projectstate =$('#projectstate').find("option:selected").val();
	
	if (addProjectname ==""){
		alert("请选择项目名称!");
		return
	}
	/*if (subprojectname ==""){
		alert("请选择子项目名称!");
		return
	}
	if (projectnumber ==""){
		alert("请选择项目编号!");
		return
	}*/
	if (projectdate ==""){
		alert("请选择立项时间!");
		return
	}
	if (projectdepartment == 0){
		alert("请选择事业部!");
		return
	}
	if (projecttem == 0){
		alert("请选择部门!");
		return
	}
	if (projectmanager == 0){
		alert("请选择项目经理!");
		return
	}
	if (projectstate == 0){
		alert("请选择项目状态!");
		return
	}
	
	$.ajax({
		type:"Post",
		url:"addProject_new.do",
		data:{
			projectnumber:projectnumber,
			subprojectname:subprojectname,
			projectdate:projectdate,
			projectdepartment:projectdepartment,
			projecttem:projecttem,
			projectmanager:projectmanager,
			projectstate:projectstate,
			projectvalue:projectvalue,
			purchaseamount:purchaseamount,
			projectname:projectname,
			id:id,
			addProjectname:addProjectname	
		},
		success:function(data){
			if ($("#id").val() !="0"){
				if (data>0){
					alert("更新成功!");
					window.location.href="projectManagement.html";
				}else{
					alert("更新失败!");
				}
			}else{
				if (data>0){
					alert("添加成功!");
					window.location.href="projectManagement.html";
				}else{
					alert("添加失败!");
				}
			}
		}
	});

}