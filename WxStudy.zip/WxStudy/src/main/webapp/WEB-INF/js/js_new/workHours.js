/*
 * 工时列表JS文件
 * 日期: 2017-02-22
 * By changrui.pan
 * 
*/
$(document).ready(function(){
	var maxTime =new Date();
	
	  // 工时查看的时间控件
		 $(".form-datetime").datetimepicker({
				minView: "month", //选择日期后，不会再跳转去选择时分秒 
				language:  'zh-CN',
				format: 'yyyy-mm-dd',
				todayBtn: 1,
				autoclose: 1,
				endDate: maxTime,
			});
			
			var currentDate=getCurrentDate().substring(0,10);
			$("#workdate").attr("value",currentDate);
			
			// 从工时查看页面未填报工时 列表 跳到工时填报页面 ,同时 把未填报的工时传递给工时填报的工时日期上
			if ($("#emptyWorkHours").val()!=""){
				$("#workdate").attr("value",$("#emptyWorkHours").val());
			}
			
            // 最后一个模块的提交按钮
			$('div.time-main .time-ul .list .box-btn-save:last').on('click',function(){	
				//日常-整天请假的提交方法
				if($("#param1").val()!=""){
					if($("#beginTime").val()=="" || $("#endTime").val()==""){
						alert("工时日期不能为空!")
						return 
					}
					
					if($("#timedif").text()==""){
						alert("工时时长不能为空!")
						return 
					}
					
					if($("#projectname").val()==""){
						alert("项目不能为空!")
						return 
					} 
					
					if($("#subprojectname").val()=="0"){
						alert("子项目不能为空!")
						return 
					} 
					
					if($("#workType").val()==""){
						alert("类型不能为空!")
						return 
					} 
					
					if($("#workLog").val()==""){
						alert("内容不能为空!")
						return 
					} 
					
					$.ajax({
						type:"Post",
						url:"holidaySubmit.do",
						data:{
							beginTime:$("#beginTime").val(),
	  	            		endTime:$("#endTime").val(),
	  	            		projectID:$('#subprojectname').find('option:selected').val(),
	  	            		workTypeID:$('#workType').find('option:selected').val(),
	  	            		workLog:$("#workLog").text()
						},
						success:function(data){
							if (data>0){
								alert("保存成功^_^!");
								// 跳到工时列表页面
		            			window.location.href="workingHours.html";
								return 
							}else{
								alert("保存失败!");
								return 
							}
						}	
					});
					return 
				}

		     // 获取所有工时模块信息
			 var b=workinghoursLoop(); 
			//var b =workinghoursLoop.workinghoursLoop();
			 
			 // 普通工作类型 提交
			 if(b[0]!="]" && b[1]=="]"){
	             $.ajax({
	            	 type:"post",
	            	 url:"insertWorkingHours.do",
	            	 data:{
	            		 a:b[0]
	            	 },
	            	 success:function(data){
	            		if (data==1){
	            			alert("保存成功^_^!");
	            			$(this).addClass("box-btn-down");
	            			// 跳到工时列表页面
	            			window.location.href="workingHours.html";
	            		} else if (data==2){
	            			alert("工时不能重复添加,添写失败!");
	            			return false;
	            		}else{
	            			alert("保存失败!");
	            			return false;
	            		}
	            	 }	 
	             });
			}else{
			// 混合工作类型 提交
				$.ajax({
					type:"post",
					url:"insertWorkingCountAndHours.do",
					data:{
						a:b[1],
						b:b[0]
					},
					success:function(data){
						if (data==1){
	            			alert("保存成功^_^!");
	            			$(this).addClass("box-btn-down");
	            			// 跳到工时列表页面
	            			window.location.href="workingHours.html";
	            		} else{
	            			alert("保存失败!");
	            			return false;
	            		}
					}
				});		
			}
			});
		
			// 时间差
			$('div.time-main .time-ul .list .begin-time:last').add($('div.time-main .time-ul .list .end-time:last')).on('change',function(){
				
				var beginTime=$('div.time-main .time-ul .list .begin-time:last').val();  //开始时间
				var endTime=$('div.time-main .time-ul .list .end-time:last').val();    //结束时间
				
				var time1 = beginTime.toString(); 
				var time2 = endTime.toString();  
				var timestart = new Date(Date.parse(time1.replace(/-/g,"/"))).getTime(); 
				var timeend = new Date(Date.parse(time2.replace(/-/g,"/"))).getTime();
				var datecomparent=timeend-timestart;  //差的毫秒数
				var time3 = time1.substring(0,10)+" 11:30";
				var time4 = time1.substring(0,10)+" 12:30";
				var restTimeBegin = new Date(Date.parse(time3.replace(/-/g,"/"))).getTime();  
				var restTimeEnd = new Date(Date.parse(time4.replace(/-/g,"/"))).getTime();  
			
				// var date3=new Date(endTime).getTime()-new Date(beginTime).getTime();  //时间差的毫秒数
				
			    // 比较开始时间和结束时间
				if (datecomparent<0)
				{
					alert("结束时间必须大于开始时间!");
					$('div.time-main .time-ul .list .end-time:last').val('');
					$('div.time-main .time-ul .list #timedif:last').text('');
					return false;
				}
			
				if ((timestart<restTimeBegin||timestart==restTimeBegin) && (timeend>restTimeEnd||timeend==restTimeEnd)){
					var hours=(datecomparent-3600*1000)/(3600*1000);
					$('div.time-main .time-ul .list #timedif:last').html(hours);
				}else{
					//计算出小时数
					var hours=datecomparent/(3600*1000);
					$('div.time-main .time-ul .list #timedif:last').html(hours);
				}
				
				
			});
		});

   // 删除工时
	function workDelete(workId,beginTime,endTime,projectid,workTypeid){
	
		if(confirm("是否删除?")){
		$.ajax({
			url:"workDelete.do",
			data:{
				id:workId,
				beginTime:beginTime,
				endTime:endTime,
				projectid:projectid,
				workTypeid:workTypeid,
				userid:$("#userName").val()
			},
			success:function(data){
			
				if (data==1){
					alert("删除成功!");
					window.location.href="workingHours.html";
				}else{
					alert("删除失败!");
				}	
			}
		});
		
		}
		
	}
   
   // 获取当前时间并且格式化 成 YYYY-MM-DD HH:mm:ss
		function getCurrentDate(){
			 var date = new Date();
			    var seperator1 = "-";
			    var seperator2 = ":";
			    var month = date.getMonth() + 1;
			    var strDate = date.getDate();
			    if (month >= 1 && month <= 9) {
			        month = "0" + month;
			    }
			    if (strDate >= 0 && strDate <= 9) {
			        strDate = "0" + strDate;
			    }
			    var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate
			            + " " + date.getHours() + seperator2 + date.getMinutes()
			            + seperator2 + date.getSeconds();
			    return currentdate;
		}
	
	
		// 循环工时模块	
		function workinghoursLoop(){
			var index =0;   // 模块索引
			var timeSum=0;  // 工时和
			var array=new Array(2);
			var a="[";
			var c="[";
			$('div.time-main .time-ul .list').each(function(){
				
				 var projectid = $('div.time-main .time-ul .list #subprojectname').eq(index).find("option:selected").val();
				
				// 记录第一个工时模块开始时间
				var firstBeginTime = $('div.time-main .time-ul .list #beginTime').eq(0).val();
				
				// 验证页面元素非空
				if($('div.time-main .time-ul .list #workdate').eq(index).val()==''){
					alert("第"+(index+1)+"个工时模块工作日期不能为空!");
					a="";
					return false;
				}else if($('div.time-main .time-ul .list #timedif').eq(index).html()=='0'||$('div.time-main .time-ul .list #timedif').eq(index).html()==''){
					alert("第"+(index+1)+"个工时模块工时不能为空!");
					a="";
					return false;
				}else if($('div.time-main .time-ul .list #beginTime').eq(index).val()==''){
					alert("第"+(index+1)+"个工时模块开始时间不能为空!");
					a="";
					return false;
				}else if($('div.time-main .time-ul .list #beginTime').eq(index).val().substring(0,10)!=firstBeginTime.substring(0,10)){
					alert("第"+(index+1)+"个工时模块开始时间和第一个工时模块开始时间不是同一天!");
					a="";
					return false;
				}else if($('div.time-main .time-ul .list #endTime').eq(index).val()==''){
					alert("第"+(index+1)+"个工时模块结束时间不能为空!");
					a="";
					return false;
				}else if($('div.time-main .time-ul .list #endTime').eq(index).val().substring(0,10)!=firstBeginTime.substring(0,10)){
					alert("第"+(index+1)+"个工时模块结束时间和第一个工时模块开始时间不是同一天!");
					a="";
					return false;
				}else if($('div.time-main .time-ul .list #projectname').eq(index).val()==''){
					alert("第"+(index+1)+"个工时模块项目名称不能为空!");
					a="";
					return false;
				}else if($('div.time-main .time-ul .list #subprojectname').eq(index).val()=='0'){
					alert("第"+(index+1)+"个工时模块子项目名称不能为空!");
					a="";
					return false;
				}else if($('div.time-main .time-ul .list #workType').eq(index).val()==''){
					alert("第"+(index+1)+"个工时模块工作类型不能为空!");
					a="";
					return false;
				}else if($('div.time-main .time-ul .list #workLog').eq(index).val().replace(/\n/g,"").trim()==''){
					alert("第"+(index+1)+"个工时模块工作内容不能为空!");
					a="";
					return false;
				}
				// 统计工时
				 timeSum =timeSum+parseFloat($('div.time-main .time-ul .list #timedif').eq(index).html());
				 var worktypeVal = $('div.time-main .time-ul .list #workType').eq(index).find('option:selected').text();
				 var worklog =$('div.time-main .time-ul .list #workLog').eq(index).val().replace(/'/g,'\\\'').replace(/\n/g,'\\n');
				  
				 // 判断是否添加重复时间段
				 if (index > 0){
					 if ($('div.time-main .time-ul .list #beginTime').eq(index).val() == $('div.time-main .time-ul .list #beginTime').eq(index-1).val()){
						 alert("开始日期重复添加!");
						 return false;
					 }
				 }
			
				// 根据工作类型  选择是否插入tb_workinghours_count ---2017/5/9	 
				 if('需求文档预审'==worktypeVal){
					 c=c+"{'workdate':'"+$('div.time-main .time-ul .list #beginTime').eq(index).val().substring(0,10)+
	                 "','beginTime':'"+$('div.time-main .time-ul .list #beginTime').eq(index).val()+
	                 // "','timedif':'"+$('div.time-main .time-ul .list #timedif').eq(index).html()+
	                 "','timedif':'0"+
					   "','endTime':'"+$('div.time-main .time-ul .list #endTime').eq(index).val()+
					   "','projectid':'"+projectid+
					   "','workTypeid':'"+$('div.time-main .time-ul .list #workType').eq(index).val()+
					   "','numname':'需求预审问题数量"+
					   "','num':'"+worklog+"'},";
					 a=a+"{'workdate':'"+$('div.time-main .time-ul .list #beginTime').eq(index).val().substring(0,10)+
	                 "','beginTime':'"+$('div.time-main .time-ul .list #beginTime').eq(index).val()+
	                 "','timedif':'"+$('div.time-main .time-ul .list #timedif').eq(index).html()+
					   "','endTime':'"+$('div.time-main .time-ul .list #endTime').eq(index).val()+
					   "','projectid':'"+projectid+
					   "','workTypeid':'"+$('div.time-main .time-ul .list #workType').eq(index).val()+
					   "','workLog':'"+$('div.time-main .time-ul .list #workLog').eq(index).val().replace(/'/g,'\\\'').replace(/\n/g,'\\n')+"'},";
				 }else if ('设计系统测试用例'==worktypeVal){
					 c=c+"{'workdate':'"+$('div.time-main .time-ul .list #beginTime').eq(index).val().substring(0,10)+
	                 "','beginTime':'"+$('div.time-main .time-ul .list #beginTime').eq(index).val()+
	                 // "','timedif':'"+$('div.time-main .time-ul .list #timedif').eq(index).html()+
	                 "','timedif':'0"+
					   "','endTime':'"+$('div.time-main .time-ul .list #endTime').eq(index).val()+
					   "','projectid':'"+projectid+
					   "','workTypeid':'"+$('div.time-main .time-ul .list #workType').eq(index).val()+
					   "','numname':'设计测试用例数量"+
					   "','num':'"+worklog+"'},"; 
					 a=a+"{'workdate':'"+$('div.time-main .time-ul .list #beginTime').eq(index).val().substring(0,10)+
	                 "','beginTime':'"+$('div.time-main .time-ul .list #beginTime').eq(index).val()+
	                 "','timedif':'"+$('div.time-main .time-ul .list #timedif').eq(index).html()+
					   "','endTime':'"+$('div.time-main .time-ul .list #endTime').eq(index).val()+
					   "','projectid':'"+projectid+
					   "','workTypeid':'"+$('div.time-main .time-ul .list #workType').eq(index).val()+
					   "','workLog':'"+$('div.time-main .time-ul .list #workLog').eq(index).val().replace(/'/g,'\\\'').replace(/\n/g,'\\n')+"'},";
				 }else if ('修改系统测试用例'==worktypeVal){
					 c=c+"{'workdate':'"+$('div.time-main .time-ul .list #beginTime').eq(index).val().substring(0,10)+
	                 "','beginTime':'"+$('div.time-main .time-ul .list #beginTime').eq(index).val()+
	                 // "','timedif':'"+$('div.time-main .time-ul .list #timedif').eq(index).html()+
	                 "','timedif':'0"+
					   "','endTime':'"+$('div.time-main .time-ul .list #endTime').eq(index).val()+
					   "','projectid':'"+projectid+
					   "','workTypeid':'"+$('div.time-main .time-ul .list #workType').eq(index).val()+
					   "','numname':'修改测试用例数量"+
					   "','num':'"+worklog+"'},"; 
					 a=a+"{'workdate':'"+$('div.time-main .time-ul .list #beginTime').eq(index).val().substring(0,10)+
	                 "','beginTime':'"+$('div.time-main .time-ul .list #beginTime').eq(index).val()+
	                 "','timedif':'"+$('div.time-main .time-ul .list #timedif').eq(index).html()+
					   "','endTime':'"+$('div.time-main .time-ul .list #endTime').eq(index).val()+
					   "','projectid':'"+projectid+
					   "','workTypeid':'"+$('div.time-main .time-ul .list #workType').eq(index).val()+
					   "','workLog':'"+$('div.time-main .time-ul .list #workLog').eq(index).val().replace(/'/g,'\\\'').replace(/\n/g,'\\n')+"'},";
				 }else if ('随机测试'==worktypeVal){
					 c=c+"{'workdate':'"+$('div.time-main .time-ul .list #beginTime').eq(index).val().substring(0,10)+
	                 "','beginTime':'"+$('div.time-main .time-ul .list #beginTime').eq(index).val()+
	                 // "','timedif':'"+$('div.time-main .time-ul .list #timedif').eq(index).html()+
	                 "','timedif':'0"+
					   "','endTime':'"+$('div.time-main .time-ul .list #endTime').eq(index).val()+
					   "','projectid':'"+projectid+
					   "','workTypeid':'"+$('div.time-main .time-ul .list #workType').eq(index).val()+
					   "','numname':'提交BUG数量"+
					   "','num':'"+worklog+"'},"; 
					 a=a+"{'workdate':'"+$('div.time-main .time-ul .list #beginTime').eq(index).val().substring(0,10)+
	                 "','beginTime':'"+$('div.time-main .time-ul .list #beginTime').eq(index).val()+
	                 "','timedif':'"+$('div.time-main .time-ul .list #timedif').eq(index).html()+
					   "','endTime':'"+$('div.time-main .time-ul .list #endTime').eq(index).val()+
					   "','projectid':'"+projectid+
					   "','workTypeid':'"+$('div.time-main .time-ul .list #workType').eq(index).val()+
					   "','workLog':'"+$('div.time-main .time-ul .list #workLog').eq(index).val().replace(/'/g,'\\\'').replace(/\n/g,'\\n')+"'},";
				 }else if ('接收测试'==worktypeVal){
					 c=c+"{'workdate':'"+$('div.time-main .time-ul .list #beginTime').eq(index).val().substring(0,10)+
	                 "','beginTime':'"+$('div.time-main .time-ul .list #beginTime').eq(index).val()+
	                 "','timedif':'0"+
					   "','endTime':'"+$('div.time-main .time-ul .list #endTime').eq(index).val()+
					   "','projectid':'"+projectid+
					   "','workTypeid':'"+$('div.time-main .time-ul .list #workType').eq(index).val()+
					   "','numname':'执行测试用例数量 "+
					   "','num':'"+worklog.substring(0,worklog.indexOf(','))+"'},"; 
					 
					 c=c+"{'workdate':'"+$('div.time-main .time-ul .list #beginTime').eq(index).val().substring(0,10)+
	                 "','beginTime':'"+$('div.time-main .time-ul .list #beginTime').eq(index).val()+
	                 "','timedif':'0"+
					   "','endTime':'"+$('div.time-main .time-ul .list #endTime').eq(index).val()+
					   "','projectid':'"+projectid+
					   "','workTypeid':'"+$('div.time-main .time-ul .list #workType').eq(index).val()+
					   "','numname':'提交BUG数量"+
					   "','num':'"+worklog.substring(worklog.indexOf(',')+1)+"'},"; 
					 
					 a=a+"{'workdate':'"+$('div.time-main .time-ul .list #beginTime').eq(index).val().substring(0,10)+
	                 "','beginTime':'"+$('div.time-main .time-ul .list #beginTime').eq(index).val()+
	                 "','timedif':'"+$('div.time-main .time-ul .list #timedif').eq(index).html()+
					   "','endTime':'"+$('div.time-main .time-ul .list #endTime').eq(index).val()+
					   "','projectid':'"+projectid+
					   "','workTypeid':'"+$('div.time-main .time-ul .list #workType').eq(index).val()+
					   "','workLog':'"+$('div.time-main .time-ul .list #workLog').eq(index).val().replace(/'/g,'\\\'').replace(/\n/g,'\\n')+"'},"; 
				 }else if ('执行系统测试'==worktypeVal){
					 c=c+"{'workdate':'"+$('div.time-main .time-ul .list #beginTime').eq(index).val().substring(0,10)+
	                 "','beginTime':'"+$('div.time-main .time-ul .list #beginTime').eq(index).val()+
	                 "','timedif':'0"+
					   "','endTime':'"+$('div.time-main .time-ul .list #endTime').eq(index).val()+
					   "','projectid':'"+projectid+
					   "','workTypeid':'"+$('div.time-main .time-ul .list #workType').eq(index).val()+
					   "','numname':'执行测试用例数量 "+
					   "','num':'"+worklog.substring(0,worklog.indexOf(','))+"'},"; 
					 
					 c=c+"{'workdate':'"+$('div.time-main .time-ul .list #beginTime').eq(index).val().substring(0,10)+
	                 "','beginTime':'"+$('div.time-main .time-ul .list #beginTime').eq(index).val()+
	                 "','timedif':'0"+
					   "','endTime':'"+$('div.time-main .time-ul .list #endTime').eq(index).val()+
					   "','projectid':'"+projectid+
					   "','workTypeid':'"+$('div.time-main .time-ul .list #workType').eq(index).val()+
					   "','numname':'提交BUG数量"+
					   "','num':'"+worklog.substring(worklog.indexOf(',')+1)+"'},"; 
					 
					 a=a+"{'workdate':'"+$('div.time-main .time-ul .list #beginTime').eq(index).val().substring(0,10)+
	                 "','beginTime':'"+$('div.time-main .time-ul .list #beginTime').eq(index).val()+
	                 "','timedif':'"+$('div.time-main .time-ul .list #timedif').eq(index).html()+
					   "','endTime':'"+$('div.time-main .time-ul .list #endTime').eq(index).val()+
					   "','projectid':'"+projectid+
					   "','workTypeid':'"+$('div.time-main .time-ul .list #workType').eq(index).val()+
					   "','workLog':'"+$('div.time-main .time-ul .list #workLog').eq(index).val().replace(/'/g,'\\\'').replace(/\n/g,'\\n')+"'},";
				 }else if ('回归缺陷'==worktypeVal){
					 c=c+"{'workdate':'"+$('div.time-main .time-ul .list #beginTime').eq(index).val().substring(0,10)+
	                 "','beginTime':'"+$('div.time-main .time-ul .list #beginTime').eq(index).val()+
	                 "','timedif':'0"+
					   "','endTime':'"+$('div.time-main .time-ul .list #endTime').eq(index).val()+
					   "','projectid':'"+projectid+
					   "','workTypeid':'"+$('div.time-main .time-ul .list #workType').eq(index).val()+
					   "','numname':'回归BUG数量 "+
					   "','num':'"+worklog+"'},"; 
					 
					 a=a+"{'workdate':'"+$('div.time-main .time-ul .list #beginTime').eq(index).val().substring(0,10)+
	                 "','beginTime':'"+$('div.time-main .time-ul .list #beginTime').eq(index).val()+
	                 "','timedif':'"+$('div.time-main .time-ul .list #timedif').eq(index).html()+
					   "','endTime':'"+$('div.time-main .time-ul .list #endTime').eq(index).val()+
					   "','projectid':'"+projectid+
					   "','workTypeid':'"+$('div.time-main .time-ul .list #workType').eq(index).val()+
					   "','workLog':'"+$('div.time-main .time-ul .list #workLog').eq(index).val().replace(/'/g,'\\\'').replace(/\n/g,'\\n')+"'},";
				 }else{
					 
					if($('div.time-main .time-ul .list #workLog').eq(index).val().replace(/\n|\s/g,"").trim().length<5){
							alert("第"+(index+1)+"个工时模块工作内容长度不能小于5个字!");
							a="";
							return false;
					}
					 a=a+"{'workdate':'"+$('div.time-main .time-ul .list #beginTime').eq(index).val().substring(0,10)+
	                 "','timedif':'"+$('div.time-main .time-ul .list #timedif').eq(index).html()+
	                 "','beginTime':'"+$('div.time-main .time-ul .list #beginTime').eq(index).val()+
					   "','endTime':'"+$('div.time-main .time-ul .list #endTime').eq(index).val()+
					   "','projectid':'"+projectid+
					   "','workTypeid':'"+$('div.time-main .time-ul .list #workType').eq(index).val()+
					   "','workLog':'"+$('div.time-main .time-ul .list #workLog').eq(index).val().replace(/'/g,'\\\'').replace(/\n/g,'\\n')+"'},";
				 }
				     index++;
				    
				if (index ==$('div.time-main .time-ul .list:last').index()){
					
						// 判断工时是否小于8小时
						if((timeSum*60*60*1000)<(8*60*60*1000)){
							alert("工时小于8小时!");
							a="";
							return false;
						}
					return false;
				}
			});
			
		   a=a.substring(0,a.length-1)+"]";
		   c=c.substring(0,c.length-1)+"]";
		
		   array[0]=a;
		   array[1]=c;
		 
			return array;
		}
	
	// 选择日期
	function getWorkingHours(){

		var userid = $("#userName").val();
		var deptid = $("#deptNm").val();
		var workdate=$("#workdate").val();
		
		if(userid==""){
			$(".table tbody").html("");	
			$("table.table1 tbody").html("");	
			return false;
		}
	
		$.ajax({
			type:"POST",
			url:"selectWorkingHours.do",
			data:{
				userid:userid,	
				deptid:deptid,
				workdate:workdate
			},
			success:function(data){

				$(".table tbody").empty();
				var sumWorkinghours=0;  //工时合计
				for (var i = 0;i<data.length;i++){
					// 判断是不是登录用户本人操作，如果是，则显示出删除和编辑 ；否则，不显示
					if (data[i].userid == $("#userid").val()){
						
						if (data[i].status != "已确认"){
							
							 $(".table tbody").append("<tr><td width='5%'>"+(i+1)+"</td>"+
								        "<td width='10%'>"+(data[i].projectName==null?'':data[i].projectName)+"</td>"+
								        "<td width='10%'>"+(data[i].worktype==null?'':data[i].worktype)+"</td>"+
								        "<td width='10%'>"+(data[i].begintime==null?'':data[i].begintime)+"</td>"+
								        "<td width='10%'>"+(data[i].endtime==null?'':data[i].endtime)+"</td>"+
								        "<td width='5%'>"+(data[i].wh==null?'':data[i].wh)+"</td>"+
								        "<td width='20%' class='box-table-more-con'>  <span class='t-more'>"+(data[i].workcontent==null?'':data[i].workcontent)+
								        "</span><a href='#' class='t-more-add'>显示全部</a></td>" +
								        "<td width='5%'>"+(data[i].status==null?'':data[i].status)+"</td>"+
								        "<td width='10%' class='boxcon1'> <span class='tmore1'>"+(data[i].reason==null?'':data[i].reason)+"</span><a href='#' class='t1'>显示全部</a></td>"+
								        "<td width=''><div class='box-table-edit' title='编辑'><i class='icon' onclick='editWork("+data[i].id+")'></i></div>"+
								        "<div class='box-table-del' title='删除'>"+										 
						                "<i class='icon' onclick=\"workDelete('"+data[i].id+"','"+data[i].begintime+"','"+data[i].endtime+"','"+data[i].projectid+"','"+data[i].worktypeid+"');\"></i></div></td></tr>"
								        );
							
						}else{
							
							 $(".table tbody").append("<tr><td width='5%'>"+(i+1)+"</td>"+
								        "<td width='10%'>"+(data[i].projectName==null?'':data[i].projectName)+"</td>"+
								        "<td width='10%'>"+(data[i].worktype==null?'':data[i].worktype)+"</td>"+
								        "<td width='10%'>"+(data[i].begintime==null?'':data[i].begintime)+"</td>"+
								        "<td width='10%'>"+(data[i].endtime==null?'':data[i].endtime)+"</td>"+
								        "<td width='5%'>"+(data[i].wh==null?'':data[i].wh)+"</td>"+
								        "<td width='20%' class='box-table-more-con'>  <span class='t-more'>"+(data[i].workcontent==null?'':data[i].workcontent)+
								        "</span><a href='#' class='t-more-add'>显示全部</a></td>" +
								        "<td width='5%' > "+(data[i].status==null?'':data[i].status)+"</td>"+
								        "<td width='10%' class='boxcon1'> <span class='tmore1'>"+(data[i].reason==null?'':data[i].reason)+"</span><a href='#' class='t1'>显示全部</a></td>"+
								        "<td width=''></td></tr>"
								        );
							
						}
					
					 
					}else{		
						 $(".table tbody").append("<tr><td width='5%'>"+(i+1)+"</td>"+
							        "<td width='10%'>"+(data[i].projectName==null?'':data[i].projectName)+"</td>"+
							        "<td width='10%'>"+(data[i].worktype==null?'':data[i].worktype)+"</td>"+
							        "<td width='15%'>"+(data[i].begintime==null?'':data[i].begintime)+"</td>"+
							        "<td width='15%'>"+(data[i].endtime==null?'':data[i].endtime)+"</td>"+
							        "<td width='5%'>"+(data[i].wh==null?'':data[i].wh)+"</td>"+
							        "<td width='20%' class='box-table-more-con'>  <span class='t-more'>"+(data[i].workcontent==null?'':data[i].workcontent)+
							        "</span><a href='#' class='t-more-add'>显示全部</a></td>" +
							        "<td width='20%'></td></tr>"
							        );
		
					}
					
					sumWorkinghours += data[i].wh;
					
				}
				
				// 工时合计 table 
				$("table.table1 tbody").empty();
				if (sumWorkinghours !=0){
					$("table.table1 tbody").append("<tr>"+
									    "<td width='5%'></td>"+
										"<td width='10%'></td>"+
										"<td width='10%'></td>"+
										"<td width='15%'></td>"+
										"<td width='15%' style='text-align: right;'>合计:</td>"+
										"<td width='5%' style='text-align: left;'>"+sumWorkinghours+"</td>"+
										"<td width='20%'></td>"+
										"<td width='20%'></td></tr>")
				}
				// 表格限制
				$('.t-more-add').hide();
				$(".table tr td.box-table-more-con").each(function(i){
				        if( $(this).text().length > 40 ){
				        	//console.log($(this).text().length);
				        	$(this).find('.t-more').hide();
				        	$(this).find('.t-more-add').show();
				        }
				});
				$('.t-more-add').on("click",function(){
					if($(this).text() == "显示全部"){
						$(this).parent().find('.t-more').show();
						$(this).text('隐藏');
					}else{
						$(this).parent().find('.t-more').hide();
						$(this).text('显示全部');
					}
						
				});
				
				//表格限制
				$('.t1').hide();
				$(".table tr td.boxcon1").each(function(i){
					
				        if( $(this).text().length>5){
				        	//console.log($(this).text().length);
				        	$(this).find('.tmore1').hide();
				        	$(this).find('.t1').show();
				        }
				});
				$('.t1').on("click",function(){
					if($(this).text() == "显示全部"){
						$(this).parent().find('.tmore1').show();
						$(this).text('隐藏');
					}else{
						$(this).parent().find('.tmore1').hide();
						$(this).text('显示全部');
					}
						
				});
			}
		});	
	};
	
   // 未填报工时
	$("#emptyWorkHours").on('click',function(){
		$.ajax({
			type:"post",
			url:"filterWorkDate.do",
			success:function(data){
				$("div.emptyWorkHours").css('display','inline-block');
				$("div.emptyWorkHours").html('');
				
				$("div.emptyWorkHours").append("<i class='menuBn' id='menuBn' onclick='aa()'></i>");
				$("div.emptyWorkHours").append("<select class='new_select_work' style='width:150px;' onchange='AddWorkHours(this.value)'>" +
						"<option value='' selected='selected'>请选择</option></select>");
				
				for(var i =0;i<data.length;i++){
					$("div.emptyWorkHours select").append("<option> "+data[i].date+" </option>");	
				}
			}
		});
	});
	
	// 未填报工时菜单上的消除按钮
	function aa(){	
		$("div.emptyWorkHours").css('display','none');
	};
	
	// 跳转工时填报页面
	function AddWorkHours(date){
		window.location.href="addWorkingHours.html?date="+date;
	}
	
   // 查询未填报工时的员工
	$("#workdate1").on('change',function(){
		
		$.ajax({
			url:'selectEmptyWork.do',
			data:{
				whdate:this.value
			},
			success:function(data){
				var s = "";
				$('table.table tbody').empty();
				if (data != null){
					for (var i =0;i<data.length;i++){
						s+="<tr><td width='10%'>"+(i+1)+"</td><td width='30%'>"+data[i].name+"</td></tr>";
												
					}
				
					$('table.table tbody').append(s);
				}else{			
					s+="<tr><td width='10%'>"+(i+1)+"</td><td width='30%'></td></tr>";
					$('table.table tbody').append(s);
				}
			}
		});	
	});
	
	// 未填工时人员页面 加载时 
	function setWhDate(){
		var maxTime =new Date();
		 $(".form-datetime").datetimepicker({
				minView: "month", //选择日期后，不会再跳转去选择时分秒 
				language:  'zh-CN',
				format: 'yyyy-mm-dd',
				todayBtn: 1,
				autoclose: 1,
				endDate: maxTime,
			});
			
			var currentDate=getCurrentDate().substring(0,10);
			$("#workdate1").attr("value",currentDate);
	}
	
	// 选择部门时重新生成用户菜单
	function getNewUserName(){
		var deptid = $("#deptNm").val();
		
		$.ajax({
			url:"selectNewUserName.do",
			data:{
				deptid:deptid
			},
			success:function(data){
			   var a ="<option value=''>请选择</option>";
			   $("#userName").html('');
			   for (var i =0;i<data.length;i++){
				   a+="<option value="+data[i].id+">"+data[i].name+"</option>";
			   }
			   $("#userName").append(a);
			   $("#userName").bind('change',getWorkingHours());

			  $('#userName').comboSelect();
			  $('#deptNm').comboSelect();
			}	
		});
	}
	
	// 工时编辑
	function editWork(workHoursid){
	  window.location.href="editWorkHours.do?workHoursid="+workHoursid;
		
	}
	
	// 工作类型是请假时，时间设置
	  function addHolidayTime(e){
		  // 获取工时填报模块的个数
	    	var count= $(e).parents('body').find('form').length;
		    if(count>1){
		    	return
		    }
	     if ($(e).find("option:selected").text()=="日常-整天请假" ){
	    	 $(e).parent().prev().find('option[value=413]').prop('selected',true);
	    	 $(e).parent().prev().find('select').prop('disabled',true);
		  $(e).parent().next().find('span').text('[*整天请假 指 请假开始日的8:30 到 请假结束日的17:30]');
		  
	    $('#beginTime,#endTime').val("");
	    $("#timedif").text('');
	    
	     $('#beginTime').datetimepicker('remove');
	    	 
	    	//开始时间
	  		$("#beginTime").datetimepicker({
	  			language: 'zh-CN',
	  			startDate:getCurrentDate(),
	  			format: 'yyyy-mm-dd 08:30',
	  			minView: "month",
	  		    todayHighlight: false,
	  		    showMeridian: true,
	  			autoclose: true
	  		}).on('changeDate', function() {
	  			$("#endTime").datetimepicker('remove');
	  			begintime = $("#beginTime").val();
	  		    
	  			//结束时间
	  			$('#endTime').datetimepicker({
	  				startDate: begintime,
	  				language: 'zh-CN',
	  				format: 'yyyy-mm-dd 17:30',
	  				todayHighlight: false,
	  				minView: "month",
	  				autoclose: true,
	  			    showMeridian: true
	  			})
	  		}); 	
	  		
	  		$('#beginTime,#endTime').on('changeDate',function(){
	  			// 如果结束日期为空,不做时间差运算
                 if ($('#endTime').val()==""){
                	 return
                 }
  				$.ajax({
  	            	type:"Post",
  	            	url:"holidayTimeCount.do",
  	            	data:{
  	            		beginTime:$("#beginTime").val(),
  	            		endTime:$("#endTime").val()
  	            	},
  	            	success:function(data){	
  	            		$("#timedif").text(data);
  	            		//param1 是否有值决定提交走的方法   
  	            		$("#param1").val(data);
  	            	}
  	            	
  	            });
  			});
	  		//清空时长
	  		$('.time-add').prop('style').display="none";
	     }else{
	    	
	    	  /* if ($("#param1").val()==""){
	    	    	return
	    	    }*/
	    	   if($('#beginTime').val()!='' && $('#endTime').val()!=''&& $('#param1').val()==''){
	    		   
	    	   }else{
	    		   $('#beginTime,#endTime').val("");
		    		 $("#timedif").text('');
		    		 $(e).parent().prev().find('select').prop('disabled',false);
	    	   }
	    	   
	    		// 添加按钮 为显示
	    		$('.time-add').prop('style').display="inline-block";
	    		$(e).parent().next().find('span').text('[*不少于5个字]');
	    		/*$('#beginTime,#endTime').val("");
	    		 $("#timedif").text('');*/
	    		 $("#param1").val('');
	    		 $('#beginTime').datetimepicker('remove');
	    		 var maxTime = getCurrentDate();
	    		 $('#beginTime,#endTime').unbind('changeDate');
    			//开始时间
	    		 $('#beginTime').datetimepicker({
    				language: 'zh-CN',
    				format: 'yyyy-mm-dd hh:ii',
    				minuteStep: 30,
    				endDate:maxTime,
    				showMeridian: true,
    				autoclose: true
    			}).on('changeDate', function() {
    				 $('#endTime').datetimepicker('remove');
            		//结束时间
    				$('.end-time').datetimepicker({
    					startDate: $('#beginTime').val(),
    					language: 'zh-CN',
    					format: 'yyyy-mm-dd hh:ii',
    					endDate:maxTime,
    					minuteStep: 30,
    					showMeridian: true,
    					autoclose: true
    				});
    			});
	  }
	}
	  
// 根据项目名查出子项目
function selectSubProject1(e){
	var a = $(e).find("option:selected").val();
	//alert(a.substring(a.indexOf(';')+1))
	$.ajax({
		url:"selectSubProjectList_Work.do",
		data:{
			projectid:a
		},
		success:function(data){
			var a="";
			$(e).parent().next().find('#subprojectname:first').find("option").remove();
			$(e).parent().next().find('#subprojectname:first').append("<option value='0'>请选择</option>");
			for (var i=0;i<data.length;i++){
				a+="<option value="+data[i].id+">"+data[i].subprojectname+"</option>";
			}
			$(e).parent().next().find('#subprojectname:first').append(a);
		}
		
	});

}
