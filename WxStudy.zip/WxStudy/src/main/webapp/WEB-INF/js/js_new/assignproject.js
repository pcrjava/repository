
 //根据项目名称查询项目函数   
$("#projectSearch").on('input',function(e){  
	   getProjectSearch(); 
}); 

$("#projectusername").on('input',function(e){  
	getUserByProjectSearchUser();
});

	//查询项目名称
	function getProjectSearch(){
		//项目名称关键字
		var projectname=$("#projectSearch").val();
	
		$.ajax({
			type:"POST",
			//url:basepath+'serachProject.do',
			url:"serachProject.do",
			data:{ 
				projectName:projectname
			},  
			success:function(data){

				$('#assignproject').empty();
				for (var i = 0;i<data.length;i++){


					 
					 $('#assignproject').append('<li>' +
			 		'<div class="list-con" id="assign' + data[i].id + '" onclick="showassign('+data[i].id+',\''+data[i].projectName+'\')">' +
			 				'<div class="con-tt">' +
			 					'<div class="con-icon"></div><span>'+(data[i].projectName==null?"":data[i].projectName)+'</div>'+
					        '<div class="con-line"></div>'+
					        /*'<p class="con-sub-tt con-num">参与人数 : 20</p>'+*/
					        '<div class="con-users"><div class="con-name">'+(data[i].projectLeader==null?"":data[i].projectLeader.substring(0,1))+'</div></div>'+
					        '</div></li>'
			);
					
				}	 
			} 
		});	
	};
	 
	//查询未参加项目的人员
	function selectuser(depid) {
		depid = $('#depID').val();
		 
		if(null == depid || depid == 0)
			depid = 0; 
		$.ajax({ 
			type:"POST",
			//url:basepath+'serachProject.do',
			url:"getUnAssignUsers.do",
			data:{ 
				projectid:oldprojectid,
				depid:depid,
				userName:''
			},  
			success:function(data){

				$('#showusers').empty();
				
				 
				for (var i = 0;i<data.length;i++){
					 $('#showusers').append("<li>" +
					 		"<div class='list-con' id='unassignuser" + data[i].userid + "' onclick='addassignuser("+data[i].userid+")'>" +
					 				"<div class='con-tt'>" +
					 					"<div class='con-icon'></div><span>"+(data[i].name==null?'':data[i].name)+"</span><span class='con-user-info'>("+data[i].account+"/"+data[i].name+")</span></div>"+
							       
							        "<div class='con-line'></div>"+
							       /* "<p class='con-sub-tt con-num'>参与人数 : 20</p>"+*/
							        "<div></div>"+
							        "</div></li>"
					);
					 
				}	
			} 
		});	
	}
	
	
	//根据项目ID查询项目人员
	function getUserByProjectSearch(projectid,projectname){
		oldprojectid = projectid;
	var username = '';
		$.ajax({
			type:"POST",
			//url:basepath+'serachProject.do',
			url:"getUserByProject.do",
			data:{ 
				projectid:projectid,
				username:username
			},  
			success:function(data){

				$('#assignuserproject1').empty();
				
				 $('.tag-user-02 .box-title h2').empty();
				 $('.tag-user-02 .box-title h2').append(projectname);
				if($('.tag-user-02 .box-title h2').html().length>'15'){
					var values = $('.tag-user-02 .box-title h2').html();
					$(".tag-user-02 .box-title h2").css({"white-space":"nowrap","overflow":"hidden","text-overflow":"ellipsis"});
					$(".tag-user-02 .box-title h2").hover(function(){
						$(".tag-user-02 .box-title h2").attr('atr',values);
					});
				}
				for (var i = 0;i<data.length;i++){
					 $('#assignuserproject1').append("<li>" +
					 		"<div class='list-con' id='assignuser" + data[i].id + "'>" +
					 				"<div class='con-tt'>" +
					 					"<div class='con-icon'></div><span>"+(data[i].name==null?'':data[i].name)+"</span><span class='con-user-info'>("+data[i].account+"/"+data[i].name+")</span></div>"+
							       
							        "<div class='con-line'></div>"+
							        /*"<p class='con-sub-tt con-num'>参与人数 : 20</p>"+*/
							        "<div class='con-del' onclick='delprojectuser("+data[i].id+")'><i class='line'></i></div>"+
							        "</div></li>"
					);
					
				}	
			} 
		});	
		
		
		$('div.allot-ul .second').fadeIn();
		//剧场隐藏
		$('div.allot-ul .second .box-tag, div.allot-ul .third .box-tag').fadeOut();
		$('div.allot-ul .third').fadeOut();
		//入场 
		$('div.allot-ul .second .tag-user-02').fadeIn();
		//按钮复位
		$("div.allot-ul .second .box-btn-save,div.allot-ul .third .box-btn-save").removeClass("box-btn-down");
		$("div.allot-ul .second .box-btn-save,div.allot-ul .third .box-btn-save").removeClass("box-info-show");

		
	};
	var oldprojectid;
	//根据项目ID查询项目人员
	function getUserByProjectSearchUser(){
		var username=$("#projectusername").val();
		$.ajax({ 
			type:"POST",
			//url:basepath+'serachProject.do',
			url:"getUserByProject.do",
			data:{ 
				projectid:oldprojectid,
				username:username
			},  
			success:function(data){

				$('#assignuserproject1').empty(); 
				 
				for (var i = 0;i<data.length;i++){
					 $('#assignuserproject1').append("<li>" +
					 		"<div class='list-con' id='assignuser" + data[i].id + "'>" +
					 				"<div class='con-tt'>" +
					 					"<div class='con-icon'></div><span>"+(data[i].name==null?'':data[i].name)+"</span><span class='con-user-info'>("+data[i].account+"/"+data[i].name+")</span></div>"+
							       
							        "<div class='con-line'></div>"+
							        /*"<p class='con-sub-tt con-num'>参与人数 : 20</p>"+*/
							        "<div class='con-del'onclick='delprojectuser("+data[i].id+")'><i class='line'></i></div>"+
							        "</div></li>"
					);
					
				}	 
			} 
		});	
		
		
		
		
	};
	var assignuserid = 0;
	//选择用户
	function addassignuser(userid) {
		assignuserid = userid;
		//$(this).parent().parent().find(".list-con").removeClass("list-con-now");
		$("#showusers div").removeClass("list-con-now");
		$('#unassignuser'+userid).addClass("list-con-now");
		
		
		
	}   
	//分配项目添加方法
	function saveassignuser(){ 
	
		if(assignuserid<=0 || oldprojectid <= 0){
			 
			$(this).addClass("box-btn-down");
			var errorboxBtn = $('#box-info-error');
			errorboxBtn.addClass("box-info-show"); 
			 
			setTimeout(function() {
				errorboxBtn.removeClass("box-info-show");
			}, 1500); 
			
			//重新加载项目人员和未参加项目人员
			getUserByProjectSearchUser();
			selectuser(0);
			return;
		}else {
			
			
			$.ajax({ 
				type:"POST",
				//url:basepath+'serachProject.do',
				url:"addAssignProjectUser.do",
				data:{ 
					projectid:oldprojectid,
					userid:assignuserid
				},  
				success:function(data){
					
					if(data == "1"){
						
						//弹出提示信息
						$(this).addClass("box-btn-down");
						var successboxBtn = $('#box-info-success');
						successboxBtn.addClass("box-info-show"); 
						
						setTimeout(function() {
							successboxBtn.removeClass("box-info-show"); 
						}, 1500);
						//重新加载项目人员和未参加项目人员
						getUserByProjectSearchUser();
						selectuser(0);
					}else{
						
						$(this).addClass("box-btn-down");
						var errorboxBtn = $('#box-info-error');
						errorboxBtn.addClass("box-info-show"); 
						 
						setTimeout(function() {
							errorboxBtn.removeClass("box-info-show");
						}, 1500); 
					}

						 
					}	 
				});	
			
			
		} 
		//重新加载项目人员和未参加项目人员
		getUserByProjectSearchUser();
		selectuser(0);
		
	}   
	
	//显示项目
	function showassign(pid,projectname) {
	
		$('.list-con-now').removeClass("list-con-now");
		$('#assign'+pid).addClass("list-con-now");
		
		getUserByProjectSearch(pid,projectname); 
			}
	//删除项目中的人员
	function delprojectuser(id) {
		
		$.ajax({ 
			type:"POST",
			//url:basepath+'serachProject.do',
			url:"delProjectUser.do",
			data:{ 
				id:id
			},  
			success:function(data){
				if(data=='success'){
					getUserByProjectSearchUser();
					selectuser(0); 
					alert("删除成功！");					
					 
				} 					
				else
					alert("删除失败！");
				 
			} 
		});	
		
		
	}
	
//
	//加载部门信息begin 
	function loadDepInfo(uri){
		// 获取隐藏域中的部门ID
		
		URI = uri;
		$.ajax({
			type:"POST",
			dataType:"text",
			url: uri +'loadDepInfo.do',
			async:false,
			dataType:"text",
			success:function(data) {
				// alert(data);
				$(eval("(" + data +")")).each(function() {
					//if (this.id == hiddenDeptid) {
					//	$("#depID").append("<option selected = 'selected' value='" + this.id + "'>" + this.deptName + "</option>");
					//	loadTeamInfo();
					//} else{
						$("#depID").append("<option value='" + this.id + "'>" + this.deptName + "</option>");
					//}
				});
			}
		});
	}
	//部门信息加载结束
	
	
	
	
	
	
	
	
	
	
	
	
	
/**********************************************按人员分配项目******************************************/
	var assingprojectid;
	
	//按人员分配，查询人员名称实现查询方式
	$("#UserSearch").on('input',function(e){  
		showuserbyname();
	}); 
	//按项目名称查询参与的项目动态显示
	$("#assignuserprojectserach2").on('input',function(e){  
		showuserproject();
	}); 
	//按项目名称查询未参与的项目 
	$("#serachunAssignProject3").on('input',function(e){  
		var projectName = $('#serachunAssignProject3').val();
		
		
		$.ajax({
			type:"POST", 
			//url:basepath+'serachProject.do',
			url:"selectUnAssignProject.do",
			data:{ 
				userid:olduserid,
				projectName:projectName 
				 
			},   
			success:function(data){

				$('#userunAssignProject3').empty();
				
				 
				for (var i = 0;i<data.length;i++){
					 $('#userunAssignProject3').append("<li>" +
					 		"<div class='list-con' id='assignuserproject" + data[i].id + "' onclick='assignuserproject("+data[i].id+")'>" +
					 				"<div class='con-tt'>" +
					 					"<div class='con-icon'></div><span>"+(data[i].projectName==null?'':data[i].projectName)+"</span><span class='con-user-info'></span></div>"+
							            "<div class='con-line'></div>"+/*<p class='con-sub-tt con-num'>参与人数 : 20</p>"+
*/							        "<div class='con-users'><div class='con-name'>"+(data[i].projectLeader==null?"":data[i].projectLeader.substring(0,1))+"</div></div>"+
							        "</div></li>"
					);
					  
				}	 
			} 
		});	
	}); 
	
	
	
	//项目分配-TAG切换
	$('ul.distribution-menu li').on("click",function() {
		var li_num = $(this).index();
		$('div.allot-ul .second, div.allot-ul .second .tag-user-02, div.allot-ul .second .tag-project-02').fadeOut();
		$('div.allot-ul .third').fadeOut();
	
		if( li_num == 0 ){
			
			getProjectSearch(); 
			$('div.tag-project').fadeIn();
			$('div.tag-user').fadeOut();
			$('h2.box-title-first').text("项目分配");
			
		}
		
		if( li_num == 1 ){
			
			$.ajax({
				type:"POST",
				//url:basepath+'serachProject.do',
				url:"getUnAssignUsers.do",
				data:{ 
					projectid:0,
					depid:0,
					userName:''
				},  
				success:function(data){

					$('#assignuserproject2').empty();
					 
					 
					for (var i = 0;i<data.length;i++){
						 $('#assignuserproject2').append("<li>" +
						 		"<div class='list-con' id='assignuser" + data[i].userid + "' onclick='clickshowuserproject("+data[i].userid+",\""+data[i].name+"\")'>" +
						 				"<div class='con-tt'>" +
						 					"<div class='con-icon'></div><span>"+(data[i].name==null?'':data[i].name)+"</span><span class='con-user-info'>("+data[i].account+"/"+data[i].name+")</span></div>"+
								       
								        "<div class='con-line'></div>"+
								       /* "<p class='con-sub-tt con-num'>参与人数 : 20</p>"+*/
								        "<div></div>"+
								        "</div></li>"
						);
						
					}	
				} 
			});	
			
			
			$('div.tag-project').fadeOut();
			$('div.tag-user').fadeIn();
			$('h2.box-title-first').text("人员分配");
		}
	});
	
	function showuserbyname() {
		var username = $('#UserSearch').val();
		

		 
		$.ajax({
			type:"POST",
			//url:basepath+'serachProject.do',
			url:"getUnAssignUsers.do",
			data:{ 
				projectid:0,
				depid:0,
				userName:username
			},  
			success:function(data){

				$('#assignuserproject2').empty();
				
				 
				for (var i = 0;i<data.length;i++){
					 $('#assignuserproject2').append("<li>" +
					 		"<div class='list-con' id='assignuser" + data[i].userid + "' onclick='clickshowuserproject("+data[i].userid+",\""+data[i].name+"\")'>" +
					 				"<div class='con-tt'>" +
					 					"<div class='con-icon'></div><span>"+(data[i].name==null?'':data[i].name)+"</span><span class='con-user-info'>("+data[i].account+"/"+data[i].name+")</span></div>"+
							       
							        "<div class='con-line'></div>"+
							       /* "<p class='con-sub-tt con-num'>参与人数 : 20</p>"+*/
							        "<div></div>"+
							        "</div></li>"
					);
					
				}	
			} 
		});	
		
		
//		$('div.tag-project').fadeOut();
//		$('div.tag-user').fadeIn();
//		$('h2.box-title-first').text("人员分配");
	
		
	}
	
//	$('#assignuserproject2 div .list-con').on("click",function() {
//		$('div.allot-ul .second').fadeIn();
//		//剧场隐藏
//		$('div.allot-ul .second .box-tag, div.allot-ul .third .box-tag').fadeOut();
//		$('div.allot-ul .third').fadeOut();
//		//入场
//		$('div.allot-ul .second .tag-project-02').fadeIn();
//		//按钮复位
//		$("div.allot-ul .second .box-btn-save,div.allot-ul .third .box-btn-save").removeClass("box-btn-down");
//		$("div.allot-ul .second .box-btn-save,div.allot-ul .third .box-btn-save").removeClass("box-info-show");
//	}); 
//	
	var olduserinfo;
	var olduserid;
	function clickshowuserproject(userid,username){
		
		$("#assignuserprojecttitle2 h2").empty();
		olduserinfo =username ;
		//根据传输的ID动态修改选择样式
		$('#assignuserproject2 .list-con-now').removeClass("list-con-now");
		$('#assignuser'+userid).addClass("list-con-now"); 
		olduserid = userid;
		showuserproject(userid,username);
		
		
		$('div.allot-ul .second').fadeIn();
		//剧场隐藏
		$('div.allot-ul .second .box-tag, div.allot-ul .third .box-tag').fadeOut();
		$('div.allot-ul .third').fadeOut();
		//入场
		$('div.allot-ul .second .tag-project-02').fadeIn();
		//按钮复位
		$("div.allot-ul .second .box-btn-save,div.allot-ul .third .box-btn-save").removeClass("box-btn-down");
		$("div.allot-ul .second .box-btn-save,div.allot-ul .third .box-btn-save").removeClass("box-info-show");

	}
	
	
	//根据人员查询项目
function showuserproject(userid,username) {
	var projectName = $("#assignuserprojectserach2").val();
	$("#assignuserprojecttitle2 h2").empty();
	$("#assignuserprojecttitle2 h2").append(username);

	$.ajax({
		type:"POST", 
		//url:basepath+'serachProject.do',
		url:"getProjectByUser.do",
		data:{ 
			userid:olduserid,
			projectName:projectName 
			 
		},  
		success:function(data){

			$('#ulassignuserproject2').empty();
			
			 
			for (var i = 0;i<data.length;i++){
				 $('#ulassignuserproject2').append("<li>" +
				 		"<div class='list-con' id='assignuser" + data[i].userid + "' onclick='showuserproject("+data[i].userid+")'>" +
				 				"<div class='con-tt'>" +
				 					"<div class='con-icon'></div><span>"+(data[i].projectName==null?'':data[i].projectName)+"</span><span class='con-user-info'></span></div>"+
						            "<div class='con-line'></div>"+/*<p class='con-sub-tt con-num'>参与人数 : 20</p>"+
*/						        "<div class='con-del'onclick='deluserproject("+data[i].id+")'><i class='line'></i></div>"+
						        "</div></li>"
				);
				 
			}	 
		} 
	});	
	
}
//点击竟然添加项目界面
function addproject() {
	
	var projectName = $('#userunAssignProjectSearch3').val();
	
	
	$.ajax({
		type:"POST", 
		//url:basepath+'serachProject.do',
		url:"selectUnAssignProject.do",
		data:{ 
			userid:olduserid,
			projectName:projectName 
			 
		},   
		success:function(data){

			$('#userunAssignProject3').empty();
			
			 
			for (var i = 0;i<data.length;i++){
				 $('#userunAssignProject3').append("<li>" +
				 		"<div class='list-con' id='assignuserproject" + data[i].id + "' onclick='assignuserproject("+data[i].id+")'>" +
				 				"<div class='con-tt'>" +
				 					"<div class='con-icon'></div><span>"+(data[i].projectName==null?'':data[i].projectName)+"</span><span class='con-user-info'></span></div>"+
						            "<div class='con-line'></div>"+/*<p class='con-sub-tt con-num'>参与人数 : 20</p>"+
*/						        "<div class='con-users'><div class='con-name'>"+(data[i].projectLeader==null?"":data[i].projectLeader.substring(0,1))+"</div></div>"+
						        "</div></li>"
				);
				 
			}	 
		} 
	});	
	
	$('div.allot-ul .third').fadeIn();
	//剧场隐藏
	$('div.allot-ul .third .box-tag').fadeOut();
	//入场
	$('div.allot-ul .third .tag-project-03').fadeIn();
}



function deluserproject(id) { 
	delprojectuser(id);	
}
//选择项目为人员分配
function assignuserproject(id) {
	$('#userunAssignProject3 .list-con-now').removeClass("list-con-now");
	$(' #assignuserproject'+id).addClass("list-con-now");
	
	assingprojectid = id;
	
	 
}

function addassignprojectuser() {
	if(assingprojectid<=0 || olduserid <= 0){
	
		$(this).addClass("box-btn-down");
		var errorboxBtn = $('#box-info-error');
		errorboxBtn.addClass("box-info-show"); 
		 
		setTimeout(function() {
			errorboxBtn.removeClass("box-info-show");
		}, 1500); 
		return;
	}else {
	$.ajax({ 
		type:"POST",
		//url:basepath+'serachProject.do',
		url:"addAssignProjectUser.do",
		data:{ 
			projectid:assingprojectid,
			userid:olduserid 
		},  
		success:function(data){
			
			if(data == "1"){
				addproject();
				showuserproject(olduserid,olduserinfo); 
				//弹出提示信息
				$(this).addClass("box-btn-down");
				var successboxBtn = $('#box-info-success3');
				successboxBtn.addClass("box-info-show"); 
				
				setTimeout(function() {
					successboxBtn.removeClass("box-info-show"); 
				}, 1500); 	
				 
			}else{
				addproject();
				showuserproject(olduserid,olduserinfo); 
				$(this).addClass("box-btn-down");
				var errorboxBtn = $('#box-info-error3');
				errorboxBtn.addClass("box-info-show"); 
				 
				setTimeout(function() {
					errorboxBtn.removeClass("box-info-show");
				}, 1500); 
				 
			}

				 
			}	 
		});	
	}
	
	
}

	