function addProjectManagerEntry(uri) {
	URI = uri;
	window.location.href = URI + "editprojectManagerEntry.html";
}

//根据项目名查出子项目
function selectSubProjectList(){
	$("#projectmanager").val("");
	$("#projectnumber").val(""); 
	$.ajax({ 
		url:"selectSubProjectList.do",
		type:'post',
	    contentType:'application/x-www-form-urlencoded; charset=UTF-8',
		data:{
			projectname:$("#projectname").find("option:selected").val()
		},
		success:function(data){
			var a="";
			$("#subprojectname").find("option").remove();
			$("#subprojectname").append("<option value=''>请选择</option>");
			for (var i=0;i<data.length;i++){
				a+="<option value="+data[i].subprojectcode+">"+data[i].subprojectname+"</option>";
			}
			$("#subprojectname").append(a);
		}
		
	});
}
//根据项目名查出子项目
function selectProjectInfoBySubProject(){
	$.ajax({ 
		url:"selectProjectInfoBySubProject.do",
		type:'post',
		contentType:'application/x-www-form-urlencoded; charset=UTF-8',
		data:{
			subprojectcode:$("#subprojectname").find("option:selected").val()
		},
		success:function(data){
			$("#projectmanager").val(data[0].projectmanagername);
			$("#projectnumber").val(data[0].projectnumber);
			
			$("#hidenprojectid").val(data[0].projectid);
			$("#hidenprojectmanager").val(data[0].projectmanager);
			
		} 
		
	});
}



//提交表单
function save(){
	var projectid =$('#hidenprojectid').val();
	var projectname =$('#projectname').find("option:selected").val();
	var subprojectname =$('#subprojectname').find("option:selected").val();
	var projectnumber =$('#projectnumber').val();
	var costdate =$('#costdate').val();
	var projectmanager =$('#hidenprojectmanager').val();
	var cost =$('#cost').val();	
	var typename =$('#typename').find("option:selected").val();
	var remark =$('#remark').val();
	
	if (projectname ==""){ 
		alert("请选择项目名称!");
		return
	}
	if (subprojectname ==""){
		alert("请选择子项目名称!");
		return
	}
	if (projectnumber ==""){
		alert("请选择项目编号!");
		return
	}
	if (typename == ""){
		alert("请选择类型!");
		return
	}
	if (remark ==""){
		alert("请输入描述!");
		return
	}
	
	
	if (cost == ""){
		alert("请填写成本!");
		return
	}else{
		/*var reg = /(^[0-9]+(.[0-9]{1,4})?$)/;
	        if (!reg.test(cost)) {
	        	alert("请填写正确成本!");
	             return 
	        } 
		*/
	}
	
	
	
	
	if (costdate ==""){
		alert("请选择日期!");
		return
	}
	
	
	if (remark.length > 100){
		alert("备注不能查过100个汉字!");
		return
	}
//	
	$.ajax({
		type:"Post",
		url:"addProjectManagerEntryNew.do",
		data:{
			projectid:projectid,
			subprojectname:subprojectname,
			projectnumber:projectnumber,
			costdate:costdate,
			projectmanager:projectmanager,
			cost:cost,
			typename:typename,
			remark:remark
			
		}, 
		success:function(data){
			if ($("#id").val() !="0"){
				if (data>0){
					alert("保存成功!");
					window.location.href="projectManagerEntry.html";
				}else{
					alert("保存失败!");
				}
			}else{
				if (data>0){
					alert("保存成功!");
					window.location.href="projectManagerEntry.html";
				}else{
					alert("保存失败!");
				}
			}
		}
	});

}



//编辑项目
function updProjectManagerEntryInfo(projectnumber,projectName,subprojectname,projectmanagername,totalcost,subprojectcode,typename) {
		
	window.location.href = "showprojectManagerEntry_New.html?" +
			"projectnumber=" + projectnumber+
			"&projectName=" + encodeURI(encodeURI(projectName)) + 
			"&subprojectname=" + encodeURI(encodeURI(subprojectname))+
			"&projectmanagername="+encodeURI(encodeURI(projectmanagername))+
			"&totalcost="+totalcost+
			"&subprojectcode="+subprojectcode+
			"&typename="+encodeURI(encodeURI(typename));

}

function goback(URI) {
	window.location.href = URI + "projectManagerEntry.html";
}

function delsubprojectmanagerentry(id) {  
	
	if(confirm("确定要删除吗？"))
	{
		$.ajax({
			type:"Post",
			url:"delprojectManagerEntry_New.do",
			data:{
				id:id
				
			}, 
			success:function(data){
				
					if (data>0){
						alert("删除成功!");
						window.location.href="projectManagerEntry.html";
					}else{
						alert("保存失败!");
					}
				
			}
		});
	}
	
	
}


function getProjectManagerEntryByProject(URI) {
	
	
	var projectname =$('#projectname').find("option:selected").val();
	window.location.href = URI + "projectManagerEntry.html?projectname="+encodeURI(encodeURI(projectname));
}


if($('#costdate').val()==''){
	var currentDate=getCurrentDate().substring(0,10);
	$("#costdate").attr("value",currentDate);
}

 // 获取当前时间并且格式化 成 YYYY-MM-DD HH:mm:ss
function getCurrentDate(){
	 var date = new Date();
	    var seperator1 = "-";
	    var seperator2 = ":";
	    var month = date.getMonth() + 1;
	    var strDate = date.getDate();
	    if (month >= 1 && month <= 9) {
	        month = "0" + month;
	    }
	    if (strDate >= 0 && strDate <= 9) {
	        strDate = "0" + strDate;
	    }
	    var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate
	            + " " + date.getHours() + seperator2 + date.getMinutes()
	            + seperator2 + date.getSeconds();
	    return currentdate;
}


