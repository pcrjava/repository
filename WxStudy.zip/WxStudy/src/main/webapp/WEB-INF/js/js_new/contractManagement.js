
 //根据项目名称查询项目函数   
$("#projectSearch").on('input',function(e){  
	   getProjectSearch(); 
}); 

$("#projectusername").on('input',function(e){  
	getUserByProjectSearchUser();
});
function saveC(){
}

window.onload=function(){
	if($("#hiddenInputID").val() == '${type}'){
		//alert(111)
	} else {
		alert($("#hiddenInputID").val())
	}
/*	
	// 给Number类型增加一个mul方法，调用起来更加方便。
	Number.prototype.mul = function (arg,arg2){
	return accMul(arg, arg2);
	}*/

}
function sumAdd(){//input 求和
	var num1 = document.getElementById("num1").value;
	var num2 = document.getElementById("num2").value;
	var num3 = document.getElementById("num3").value;
	var num4 = document.getElementById("num4").value;
	var num5 = document.getElementById("num5").value;
	var num6 = document.getElementById("num6").value;
	var num7 = document.getElementById("num7").value;
	var num8 = document.getElementById("num8").value;
	var num9 = document.getElementById("num9").value;
	var num10 = document.getElementById("num10").value;
	var num11 = document.getElementById("num11").value;
	var num12 = document.getElementById("num12").value;
	var num13 = document.getElementById("num13").value;
	var num14 = document.getElementById("num14").value;
	if(isNaN(num1.trim())){num1=0;}
	if(isNaN(num2.trim())){num2=0;}
	if(isNaN(num3.trim())){num3=0;}
	if(isNaN(num4.trim())){num4=0;}
	if(isNaN(num5.trim())){num5=0;}
	if(isNaN(num6.trim())){num6=0;}
	if(isNaN(num7.trim())){num7=0;}
	if(isNaN(num8.trim())){num8=0;}
	if(isNaN(num9.trim())){num9=0;}
	if(isNaN(num10.trim())){num10=0;}
	if(isNaN(num11.trim())){num11=0;}
	if(isNaN(num12.trim())){num12=0;}
	if(isNaN(num13.trim())){num13=0;}
	if(isNaN(num14.trim())){num14=0;}
	
	// 算出合计人日
	var temp11 = accAdd(num1,num3);
	var temp22 = accAdd(temp11,num5);
	var temp33 = accAdd(temp22,num7);
	var temp44 = accAdd(temp33,num9);
	var temp55 = accAdd(temp44,num11);
	var temp66 = accAdd(temp55,num13);
	var result1 = accAdd(temp66,num14);

 // 算出合计万元
	var temp1 =accAdd(num2,num4);
	var temp2 =accAdd(temp1,num6);
	var temp3 =accAdd(temp2,num8);
	var temp4 =accAdd(temp3,num10);
	var result2 =accAdd(temp4,num12);

	var unitPrice = $("#unitPriceId").find("option:selected").val();
	document.getElementById("sum1").value = result1;
	document.getElementById("sum2").value = result2;
	document.getElementById("hiddenResult1").value = result1;
	//document.getElementById("sumrlcbId").value = result1;
	
	//document.getElementById("sumcbfygsId").value = result2;
	document.getElementById("sumfygsId").value =result2;
	document.getElementById("lrlId").value = 0;
	if (unitPrice == 0) {
		document.getElementById("sumcbfygsId").value = result2;
		return false;
	}else{
		document.getElementById("sumrlcbId").value = accMul(Number(unitPrice)/10000,result1);
	
		document.getElementById("sumcbfygsId").value =accAdd($('#sumrlcbId').val(),result2);
	}
	profitMargin($("#numhtje").val());
}

function profitMargin(obj){
	if(obj == ''){
		return false;
	}else{
	var a =  $("#sumcbfygsId").val();
	if (obj!='0'){
	  var lrl = (Number(obj) -Number(a))/Number(obj);
	  var templrl = (parseFloat(lrl)*100).toFixed(2);
		var ret = templrl.toString()+"%"
		document.getElementById("lrlId").value = ret;
	}else{
		var lrl=0;
		document.getElementById("lrlId").value = "-";
	}
	//var templrl = (parseFloat(lrl)*100/1.0).toFixed(2);
	
	}
}

//根据项目名查出子项目
function selectSubProjectList(){
	if ($("#projectname").find("option:selected").val() == "") {
		$("#select").attr("disabled", true); 
	//	$("#select").arrt('title','请先选择项目和子项目！');
		clear();
		return false;
	}
	$.ajax({
		url:"selectSubProjectList.do",
		data:{
			projectname:$("#projectname").find("option:selected").val()
		},
		success:function(data){
			var a="";
			$("#subprojectname").find("option").remove();
			$("#subprojectname").append("<option value=''>请选择</option>");
			for (var i=0;i<data.length;i++){
				a+="<option value="+data[i].subprojectname+">"+data[i].subprojectname+"</option>";
			}
			$("#subprojectname").append(a);
		}
		
	});
}
//根据子项目查询对应的项目编号和项目经理
function getProjectCodeAndManager(){
	if ($("#projectname").find("option:selected").val() == "" || $("#subprojectname").find("option:selected").val() == 0) {
		$("#select").attr("disabled", true); 
		//$("#select").arrt('title','请先选择项目和子项目！');
		clear();
		return false;
	}else{
	$("#select").attr("disabled", false); 
	$("#select").removeAttr('title');
	$.ajax({
		url:"getProjectCodeAndManager.do",
		data:{
			projectname:$("#projectname").find("option:selected").val(),
			subprojectname:$("#subprojectname").find("option:selected").val()
		},
		success:function(data){
			document.getElementById("projectCodeId").value = data[0].projectnumber;
			document.getElementById("projectManagerId").value = data[0].projectManageName;
			doesTheContractExist(data[0].subprojectcode);
		}
		
	});
	}
}
//根据查询的子项目号查询合同表中是否存在
function doesTheContractExist(obj){
	$.ajax({
		url:"doesTheContractExist.do",
		data:{
			subprojectcode:obj
		},
		success:function(data){
			if (data.length == 0) {
				document.getElementById("sum1").value = "";
				$("sum1").attr("placeholder","请输入");
				document.getElementById("sum2").value = "";
				document.getElementById("num1").value = "0";
				document.getElementById("num2").value = "0";
				document.getElementById("num3").value = "0";
				document.getElementById("num4").value = "0";
				document.getElementById("num5").value ="0";
				document.getElementById("num6").value = "0";
				document.getElementById("num7").value = "0";
				document.getElementById("num8").value = "0";
				document.getElementById("num9").value = "0";
				document.getElementById("num10").value = "0";
				document.getElementById("num11").value = "0";
				document.getElementById("num12").value = "0";
				document.getElementById("num13").value = "0";
				document.getElementById("num14").value = "0";
				//基础数据
				document.getElementById("lrlId").value = "";
				document.getElementById("numhtje").value = "0";
				document.getElementById("selecthtqdtypeId").value = "0";
				document.getElementById("unitPriceId").value = "0";
				document.getElementById("sumrlcbId").value = "";
				document.getElementById("sumfygsId").value = "";
				document.getElementById("sumcbfygsId").value = "";
				document.getElementById("hiddenResult1").value = "";
				return false;
			}else{
				var sum1 = Number(data[0].hcdemand)+Number(data[0].hcdevelopment)+Number(data[0].hctest)+Number(data[0].hcoperation)
				          +Number(data[0].hctrain)+Number(data[0].hcconsultation)+Number(data[0].hcafterservice)+Number(data[0].hcother)
				document.getElementById("sum1").value = sum1;
				document.getElementById("sum2").value = data[0].expenses;
				document.getElementById("num1").value = data[0].hcdemand;
				document.getElementById("num2").value = data[0].expurchasingsoftware;
				document.getElementById("num3").value = data[0].hcdevelopment;
				document.getElementById("num4").value = data[0].expurchasinghardware;
				document.getElementById("num5").value = data[0].hctest;
				document.getElementById("num6").value = data[0].exoutservice;
				document.getElementById("num7").value = data[0].hcoperation;
				document.getElementById("num8").value = data[0].exoutteam;
				document.getElementById("num9").value = data[0].hctrain;
				document.getElementById("num10").value = data[0].exerp;
				document.getElementById("num11").value = data[0].hcconsultation;
				document.getElementById("num12").value = data[0].exother;
				document.getElementById("num13").value = data[0].hcafterservice;
				document.getElementById("num14").value = data[0].hcother;
				//基础数据
				document.getElementById("lrlId").value = data[0].profitrate;
				document.getElementById("numhtje").value = data[0].contractvalues;
				document.getElementById("selecthtqdtypeId").value = data[0].contractstate;
				document.getElementById("unitPriceId").value = data[0].dailycost;
				document.getElementById("sumrlcbId").value = data[0].humancost;
				document.getElementById("sumfygsId").value = data[0].humancostexpenses;
				document.getElementById("sumcbfygsId").value = data[0].costtotal;
				document.getElementById("hiddenResult1").value = sum1;
			}
		}
		
	});
}

function cheakUnitPrice(){//根据不同单价计算成本
	var unitPrice = $("#unitPriceId").find("option:selected").val();
	if (unitPrice == 0) {
		profitMargin(0);
		//document.getElementById("sumfygsId").value = 0;
		document.getElementById("sumrlcbId").value = 0;
		document.getElementById("sumcbfygsId").value =document.getElementById("sum2").value;
		return false;
	}else{
		//document.getElementById("sumrlcbId").value = Number(unitPrice)/10000*Number($('#hiddenResult1').val());;
		document.getElementById("sumrlcbId").value = accMul(Number(unitPrice)/10000,Number($('#hiddenResult1').val()));
		var workload = $("#sumrlcbId").val();
		var workload2 = $("#sum2").val();
		document.getElementById("sumfygsId").value =workload2;
		document.getElementById("sumcbfygsId").value =accAdd(workload,workload2);
		profitMargin($("#numhtje").val());
	}
}


	//查询项目名称
	function getProjectSearch(){
		//项目名称关键字
		var projectname=$("#projectSearch").val();
	
		 
		$.ajax({
			type:"POST",
			//url:basepath+'serachProject.do',
			url:"serachProject.do",
			data:{ 
				projectName:projectname
			},  
			success:function(data){

				$('#assignproject').empty();
				for (var i = 0;i<data.length;i++){


					 
					 $('#assignproject').append('<li>' +
			 		'<div class="list-con" id="assign' + data[i].id + '" onclick="showassign('+data[i].id+',\''+data[i].projectcode+'\')">' +
			 				'<div class="con-tt">' +
			 					'<div class="con-icon"></div><span>'+(data[i].projectName==null?"":data[i].projectName)+'</div>'+
					        '<p class="con-sub-tt">创建时间 : '+data[i].addtime.substring(0,19)+'</p>'+
					        '<div class="con-line"></div>'+
					        /*'<p class="con-sub-tt con-num">参与人数 : 20</p>'+*/
					        '<div class="con-users"><div class="con-name">'+(data[i].projectLeader==null?"":data[i].projectLeader.substring(0,1))+'</div></div>'+
					        '</div></li>'
			);
					
				}	 
			} 
		});	
	};
	 
	//查询未参加项目的人员
	function selectuser(depid) {
		depid = $('#depID').val();
		 
		if(null == depid || depid == 0)
			depid = 0; 
		$.ajax({ 
			type:"POST",
			//url:basepath+'serachProject.do',
			url:"getUnAssignUsers.do",
			data:{ 
				projectid:oldprojectid,
				depid:depid,
				userName:''
			},  
			success:function(data){

				$('#showusers').empty();
				
				 
				for (var i = 0;i<data.length;i++){
					 $('#showusers').append("<li>" +
					 		"<div class='list-con' id='unassignuser" + data[i].userid + "' onclick='addassignuser("+data[i].userid+")'>" +
					 				"<div class='con-tt'>" +
					 					"<div class='con-icon'></div><span>"+(data[i].name==null?'':data[i].name)+"</span><span class='con-user-info'>("+data[i].account+"/"+data[i].name+")</span></div>"+
							       
							        "<div class='con-line'></div>"+
							       /* "<p class='con-sub-tt con-num'>参与人数 : 20</p>"+*/
							        "<div></div>"+
							        "</div></li>"
					);
					 
				}	
			} 
		});	
	}
	
	
	//根据项目ID查询项目人员
	function getUserByProjectSearch(projectid,projectnumber){
		alert(projectnumber);
	var username = '';
		$.ajax({
			type:"POST",
			url:"serachSonProject.do",
			data:{ 
				projectnumber:projectnumber
			},  
			success:function(data){

				alert(data.length);
			} 
		});	
		
		
		$('div.allot-ul .second').fadeIn();
		//剧场隐藏
		$('div.allot-ul .second .box-tag, div.allot-ul .third .box-tag').fadeOut();
		$('div.allot-ul .third').fadeOut();
		//入场 
		$('div.allot-ul .second .tag-user-02').fadeIn();
		//按钮复位
		$("div.allot-ul .second .box-btn-save,div.allot-ul .third .box-btn-save").removeClass("box-btn-down");
		$("div.allot-ul .second .box-btn-save,div.allot-ul .third .box-btn-save").removeClass("box-info-show");

		
	};
	var oldprojectid;
	//根据项目ID查询项目人员
	function getUserByProjectSearchUser(){
		var username=$("#projectusername").val();
		$.ajax({ 
			type:"POST",
			//url:basepath+'serachProject.do',
			url:"getUserByProject.do",
			data:{ 
				projectid:oldprojectid,
				username:username
			},  
			success:function(data){

				$('#assignuserproject1').empty(); 
				 
				for (var i = 0;i<data.length;i++){
					 $('#assignuserproject1').append("<li>" +
					 		"<div class='list-con' id='assignuser" + data[i].id + "'>" +
					 				"<div class='con-tt'>" +
					 					"<div class='con-icon'></div><span>"+(data[i].name==null?'':data[i].name)+"</span><span class='con-user-info'>("+data[i].account+"/"+data[i].name+")</span></div>"+
							       
							        "<div class='con-line'></div>"+
							        /*"<p class='con-sub-tt con-num'>参与人数 : 20</p>"+*/
							        "<div class='con-del'onclick='delprojectuser("+data[i].id+")'><i class='line'></i></div>"+
							        "</div></li>"
					);
					
				}	 
			} 
		});	
		
		
		
		
	};
	var assignuserid = 0;
	//选择用户
	function addassignuser(userid) {
		assignuserid = userid;
		//$(this).parent().parent().find(".list-con").removeClass("list-con-now");
		$("#showusers div").removeClass("list-con-now");
		$('#unassignuser'+userid).addClass("list-con-now");
		
		
		
	}   
	//分配项目添加方法
	function saveassignuser(){ 
	
		if(assignuserid<=0 || oldprojectid <= 0){
			 
			$(this).addClass("box-btn-down");
			var errorboxBtn = $('#box-info-error');
			errorboxBtn.addClass("box-info-show"); 
			 
			setTimeout(function() {
				errorboxBtn.removeClass("box-info-show");
			}, 1500); 
			
			//重新加载项目人员和未参加项目人员
			getUserByProjectSearchUser();
			selectuser(0);
			return;
		}else {
			
			
			$.ajax({ 
				type:"POST",
				//url:basepath+'serachProject.do',
				url:"addAssignProjectUser.do",
				data:{ 
					projectid:oldprojectid,
					userid:assignuserid
				},  
				success:function(data){
					
					if(data == "1"){
						
						//弹出提示信息
						$(this).addClass("box-btn-down");
						var successboxBtn = $('#box-info-success');
						successboxBtn.addClass("box-info-show"); 
						
						setTimeout(function() {
							successboxBtn.removeClass("box-info-show"); 
						}, 1500);
						//重新加载项目人员和未参加项目人员
						getUserByProjectSearchUser();
						selectuser(0);
					}else{
						
						$(this).addClass("box-btn-down");
						var errorboxBtn = $('#box-info-error');
						errorboxBtn.addClass("box-info-show"); 
						 
						setTimeout(function() {
							errorboxBtn.removeClass("box-info-show");
						}, 1500); 
					}

						 
					}	 
				});	
			
			
		} 
		//重新加载项目人员和未参加项目人员
		getUserByProjectSearchUser();
		selectuser(0);
		
	}   
	
	//显示项目
	function showassign(pid,projectname) {
		$('.list-con-now').removeClass("list-con-now");
		$('#assign'+pid).addClass("list-con-now");
		getUserByProjectSearch(pid,projectname); 
			}
	//删除项目中的人员
	function delprojectuser(id) {
		
		$.ajax({ 
			type:"POST",
			//url:basepath+'serachProject.do',
			url:"delProjectUser.do",
			data:{ 
				id:id
			},  
			success:function(data){
				if(data=='success'){
					getUserByProjectSearchUser();
					selectuser(0); 
					alert("删除成功！");					
					 
				} 					
				else
					alert("删除失败！");
				 
			} 
		});	
		
		
	}
	
//
	//加载部门信息begin 
	function loadDepInfo(uri){
		// 获取隐藏域中的部门ID
		
		URI = uri;
		$.ajax({
			type:"POST",
			dataType:"text",
			url: uri +'loadDepInfo.do',
			async:false,
			dataType:"text",
			success:function(data) {
				// alert(data);
				$(eval("(" + data +")")).each(function() {
					//if (this.id == hiddenDeptid) {
					//	$("#depID").append("<option selected = 'selected' value='" + this.id + "'>" + this.deptName + "</option>");
					//	loadTeamInfo();
					//} else{
						$("#depID").append("<option value='" + this.id + "'>" + this.deptName + "</option>");
					//}
				});
			}
		});
	}
	//部门信息加载结束

/**********************************************按人员分配项目******************************************/
	var assingprojectid;
	
	//按人员分配，查询人员名称实现查询方式
	$("#UserSearch").on('input',function(e){  
		showuserbyname();
	}); 
	//按项目名称查询参与的项目动态显示
	$("#assignuserprojectserach2").on('input',function(e){  
		showuserproject();
	}); 
	//按项目名称查询未参与的项目 
	$("#serachunAssignProject3").on('input',function(e){  
		var projectName = $('#serachunAssignProject3').val();
		
		
		$.ajax({
			type:"POST", 
			//url:basepath+'serachProject.do',
			url:"selectUnAssignProject.do",
			data:{ 
				userid:olduserid,
				projectName:projectName 
				 
			},   
			success:function(data){

				$('#userunAssignProject3').empty();
				
				 
				for (var i = 0;i<data.length;i++){
					 $('#userunAssignProject3').append("<li>" +
					 		"<div class='list-con' id='assignuserproject" + data[i].id + "' onclick='assignuserproject("+data[i].id+")'>" +
					 				"<div class='con-tt'>" +
					 					"<div class='con-icon'></div><span>"+(data[i].projectName==null?'':data[i].projectName)+"</span><span class='con-user-info'></span></div>"+
							            "<p class='con-sub-tt'>创建时间 : "+data[i].addtime.substring(0,19)+"</p><div class='con-line'></div>"+/*<p class='con-sub-tt con-num'>参与人数 : 20</p>"+
*/							        "<div class='con-users'><div class='con-name'>"+(data[i].projectLeader==null?"":data[i].projectLeader.substring(0,1))+"</div></div>"+
							        "</div></li>"
					);
					  
				}	 
			} 
		});	
	}); 
	
	
	
	//项目分配-TAG切换
	$('ul.distribution-menu li').on("click",function() {
		var li_num = $(this).index();
		$('div.allot-ul .second, div.allot-ul .second .tag-user-02, div.allot-ul .second .tag-project-02').fadeOut();
		$('div.allot-ul .third').fadeOut();
	
		if( li_num == 0 ){
			
			getProjectSearch(); 
			$('div.tag-project').fadeIn();
			$('div.tag-user').fadeOut();
			$('h2.box-title-first').text("项目分配");
			
		}
		
		if( li_num == 1 ){
			
			$.ajax({
				type:"POST",
				//url:basepath+'serachProject.do',
				url:"getUnAssignUsers.do",
				data:{ 
					projectid:0,
					depid:0,
					userName:''
				},  
				success:function(data){

					$('#assignuserproject2').empty();
					 
					 
					for (var i = 0;i<data.length;i++){
						 $('#assignuserproject2').append("<li>" +
						 		"<div class='list-con' id='assignuser" + data[i].userid + "' onclick='clickshowuserproject("+data[i].userid+",\""+data[i].name+"\")'>" +
						 				"<div class='con-tt'>" +
						 					"<div class='con-icon'></div><span>"+(data[i].name==null?'':data[i].name)+"</span><span class='con-user-info'>("+data[i].account+"/"+data[i].name+")</span></div>"+
								       
								        "<div class='con-line'></div>"+
								       /* "<p class='con-sub-tt con-num'>参与人数 : 20</p>"+*/
								        "<div></div>"+
								        "</div></li>"
						);
						
					}	
				} 
			});	
			
			
			$('div.tag-project').fadeOut();
			$('div.tag-user').fadeIn();
			$('h2.box-title-first').text("人员分配");
		}
	});
	
	function showuserbyname() {
		var username = $('#UserSearch').val();
		

		 
		$.ajax({
			type:"POST",
			//url:basepath+'serachProject.do',
			url:"getUnAssignUsers.do",
			data:{ 
				projectid:0,
				depid:0,
				userName:username
			},  
			success:function(data){

				$('#assignuserproject2').empty();
				
				 
				for (var i = 0;i<data.length;i++){
					 $('#assignuserproject2').append("<li>" +
					 		"<div class='list-con' id='assignuser" + data[i].userid + "' onclick='clickshowuserproject("+data[i].userid+",\""+data[i].name+"\")'>" +
					 				"<div class='con-tt'>" +
					 					"<div class='con-icon'></div><span>"+(data[i].name==null?'':data[i].name)+"</span><span class='con-user-info'>("+data[i].account+"/"+data[i].name+")</span></div>"+
							       
							        "<div class='con-line'></div>"+
							       /* "<p class='con-sub-tt con-num'>参与人数 : 20</p>"+*/
							        "<div></div>"+
							        "</div></li>"
					);
					
				}	
			} 
		});	
	}
	
	var olduserinfo;
	var olduserid;
	function clickshowuserproject(userid,username){
		
		$("#assignuserprojecttitle2 h2").empty();
		olduserinfo =username ;
		//根据传输的ID动态修改选择样式
		$('#assignuserproject2 .list-con-now').removeClass("list-con-now");
		$('#assignuser'+userid).addClass("list-con-now"); 
		olduserid = userid;
		showuserproject(userid,username);
		
		
		$('div.allot-ul .second').fadeIn();
		//剧场隐藏
		$('div.allot-ul .second .box-tag, div.allot-ul .third .box-tag').fadeOut();
		$('div.allot-ul .third').fadeOut();
		//入场
		$('div.allot-ul .second .tag-project-02').fadeIn();
		//按钮复位
		$("div.allot-ul .second .box-btn-save,div.allot-ul .third .box-btn-save").removeClass("box-btn-down");
		$("div.allot-ul .second .box-btn-save,div.allot-ul .third .box-btn-save").removeClass("box-info-show");

	}
	
	
	//根据人员查询项目
function showuserproject(userid,username) {
	var projectName = $("#assignuserprojectserach2").val();
	$("#assignuserprojecttitle2 h2").empty();
	$("#assignuserprojecttitle2 h2").append(username);

	$.ajax({
		type:"POST", 
		//url:basepath+'serachProject.do',
		url:"getProjectByUser.do",
		data:{ 
			userid:olduserid,
			projectName:projectName 
			 
		},  
		success:function(data){

			$('#ulassignuserproject2').empty();
			
			 
			for (var i = 0;i<data.length;i++){
				 $('#ulassignuserproject2').append("<li>" +
				 		"<div class='list-con' id='assignuser" + data[i].userid + "' onclick='showuserproject("+data[i].userid+")'>" +
				 				"<div class='con-tt'>" +
				 					"<div class='con-icon'></div><span>"+(data[i].projectName==null?'':data[i].projectName)+"</span><span class='con-user-info'></span></div>"+
						            "<p class='con-sub-tt'>创建时间 : "+data[i].addtime.substring(0,19)+"</p><div class='con-line'></div>"+/*<p class='con-sub-tt con-num'>参与人数 : 20</p>"+
*/						        "<div class='con-del'onclick='deluserproject("+data[i].id+")'><i class='line'></i></div>"+
						        "</div></li>"
				);
				 
			}	 
		} 
	});	
	
}
//点击竟然添加项目界面
function addproject() {
	
	var projectName = $('#userunAssignProjectSearch3').val();
	
	
	$.ajax({
		type:"POST", 
		//url:basepath+'serachProject.do',
		url:"selectUnAssignProject.do",
		data:{ 
			userid:olduserid,
			projectName:projectName 
			 
		},   
		success:function(data){

			$('#userunAssignProject3').empty();
			
			 
			for (var i = 0;i<data.length;i++){
				 $('#userunAssignProject3').append("<li>" +
				 		"<div class='list-con' id='assignuserproject" + data[i].id + "' onclick='assignuserproject("+data[i].id+")'>" +
				 				"<div class='con-tt'>" +
				 					"<div class='con-icon'></div><span>"+(data[i].projectName==null?'':data[i].projectName)+"</span><span class='con-user-info'></span></div>"+
						            "<p class='con-sub-tt'>创建时间 : "+data[i].addtime.substring(0,19)+"</p><div class='con-line'></div>"+/*<p class='con-sub-tt con-num'>参与人数 : 20</p>"+
*/						        "<div class='con-users'><div class='con-name'>"+(data[i].projectLeader==null?"":data[i].projectLeader.substring(0,1))+"</div></div>"+
						        "</div></li>"
				);
				 
			}	 
		} 
	});	
	
	$('div.allot-ul .third').fadeIn();
	//剧场隐藏
	$('div.allot-ul .third .box-tag').fadeOut();
	//入场
	$('div.allot-ul .third .tag-project-03').fadeIn();
}



function deluserproject(id) { 
	delprojectuser(id);	
}
//选择项目为人员分配
function assignuserproject(id) {
	$('#userunAssignProject3 .list-con-now').removeClass("list-con-now");
	$(' #assignuserproject'+id).addClass("list-con-now");
	
	assingprojectid = id;
	
	 
}

function addassignprojectuser() {
	if(assingprojectid<=0 || olduserid <= 0){
	
		$(this).addClass("box-btn-down");
		var errorboxBtn = $('#box-info-error');
		errorboxBtn.addClass("box-info-show"); 
		 
		setTimeout(function() {
			errorboxBtn.removeClass("box-info-show");
		}, 1500); 
		return;
	}else {
	$.ajax({ 
		type:"POST",
		//url:basepath+'serachProject.do',
		url:"addAssignProjectUser.do",
		data:{ 
			projectid:assingprojectid,
			userid:olduserid 
		},  
		success:function(data){
			
			if(data == "1"){
				addproject();
				showuserproject(olduserid,olduserinfo); 
				//弹出提示信息
				$(this).addClass("box-btn-down");
				var successboxBtn = $('#box-info-success3');
				successboxBtn.addClass("box-info-show"); 
				
				setTimeout(function() {
					successboxBtn.removeClass("box-info-show"); 
				}, 1500); 	
				 
			}else{
				addproject();
				showuserproject(olduserid,olduserinfo); 
				$(this).addClass("box-btn-down");
				var errorboxBtn = $('#box-info-error3');
				errorboxBtn.addClass("box-info-show"); 
				 
				setTimeout(function() {
					errorboxBtn.removeClass("box-info-show");
				}, 1500); 
				 
			}

				 
			}	 
		});	
	}
}

function clear(){
	document.getElementById("sum1").value = "";
	document.getElementById("sum2").value = "";
	document.getElementById("num1").value = "0";
	document.getElementById("num2").value = "0";
	document.getElementById("num3").value = "0";
	document.getElementById("num4").value = "0";
	document.getElementById("num5").value ="0";
	document.getElementById("num6").value = "0";
	document.getElementById("num7").value = "0";
	document.getElementById("num8").value = "0";
	document.getElementById("num9").value = "0";
	document.getElementById("num10").value = "0";
	document.getElementById("num11").value = "0";
	document.getElementById("num12").value = "0";
	document.getElementById("num13").value = "0";
	document.getElementById("num14").value = "0";
	//基础数据
	document.getElementById("lrlId").value = "";
	document.getElementById("numhtje").value = "0";
	document.getElementById("selecthtqdtypeId").value = "0";
	document.getElementById("unitPriceId").value = "0";
	document.getElementById("sumrlcbId").value = "";
	document.getElementById("sumfygsId").value = "";
	document.getElementById("sumcbfygsId").value = "";
	document.getElementById("hiddenResult1").value = "";
	document.getElementById("projectCodeId").value = "";
	document.getElementById("projectManagerId").value = "";
	document.getElementById("subprojectname").value = "";
}

// 乘法
function accMul(arg1,arg2){
var m=0,s1=arg1.toString(),s2=arg2.toString();
try{m+=s1.split(".")[1].length}catch(e){}
try{m+=s2.split(".")[1].length}catch(e){}
return Number(s1.replace(".",""))*Number(s2.replace(".",""))/Math.pow(10,m)
}
 // 加法
function accAdd(arg1, arg2) {
    var r1, r2, m;
    try { r1 = arg1.toString().split(".")[1].length } catch (e) { r1 = 0 }
    try { r2 = arg2.toString().split(".")[1].length } catch (e) { r2 = 0 }
    m = Math.pow(10, Math.max(r1, r2))
    return (arg1 * m + arg2 * m) / m
}