/*
 * 主JS文件
 * 日期: 2017-02-06
 * By Endfish
 * 
*/

//所有页面
function initPage () {
	
	//左侧导航开启
	$('div.page-top .menu-left').on("click",function() {
		$('div.left-nav').removeClass("left-nav-hide");
	})
	//左侧导航关闭
	$('div.left-nav .btn-close').on("click",function() {
		$('div.left-nav').addClass("left-nav-hide");
	});
	//右侧导航开启
	$('div.page-top .menu-right').on("click",function() {
		$('div.right-nav').removeClass("right-nav-hide");
	})
	//右侧导航关闭
	$('div.right-nav .btn-close').on("click",function() {
		$(this).parent().addClass("right-nav-hide");
	});
	
	//计算页面高度分配给BOX
	var pageHeight = $(window).height(); //屏幕高度
	var pageBoxHeight = pageHeight - $('div.page-boxs')[0].offsetTop - 100; //BOX高度
	$('div.page-box-con').css("height",pageBoxHeight);
	$('div.time-main,div.allot-main').css("height",pageBoxHeight + 60);
	$('div.box-form').css("height",pageBoxHeight - 60);
	$('div.box-list').css("height",pageBoxHeight - 60 - 60);
	//$('div.page-box-login').css("height",pageHeight - 140 - 140);
	
	//表格产生滚动条
	var pageBoxTableHeight = pageBoxHeight - 60 - 45 - 25;
	$('div.box-table-con').css("height",pageBoxTableHeight);
	$('div.box-table-con').mCustomScrollbar({
		theme: "minimal-dark"
	});
	
	//模块产生滚动条
	$('div.time-main,div.allot-main').mCustomScrollbar({
		axis:"x", //设置水平滚动方向
		autoDraggerLength: true, //自动调整滚动条长度
		theme: "minimal-dark",
		scrollInertia: 3000,
		advanced:{
			autoExpandHorizontalScroll: true, //设置水平滚动
			updateOnContentResize: true, //自动更新滚动条
			autoScrollOnFocus: false //禁用表单焦点
		},
		callbacks:{
			onUpdate: function() {
				//滚动条更新后回调函数
			}
		}
	});
	
	//表单产生滚动条
	$('div.box-form-scroll, div.box-list-scroll').mCustomScrollbar({
		theme: "minimal-dark"
	});
	
	//点击后在右侧添加工时
	var TimeAdd;
	var TimeAddForm;
	$('div.time-add').on("click",function() {
		TimeAdd = $('div.time-main .time-ul .list').eq(-2).clone(true); //获取倒数第2个模板
		TimeAddForm = $('div.time-main .time-ul .list:last').before(TimeAdd); //在添加按钮前插入模板
	});
	
	//表单下拉菜单的宽度
	var formPopWidth = $('div.form-group').width();
	var formPopHeight = pageBoxHeight / 2.5;
	$('div.box-form .box-pop').css({
		'width' : formPopWidth,
		'max-height' : formPopHeight
	});
	
	//下拉菜单滚动
	$('div.box-form .box-pop').mCustomScrollbar({
		theme: "minimal-dark"
	});
	
	//点击表单展现下拉菜单
	$('div.form-pop .form-control').on("click",function() {
		$('div.box-pop').removeClass("box-pop-show"); //取消其他下拉列表
		$(this).parent().find('.box-pop').addClass("box-pop-show");
	});
	
	//点击下拉列表赋值当前表单属性并关闭下拉菜单
	$('div.box-form .box-pop li').on("click",function() {
		$(this).parents('.form-group').find('.form-control').val($(this).text());
		$(this).parents('.form-group').find('.form-select option').attr("selected",false);
		$(this).parents('.form-group').find('.form-select option').eq($(this).index()).attr("selected",true);
		
		var o = $(this).parents('.form-group').find('.form-select option').eq($(this).index()).val();
		loadTeamInfo(o);
		
		$('div.box-pop').removeClass("box-pop-show"); //关闭下拉列表
	});
	
	//点击标题右上角more的下拉菜单
	$('div.page-box .more').on("click",function(e) {
		$(this).parent().find('.box-pop').addClass("box-pop-show");
		//阻止冒泡排序
		e.stopPropagation();
	});
	
	//点击任何地方关闭右上角more的下拉菜单
	$(document).on("click",function() {
		$('div.box-title .box-pop').removeClass("box-pop-show");
	});
	
	//选中下拉关闭
	$('div.box-title .box-pop li').on("click",function() {
		$('div.box-pop').removeClass("box-pop-show"); //关闭下拉列表
	});
	
//	//按钮状态切换并弹出对应信息
//	$('div.box-btn-save').on("click",function() {
//		$(this).addClass("box-btn-down");
//		var boxBtn = $(this).parent().find('.box-info');
//		boxBtn.addClass("box-info-show");
//		
//		setTimeout(function() {
//			boxBtn.removeClass("box-info-show");
//		}, 1500);
//		
//	}); 
	
			
	
	
//	//项目分配-点击
//	$('ul .list-hover .list-con').on("click",function() {
//		$(this).parent().parent().find(".list-con").removeClass("list-con-now");
//		$(this).addClass("list-con-now");
//	});
//	
//	//项目分配-点击选中
//	$('ul .list-select .list-con').on("click",function() {
//		
//		if( $(this).hasClass("list-con-sel") ){
//			$(this).removeClass("list-con-sel");
//		}else{
//			$(this).addClass("list-con-sel");
//		}
//		
//		$(this).parents(".page-box-con").find(".box-btn-save").removeClass("box-btn-down");
//		$(this).parents(".page-box-con").find(".box-info").removeClass("box-info-show");
//		
//	});
	
	
	//项目分配-点击
	$('ul.list-hover .list-con').on("click",function() {
		$(this).parent().parent().find(".list-con").removeClass("list-con-now");
		$(this).addClass("list-con-now");
	});
	
	//项目分配-点击选中
	$('ul .list-select .list-con').on("click",function() {
		
		if( $(this).hasClass("list-con-sel") ){
			$(this).removeClass("list-con-sel");
		}else{
			$(this).addClass("list-con-sel"); 
		}
		
		$(this).parents(".page-box-con").find(".box-btn-save").removeClass("box-btn-down");
		$(this).parents(".page-box-con").find(".box-info").removeClass("box-info-show");
		
	});
	
	
	
	//项目分配-首屏
	//第一个模块, 第二剧场产品入场
//	$('div.allot-ul .first .list-pro li').on("click",function() {
//		
//		$('div.allot-ul .second').fadeIn();
//		//剧场隐藏
//		$('div.allot-ul .second .box-tag, div.allot-ul .third .box-tag').fadeOut();
//		$('div.allot-ul .third').fadeOut();
//		//入场
//		$('div.allot-ul .second .tag-user-02').fadeIn();
//		//按钮复位
//		$("div.allot-ul .second .box-btn-save,div.allot-ul .third .box-btn-save").removeClass("box-btn-down");
//		$("div.allot-ul .second .box-btn-save,div.allot-ul .third .box-btn-save").removeClass("box-info-show");
//	});
	//第一个模块, 第二剧场用户入场
	$('div.allot-ul .first .list-user li').on("click",function() {
		$('div.allot-ul .second').fadeIn();
		//剧场隐藏
		$('div.allot-ul .second .box-tag, div.allot-ul .third .box-tag').fadeOut();
		$('div.allot-ul .third').fadeOut();
		//入场
		$('div.allot-ul .second .tag-project-02').fadeIn();
		//按钮复位
		$("div.allot-ul .second .box-btn-save,div.allot-ul .third .box-btn-save").removeClass("box-btn-down");
		$("div.allot-ul .second .box-btn-save,div.allot-ul .third .box-btn-save").removeClass("box-info-show");
	});
	//第二个模块, 产品按钮点击, 第三剧场用户入场
	$('div.allot-ul .second .tag-user-02 .box-btn').on("click",function() {
		$('div.allot-ul .third').fadeIn();
		//剧场隐藏
		$('div.allot-ul .third .box-tag').fadeOut();
		//入场
		$('div.allot-ul .third .tag-user-02').fadeIn();
	});
	//第二个模块, 第三剧场产品入场
	$('div.allot-ul .second .list-user li').on("click",function() {
		$('div.allot-ul .third').fadeIn();
		//剧场隐藏
		$('div.allot-ul .third .box-tag').fadeOut();
		//入场
		$('div.allot-ul .third .tag-project-02').fadeIn();
		//按钮复位
		$("div.allot-ul .second .box-btn-save,div.allot-ul .third .box-btn-save").removeClass("box-btn-down");
		$("div.allot-ul .second .box-btn-save,div.allot-ul .third .box-btn-save").removeClass("box-info-show");
	});
	//第二个模块, 第三剧场用户入场
	$('div.allot-ul .second .list-pro li').on("click",function() {
		$('div.allot-ul .third').fadeIn();
		//剧场隐藏
		$('div.allot-ul .third .box-tag').fadeOut();
		//入场
		$('div.allot-ul .third .tag-user-03').fadeIn();
		//按钮复位
		$("div.allot-ul .second .box-btn-save,div.allot-ul .third .box-btn-save").removeClass("box-btn-down");
		$("div.allot-ul .second .box-btn-save,div.allot-ul .third .box-btn-save").removeClass("box-info-show");
	});
	
	//表格限制
	$('.t-more-add').hide();
	$(".table tr td.box-table-more-con").each(function(i){
	        if( $(this).text().length > 40 ){
	        	//console.log($(this).text().length);
	        	$(this).find('.t-more').hide();
	        	$(this).find('.t-more-add').show();
	        }
	});
	$('.t-more-add').on("click",function(){
		if($(this).text() == "显示全部"){
			$(this).parent().find('.t-more').show();
			$(this).text('隐藏');
		}else{
			$(this).parent().find('.t-more').hide();
			$(this).text('显示全部');
		}
			
	});

	//表格限制
	$('.t1').hide();
	$(".table tr td.boxcon1").each(function(i){
		
	        if( $(this).text().length>5){
	        	//console.log($(this).text().length);
	        	$(this).find('.tmore1').hide();
	        	$(this).find('.t1').show();
	        }
	});
	$('.t1').on("click",function(){
		if($(this).text() == "显示全部"){
			$(this).parent().find('.tmore1').show();
			$(this).text('隐藏');
		}else{
			$(this).parent().find('.tmore1').hide();
			$(this).text('显示全部');
		}
			
	});
	
	
}

//时间控件
function formTime () {
	
	var begintime;
	
	//开始时间
	$('.begin-time').datetimepicker({
		language: 'zh-CN',
		format: 'yyyy-mm-dd hh:ii',
		minuteStep: 30,
		showMeridian: true,
		autoclose: true
	}).on('changeDate', function() {
		
		begintime = $('.begin-time').val();
		
		//结束时间
		$('.end-time').datetimepicker({
			startDate: begintime,
			language: 'zh-CN',
			format: 'yyyy-mm-dd hh:ii',
			minuteStep: 30,
			showMeridian: true,
			autoclose: true
		});
	});
	
	
}


 
 
  
