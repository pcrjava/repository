/*
 * 主JS文件
 * 日期: 2017-02-06
 * By Endfish
 * 
*/

//所有页面
function initPage () {
	
	//左侧导航开启
	$('div.page-top .menu-left').on("click",function() {
		$('div.left-nav').removeClass("left-nav-hide");
	})
	//左侧导航关闭
	$('div.left-nav .btn-close').on("click",function() {
		$(this).parent().addClass("left-nav-hide");
	});
	//右侧导航开启
	$('div.page-top .menu-right').on("click",function() {
		$('div.right-nav').removeClass("right-nav-hide");
	})
	//右侧导航关闭
	$('div.right-nav .btn-close').on("click",function() {
		$(this).parent().addClass("right-nav-hide");
	});
	
	//计算页面高度分配给BOX
	var pageHeight = $(window).height(); //屏幕高度
	var pageBoxHeight = pageHeight - $('div.page-boxs')[0].offsetTop - 100; //BOX高度
	$('div.page-box-con').css("height",pageBoxHeight);
	$('div.time-main,div.allot-main').css("height",pageBoxHeight + 60);
	$('div.box-form').css("height",pageBoxHeight - 60);
	$('div.box-list').css("height",pageBoxHeight - 60 - 60);
	$('div.page-box-login').css("height",pageHeight - 140 - 140);
	
	//表格产生滚动条
	var pageBoxTableHeight = pageBoxHeight - 60 - 45 - 25;
	$('div.box-table-con').css("height",pageBoxTableHeight);
	$('div.box-table-con').mCustomScrollbar({
		theme: "minimal-dark"
	});
	
	//模块产生滚动条
	$('div.time-main,div.allot-main').mCustomScrollbar({
		axis:"x", //设置水平滚动方向
		autoDraggerLength: true, //自动调整滚动条长度
		theme: "minimal-dark",
		scrollInertia: 3000,
		advanced:{
			autoExpandHorizontalScroll: true, //设置水平滚动
			updateOnContentResize: true, //自动更新滚动条
			autoScrollOnFocus: false //禁用表单焦点
		},
		callbacks:{
			onUpdate: function() {
				//滚动条更新后回调函数
			}
		}
	});
	
	//表单产生滚动条
	$('div.box-form-scroll, div.box-list-scroll, div.box-form .box-pop').mCustomScrollbar({
		theme: "minimal-dark",
		live: true
	});
	
	//表单下拉菜单的宽度
	var formPopWidth = $('div.form-group').width();
	var formPopHeight = pageBoxHeight / 2.5;
	$('div.box-form .box-pop').css({
		'width' : formPopWidth,
		'max-height' : formPopHeight
	});
	
	//点击表单展现下拉菜单
	$('div.form-pop .form-control').on("click",function() {
		$('div.box-pop').removeClass("box-pop-show"); //取消其他下拉列表
		$(this).parent().find('.box-pop').addClass("box-pop-show");
	});
	
	//点击下拉列表赋值当前表单属性并关闭下拉菜单
	$('div.box-form .box-pop li').on("click",function() {
		$(this).parents('.form-group').find('.form-control').val($(this).text());
		$('div.box-pop').removeClass("box-pop-show"); //关闭下拉列表
	});
	
	//点击标题右上角more的下拉菜单
	$('div.page-box .more').on("click",function(e) {
		$(this).parent().find('.box-pop').addClass("box-pop-show");
		//阻止冒泡排序
		e.stopPropagation();
	});
	
	//点击任何地方关闭右上角more的下拉菜单
	$(document).on("click",function() {
		$('div.box-title .box-pop').removeClass("box-pop-show");
	});
	
	//选中下拉关闭
	$('div.box-title .box-pop li').on("click",function() {
		$('div.box-pop').removeClass("box-pop-show"); //关闭下拉列表
	});
	
	
	//项目分配-点击
	$('ul.list-hover .list-con').on("click",function() {
		$(this).parent().parent().find(".list-con").removeClass("list-con-now");
		$(this).addClass("list-con-now");
	});
	
	//项目分配-点击选中
	$('ul.list-select .list-con').on("click",function() {
		
		if( $(this).hasClass("list-con-sel") ){
			$(this).removeClass("list-con-sel");
		}else{
			$(this).addClass("list-con-sel");
		}
		
		$(this).parents(".page-box-con").find(".box-btn-save").removeClass("box-btn-down");
		$(this).parents(".page-box-con").find(".box-info").removeClass("box-info-show");
		
	});
	
	//项目分配-TAG切换
	$('ul.distribution-menu li').on("click",function() {
		var li_num = $(this).index();
		$('div.allot-ul .second, div.allot-ul .second .tag-user-02, div.allot-ul .second .tag-project-02').fadeOut();
		$('div.allot-ul .third').fadeOut();
		
		if( li_num == 0 ){
			$('div.tag-project').fadeIn();
			$('div.tag-user').fadeOut();
			$('h2.box-title-first').text("项目分配");
		}
		
		if( li_num == 1 ){
			$('div.tag-project').fadeOut();
			$('div.tag-user').fadeIn();
			$('h2.box-title-first').text("人员分配");
		}
	});
	
	//项目分配-首屏
	//第一个模块, 第二剧场产品入场
	$('div.allot-ul .first .list-pro li').on("click",function() {
		$('div.allot-ul .second').fadeIn();
		//剧场隐藏
		$('div.allot-ul .second .box-tag, div.allot-ul .third .box-tag').fadeOut();
		$('div.allot-ul .third').fadeOut();
		//入场
		$('div.allot-ul .second .tag-user-02').fadeIn();
		//按钮复位
		$("div.allot-ul .second .box-btn-save,div.allot-ul .third .box-btn-save").removeClass("box-btn-down");
		$("div.allot-ul .second .box-btn-save,div.allot-ul .third .box-btn-save").removeClass("box-info-show");
	});
	//第一个模块, 第二剧场用户入场
	$('div.allot-ul .first .list-user li').on("click",function() {
		$('div.allot-ul .second').fadeIn();
		//剧场隐藏
		$('div.allot-ul .second .box-tag, div.allot-ul .third .box-tag').fadeOut();
		$('div.allot-ul .third').fadeOut();
		//入场
		$('div.allot-ul .second .tag-project-02').fadeIn();
		//按钮复位
		$("div.allot-ul .second .box-btn-save,div.allot-ul .third .box-btn-save").removeClass("box-btn-down");
		$("div.allot-ul .second .box-btn-save,div.allot-ul .third .box-btn-save").removeClass("box-info-show");
	});
	//第二个模块, 产品按钮点击, 第三剧场用户入场
	$('div.allot-ul .second .tag-user-02 .box-btn').on("click",function() {
		$('div.allot-ul .third').fadeIn();
		//剧场隐藏
		$('div.allot-ul .third .box-tag').fadeOut();
		//入场
		$('div.allot-ul .third .tag-user-02').fadeIn();
	});
	//第二个模块, 第三剧场产品入场
	$('div.allot-ul .second .list-user li').on("click",function() {
		$('div.allot-ul .third').fadeIn();
		//剧场隐藏
		$('div.allot-ul .third .box-tag').fadeOut();
		//入场
		$('div.allot-ul .third .tag-project-02').fadeIn();
		//按钮复位
		$("div.allot-ul .second .box-btn-save,div.allot-ul .third .box-btn-save").removeClass("box-btn-down");
		$("div.allot-ul .second .box-btn-save,div.allot-ul .third .box-btn-save").removeClass("box-info-show");
	});
	//第二个模块, 第三剧场用户入场
	$('div.allot-ul .second .list-pro li').on("click",function() {
		$('div.allot-ul .third').fadeIn();
		//剧场隐藏
		$('div.allot-ul .third .box-tag').fadeOut();
		//入场
		$('div.allot-ul .third .tag-user-03').fadeIn();
		//按钮复位
		$("div.allot-ul .second .box-btn-save,div.allot-ul .third .box-btn-save").removeClass("box-btn-down");
		$("div.allot-ul .second .box-btn-save,div.allot-ul .third .box-btn-save").removeClass("box-info-show");
	});
	//第二个模块, 用户按钮点击, 第三产品2剧场入场
	$('div.allot-ul .second .tag-project-02 .box-btn').on("click",function() {
		$('div.allot-ul .third').fadeIn();
		//剧场隐藏
		$('div.allot-ul .third .box-tag').fadeOut();
		//入场
		$('div.allot-ul .third .tag-project-03').fadeIn();
	});

}

//新建工作类型
function addWorkType(){
	var deptid = $("#deptid").val(); // 部门ID
	var workType = $("#jobType").val();// 工作类型
	
	if (deptid ==""){
		alert("部门不能为空!");
		return false;
	}
	
	if (workType ==""){
		alert("工作类型不能为空!");
		return false;
	}
	$.ajax({
		url:"insertWorkType.do",
		data:{
			deptid:deptid,
			workType:workType
		},
		success:function(data){		
             if (data==1){
				alert("添加成功!");
				window.location.href="workTypeIndex.html";
			}else if (data==2){
				alert("新建的工作类型已存在!");
				return false;
			}else{
				alert("添加失败!");
				return false;
			}
			
		}
	});
}

// 删除组别
function deleteWorkType(workTypeid){
	
	if (!confirm("是否删除?")){
		return false;
	}
	
	$.ajax({
		url:"deleteWorkType.do",
		data:{
			workTypeid:workTypeid
		},
		success:function(data){
			 if (data==1){
				alert("删除成功!");
				window.location.href="workTypeIndex.html";
			}else{
				alert("删除失败!");
				return false;
			}	
		}
	});
}