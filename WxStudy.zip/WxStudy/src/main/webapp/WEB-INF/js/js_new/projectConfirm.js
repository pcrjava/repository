
// 获取当前时间并且格式化 成 YYYY-MM-DD HH:mm:ss
function getYesterDate(){
	 var date = new Date();
	    var seperator1 = "-";
	    var seperator2 = ":";
	    var month = date.getMonth() + 1;
	    var strDate = date.getDate();
	    if (month >= 1 && month <= 9) {
	        month = "0" + month;
	    }
	    if (strDate >= 0 && strDate <= 9) {
	        strDate = "0" + strDate;
	    }
	    var currentdate = date.getFullYear() + seperator1 + month + seperator1 + (strDate-1)
	            + " " + date.getHours() + seperator2 + date.getMinutes()
	            + seperator2 + date.getSeconds();
	    return currentdate;
}

//获取当前时间并且格式化 成 YYYY-MM-DD HH:mm:ss
function getCurrentDate(){
	 var date = new Date();
	    var seperator1 = "-";
	    var seperator2 = ":";
	    var month = date.getMonth() + 1;
	    var strDate = date.getDate();
	    if (month >= 1 && month <= 9) {
	        month = "0" + month;
	    }
	    if (strDate >= 0 && strDate <= 9) {
	        strDate = "0" + strDate;
	    }
	    var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate
	            + " " + date.getHours() + seperator2 + date.getMinutes()
	            + seperator2 + date.getSeconds();
	    return currentdate;
}

// 页面加载后触发
function initPage () {
		//左侧导航开启
		$('div.page-top .menu-left').on("click",function() {
			$('div.left-nav').removeClass("left-nav-hide");
		})
		//左侧导航关闭
		$('div.left-nav .btn-close').on("click",function() {
			$('div.left-nav').addClass("left-nav-hide");
		});
		//右侧导航开启
		$('div.page-top .menu-right').on("click",function() {
			$('div.right-nav').removeClass("right-nav-hide");
		})
		//右侧导航关闭
		$('div.right-nav .btn-close').on("click",function() {
			$(this).parent().addClass("right-nav-hide");
		});
		
		//计算页面高度分配给BOX
		var pageHeight = $(window).height(); //屏幕高度
		var pageBoxHeight = pageHeight - $('div.page-boxs')[0].offsetTop - 100; //BOX高度
		$('div.page-box-con').css("height",pageBoxHeight);
		$('div.time-main,div.allot-main').css("height",pageBoxHeight + 60);
		$('div.box-form').css("height",pageBoxHeight - 60);
		$('div.box-list').css("height",pageBoxHeight - 60 - 60);
		$('div.page-box-login').css("height",pageHeight - 140 - 140);
		
		//表格产生滚动条
		var pageBoxTableHeight = pageBoxHeight - 60 - 45 - 25 - 40;
		$('div.box-table-con').css("height",pageBoxTableHeight);
		$('div.box-table-con').mCustomScrollbar({
			theme: "minimal-dark"
		});
		
		//模块产生滚动条
		$('div.time-main,div.allot-main').mCustomScrollbar({
			axis:"x", //设置水平滚动方向
			autoDraggerLength: true, //自动调整滚动条长度
			theme: "minimal-dark",
			scrollInertia: 3000,
			advanced:{
				autoExpandHorizontalScroll: true, //设置水平滚动
				updateOnContentResize: true, //自动更新滚动条
				autoScrollOnFocus: false //禁用表单焦点
			},
			callbacks:{
				onUpdate: function() {
					//滚动条更新后回调函数
				}
			}
		});
		
		//表单产生滚动条
		$('div.box-form-scroll, div.box-list-scroll, div.box-form .box-pop').mCustomScrollbar({
			theme: "minimal-dark",
			live: true
		});
		
		//表格限制
		$('.t-more-add').hide();
		$(".table tr td.box-table-more-con").each(function(i){
		        if( $(this).text().length > 40 ){
		        	//console.log($(this).text().length);
		        	$(this).find('.t-more').hide();
		        	$(this).find('.t-more-add').show();
		        }
		});
		$('.t-more-add').on("click",function(){
			if($(this).text() == "显示全部"){
				$(this).parent().find('.t-more').show();
				$(this).text('隐藏');
			}else{
				$(this).parent().find('.t-more').hide();
				$(this).text('显示全部');
			}
				
		});
		
		if(document.getElementById('table').rows.length>0){
			$('#table1').css('display','block');
		}
		
		fomatDate();	
}

// 初始化时间控件
  function fomatDate(){
	  var yesterDay=getYesterDate().substring(0,10);
		var currentDay=getCurrentDate().substring(0,10);
		
		$(".begin-time").val(yesterDay);
		$(".end-time").val(currentDay);
		
		$(".begin-time").datetimepicker({
			language: 'zh-CN',
			format: 'yyyy-mm-dd',
			showMeridian: true,
			minView: 2,
			autoclose: true
			}).on('changeDate', function() {
				$('.end-time').datetimepicker('remove');
				//结束时间
				$('.end-time').datetimepicker({
					startDate:$("#begintime").val(),
					language: 'zh-CN',
					format: 'yyyy-mm-dd',
					minView: 2,
					showMeridian: true,
					autoclose: true
				});
			});
  }
  
  // 条件查询事件
 $('#status, #projectNm,.end-time').on('change',function(){
	 generalWorkList();
  }); 
 
 // 确认/不确认 事件
  function editWork(id,a,e){
	  var id;
	  var reason;	
	if (typeof(e)==="object"){
	 id =$(e.parentNode).parent().find("td").eq(0).text();
	 reason =$(e.parentNode).parent().find("td").eq(10).find("textarea").val();
	}
	$.ajax({
		type:"post",
		url:"editProjectConfirm.do",
		data:{
			id:id,
			status:a,
			reason:reason
		},
		success:function(data){
			if(data==1){
				alert("确认成功!")
				generalWorkList();
			}
		}
	});
  }
  
  //ajax画表格
  function generalWorkList(){
	  
	  $.ajax({
		  url:"projectConfirmByConditions.do",
		  type:"post",
		  data:{
			begintime:$('#begintime').val(),
			endtime:$('#endtime').val(),
			status:$('#status').find('option:selected').val(),
			projectName:$('#projectNm').find('option:selected').val()
		  },
		  success:function(data){
			  var a="";
			  $(".table tbody").empty();
			  for(var i =0;i<data.length;i++){
				  
				  var b="this";
				  
				  a+="<tr><td style='display:none'>" + data[i].id +"</td>"+
				  	"<td width='4%' style='text-align:center'>"+(i+1)+"</td>"+
				  "<td width=''>"+(data[i].projectName==null?'':data[i].projectName)+"</td>"+
				   "<td width='5%'>"+(data[i].worktype==null?'':data[i].worktype)+"</td>"+
			        "<td width='10%'>"+(data[i].begintime==null?'':data[i].begintime)+"</td>"+
			        "<td width='10%'>"+(data[i].endtime==null?'':data[i].endtime)+"</td>"+
			        "<td width='5%'>"+(data[i].wh==null?'':data[i].wh)+"</td>"+
			        "<td width='20%' class='box-table-more-con'>  <span class='t-more'>"+(data[i].workcontent==null?'':data[i].workcontent)+
			        "</span><a href='#' class='t-more-add'>显示全部</a></td>" +
			        "<td width='5%'>"+(data[i].status==null?'':data[i].status)+"</td>"+
			        "<td width='5%'>"+(data[i].name==null?'':data[i].name)+"</td>"+
			        "<td width='10%'><textarea maxlength='50' style='height:20px;max-width: 60px;'>"+(data[i].reason==null?'':data[i].reason)+"</textarea></td>"+
			        "<td width='10%'><input type='checkbox'><div class='box-table-yes' title='确认' onclick=\"editWork('"+data[i].id+"','已确认',"+b+")\"></div>"+
			        "<div class='box-table-no' title='不确认' onclick=\"editWork('"+data[i].id+"','不确认',"+b+");\"></div></td></tr>";
			  }
			  $(".table tbody").append(a);
	         
			  $('.t-more-add').hide();
				$(".table tr td.box-table-more-con").each(function(i){
				        if( $(this).text().length > 40 ){
				        	//console.log($(this).text().length);
				        	$(this).find('.t-more').hide();
				        	$(this).find('.t-more-add').show();
				        }
				});
				$('.t-more-add').on("click",function(){
					if($(this).text() == "显示全部"){
						$(this).parent().find('.t-more').show();
						$(this).text('隐藏');
					}else{
						$(this).parent().find('.t-more').hide();
						$(this).text('显示全部');
					}	
				});
				
				if(document.getElementById('table').rows.length>0){
					$('#table1').css('display','block');
				}
				
		  }  
	  }); 
  }
  
  // 全选/反选
  function multiplicitySelect(){
	 
	  var checked = $('#multiplicitySelect').is(":checked");
		  $('.table tbody tr').each(function(){
			  $(this).find('input[type=checkbox]').prop('checked',checked);
			  
		  });
  }
  
  // 批量确认/不确认 事件
  function editAllWork(status){
	  var a="[";
	  $('.table tbody tr').each(function(){
		  if ($(this).find('input[type=checkbox]').is(":checked")){
			  a=a+"{'id':'"+$(this).find('td').eq(0).text()+
	               "','status':'"+status+
	               "','reason':'"+$(this).find("td").eq(10).find("textarea").val()+
				    "'},";
		  }
	  });
	  
	  if (a=='['){
		  a="";
		  alert("请先选择!");
		  return 
	  }else{
		  a=a.substring(0,a.length-1)+"]";
	  }

	  $.ajax({
		  url:"editAllWork.do",
		  type:"post",
		  data:{
			  a:a
		  },
		  success:function(data){
			  alert("确认成功!")
			   $('#multiplicitySelect').prop('checked',false);
			  generalWorkList();
		  }  
	  });
	  
	  
  }
  