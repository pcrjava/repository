 $('#subProject,#checkusers').addClass("checkuser");
 
 // 获取当前时间
 var currentDate=getCurrentDate(new Date()).substring(0,10);
 
// 获取前一天日期
NextNow = addDate(new Date(),-1);

var NexNow = getCurrentDate(new Date(NextNow)).substring(0,10);

//获取当前时间并且格式化 成 YYYY-MM-DD HH:mm:ss
function getCurrentDate(date){
	 //var date = new Date();
	    var seperator1 = "-";
	    var seperator2 = ":";
	    var month = date.getMonth() + 1;
	    var strDate = date.getDate();
	    if (month >= 1 && month <= 9) {
	        month = "0" + month;
	    }
	    if (strDate >= 0 && strDate <= 9) {
	        strDate = "0" + strDate;
	    }
	    var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate
	            + " " + date.getHours() + seperator2 + date.getMinutes()
	            + seperator2 + date.getSeconds();
	    return currentdate;
}

$("#reset1").on('click',function(){
	$("#subProjectList").empty();
	$("#ckelist input[type='checkbox']").prop('checked',false);
	$('#beginTime,#endTime').val(getCurrentDate(new Date(NextNow)).substring(0,10));
	
});

$("#beginTime,#endTime").val(NexNow);

//开始时间
	$('.begin-time').datetimepicker({
		minView: "month", //选择日期后，不会再跳转去选择时分秒 
		language: 'zh-CN',
		format: 'yyyy-mm-dd',
		todayBtn: 0,
		autoclose: 1,
		endDate: NextNow,
	}).on('changeDate', function() {
		
		begintime = $('.begin-time').val();
		
		//结束时间
		$('.end-time').datetimepicker({
			minView: "month", //选择日期后，不会再跳转去选择时分秒 
			//startDate:begintime,
			language: 'zh-CN',
			format: 'yyyy-mm-dd',
			todayBtn: 0,
			autoclose: 1,
			endDate: NextNow,
		});
	});
	
	function addDate(dd,dadd){
		var a = new Date(dd)
		a = a.valueOf()
		a = a + dadd * 24 * 60 * 60 * 1000
		a = new Date(a)
		return a;
		}

//设置子项目显示/隐藏
function checkProject (){

	//控制选择用户DIV显示隐藏
	if( $('#subProject').hasClass("showcheckuser") ){
		$('#subProject').removeClass("showcheckuser");
		$('#subProject').addClass('checkuser');
		$('#selectSubProject').attr("value","点击显示");

	}else{
     
		$('#subProject').addClass("showcheckuser");
		$('#subProject').removeClass('checkuser');
		
		$('#selectSubProject').attr("value","点击隐藏");
	}
		
}  


function selectAllsubProject() { 
    if ($('#selectAll1').prop("checked")) {
        $("input[name='subProject']").prop("checked", true);
    } else {  
        $("input[name='subProject']").prop("checked", false);  
    }
} 


//设置主项目显示/隐藏
function checkusers (){
	//$('checkusers').removeClass('checkuser');
	
	//控制选择用户DIV显示隐藏
	if( $('#checkusers').hasClass("showcheckuser") ){
		$('#checkusers').removeClass("showcheckuser");
		$('#checkusers').addClass('checkuser');
		$('#selectuser').attr("value","点击显示");
		
	}else{
		
		var ckelist = document.getElementsByName('checkuser');

		for(var i=0;i<ckelist.length;i++){
			ckelist[i].addEventListener('click',function(){
			  
				 var list = $("#ckelist input[type='checkbox']:checked");
				 if(list.length>1){
					 var projectname="";
					 for(var m=0;m<list.length;m++){
						 if (list[m].value!=""){
						  projectname+=list[m].value+","
						 }
					 }
					 projectname=projectname.substr(0,projectname.length-1);
					 
					 ajaxOrder.duplicateExport(projectname);
					 
				 }else{
					 projectname=$('#ckelist input[type=checkbox]:checked').val();
					 
					 ajaxOrder.signleExport(projectname);
				 }
			 
			});
		}

		$('#checkusers').addClass("showcheckuser");
		$('#checkusers').removeClass('checkuser');
		
		$('#selectuser').attr("value","点击隐藏");
	}
		
}  

var ajaxOrder={
	signleExport: function(projectname){
		$.ajax({

			type:"POST",
			url:"selectSubProjectNew.do",
			data:{
				projectname:projectname
			},
			success:function(data){
				$('#subProjectList').empty();
				
				if (data!=""){
					var b="<li>"+
					"<input type='checkbox' value='all1' id='selectAll1' onclick='selectAllsubProject();'>全选"+										 	  
					"</li>";
				}else{
					var b="";
				}
				
				for(var i=0;i<data.length;i++){		
					b+="<li><input type='checkbox' value='"+data[i].id+" 'name='subProject'>"+data[i].subprojectname+"</li>";	
				}
				$('#subProjectList').append(b);
		
			}

		});
	},
	duplicateExport:function(projectname){
		 $.ajax({
				type:"POST",
				url:"selectSubProjectNew.do",
				data:{
					projectname:projectname
				},
				success:function(data){
					$('#subProjectList').empty();
					var b="<li>"+
					"<input type='checkbox' value='all1' id='selectAll1' onclick='selectAllsubProject();' disabled='disabled'>全选"+										 	  
					"</li>";
					for(var i=0;i<data.length;i++){
						b+="<li><input type='checkbox' value='"+data[i].id+"' id='"+data[i].id+" 'name='subProject' checked='checked' disabled='disabled'>"+data[i].subprojectname+"</li>";					
					}
					$('#subProjectList').append(b);
					
				}

			});
	}
};

function selectAllusers() { 
    if ($('#selectAll').prop("checked")) {
        $("input[name='checkuser']").prop("checked", true);
    } else {  
        $("input[name='checkuser']").prop("checked", false); 
    	$('#subProjectList').empty();
    }
}  

$('#export').on('click',function(){
	var a="";
	 $("input[name='subProject']:checked").each(function(){
		 a+=$(this).val()+",";	 
	 });
	 var subProjectId = a.substr(0,a.length-1);
	 
	 var count=$("#ckelist input[type='checkbox']:checked").length

	 switch (count)
	 {
	 case 0: 
		 alert("请选择项目!");
		 return
	 case 1:
		 var num=$("#subProjectList input[type='checkbox']:checked").length;
		 if (num==0){
			 alert("请选择子项目!");
			 return
		 }
	 }
	var beginTime = new Date($('#beginTime').val());
	var endTime = new Date($('#endTime').val());
	
	 if (beginTime.getTime()>endTime.getTime()){
		 alert("结束日期必须大于等于开始日期!");
		 return 
	 }

	 $("input[name=subProjectIdTem]").val(subProjectId);
	
		
	document.getElementById("from1").action="NewExport.do";
	document.getElementById("from1").method="POST";
	  document.getElementById("from1").submit();
	
});
