/**login**/
/** cheakIn 登录名只能以字母开头 .在中间 以字母结尾* */
function login(uri) {
	// 获取用户输入的登录名
	var loginname = $("#loginname").val();
	// 获取用户输入的密码
	var pwd = $("#pwd").val().trim();
	// 验证登录名是否合法
	var standard = /^([A-Za-z]*\.[A-Za-z]*)$/;
	// 先验证登录名是否是空值
	if (loginname == "" || null == loginname) {
		$("#ceshi1").addClass("box-info-show");
		setTimeout(function() {
			$("#ceshi1").removeClass("box-info-show");
		}, 1500);
		return false;
	}
	// 再校验登录名称是否合法
	if (standard.test(loginname)) {
	} else {
		$("#ceshi").addClass("box-info-show");

		setTimeout(function() {
			$("#ceshi").removeClass("box-info-show");
		}, 1500);
		return false;
	}
	// 再判断密码是否为空
	if (pwd == "" || null == pwd) {
		$("#ceshi2").addClass("box-info-show");
		setTimeout(function() {
			$("#ceshi2").removeClass("box-info-show");
		}, 1500);
		return false;
	}
	$.ajax({
		type : "POST",
		url : uri + 'tbUsers/login.do?loginname=' + loginname + '&pwd=' + pwd,
		async : false,
		success : function(data) {
			// alert(data);
			if (data == "0") {
				// 成功后跳转至首页
				window.location.href = uri + "workingHours.html?";
			} else if(data == "2"){
				// 登录失败 提示登录名或密码不正确
				$("#ceshi4").addClass("box-info-show");
				setTimeout(function() {
					$("#ceshi4").removeClass("box-info-show");
				}, 15000);
			} else {
				// 登录失败 提示登录名或密码不正确
				$("#ceshi3").addClass("box-info-show");
				setTimeout(function() {
					$("#ceshi3").removeClass("box-info-show");
				}, 1500);
				// location.reload();
			}
		}
	});
}
/**回车监听事件**/
function keydownEvent(uri) {
	var e = window.event || arguments.callee.caller.arguments[0];
	if (e && e.keyCode == 13) {
		login(uri);
	}

}

/** 退出登录* */
function quit(uri) {
	if (!confirm("是否确认退出？")) {
		return false;
	}
	window.location.href = uri + "tbUsers/quit.html?";

}

/**发起修改密码请求**/
function updpwd(uri) {
	window.location.href = uri + "tbUsers/updpwd.html?";
}

/**确认修改密码**/
function confirmUpdPwd (uri){
	//获取当前密码
	var CurrentPassword = $("#CurrentPassword").val().trim();
	//获取新密码
	var NewPassword = $("#NewPassword").val().trim();
	//获取确认密码
	var NewPasswordConfirm = $("#NewPasswordConfirm").val().trim();
	//
	//alert(NewPassword.length);
	if ("" == CurrentPassword || null == CurrentPassword) {
		alert("当前密码不能为空!");
		return false;
	}
	if ("" == NewPassword || null == NewPassword) {
		alert("新密码不能为空!");
		return false;
	}
	if (NewPassword.length > 20 || NewPassword.length < 8) {
		alert("新密码长度需8~20个字符!");
		return false;
	}
	if ("" == NewPasswordConfirm || null == NewPasswordConfirm) {
		alert("确认密码不能为空!");
		return false;
	}
	if (NewPassword != NewPasswordConfirm) {
		alert("新密码和确认密码不相符!");
		return false;
	}
	//确认限制条件通过可以进行密码修改
	$.ajax({
		type : "POST",
		url : uri + 'tbUsers/confirmUpdPwd.html?CurrentPassword=' + CurrentPassword + '&NewPasswordConfirm=' + NewPasswordConfirm,
		async : false,
		success : function(data) {
			 //alert(data);
			if (data == "Error") {
				alert("当前密码不正确，请重新修改!");
				location.reload();
			} else {
				alert("密码修改成功，请重新登录!");
				//document.location = 'http://www.bleach.cn:8080/workinghours/index.html';
				window.location.href= uri + "tbUsers/updpwd.html?";
			}
		}
	});
}