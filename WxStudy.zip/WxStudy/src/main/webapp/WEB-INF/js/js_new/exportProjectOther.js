//设置选择用户
function checkusers (){
	//$('checkusers').removeClass('checkuser');
	
	//控制选择用户DIV显示隐藏
	if( $('#checkusers').hasClass("showcheckuser") ){
		$('#checkusers').removeClass("showcheckuser");
		$('#checkusers').addClass('checkuser');
		$('#selectuser').attr("value","点击显示");
		document.getElementById('checkusers').style.display="none";
	}else{
		 
		$('#checkusers').addClass("showcheckuser");
		$('#checkusers').removeClass('checkuser');
		document.getElementById('checkusers').style.display="block";
		$('#selectuser').attr("value","点击隐藏");
	}
}  

function selectAllusers() { 
    if ($('#selectAll').prop("checked")) {
        $("input[name='checkuser']").prop("checked", true);
    } else {  
        $("input[name='checkuser']").prop("checked", false);  
    }
}  

$(function(){
	
	// 获取当前时间
	  var currentDate=getCurrentDate().substring(0,10);
	  
	// 获取前一天日期
	NextNow = addDate(new Date(),-1);
	
	var currentYear = new Date().getFullYear();
	var currentMonth =new Date().getMonth()+1;
	var preDay =new Date().getDate()-1;
	
	if (currentMonth<10){
		currentMonth="0"+currentMonth;
	}
	
	if (preDay<10){
		preDay="0"+preDay;
	}
	
	if ($("#beginTime1").val()!="" && $("#endTime1").val()!=""){
		$('.begin-time').attr("value",$("#beginTime1").val());
		$('.end-time').attr("value",$("#endTime1").val());
	}else{
		$('.begin-time,.end-time').attr("value",currentYear+'-'+currentMonth+'-'+preDay);
	}
	//开始时间
	$('.begin-time').datetimepicker({
		minView: "month", //选择日期后，不会再跳转去选择时分秒 
		language: 'zh-CN',
		format: 'yyyy-mm-dd',
		todayBtn: 1,
		autoclose: 1,
		endDate: NextNow,
	}).on('changeDate', function() {
		
		begintime = $('.begin-time').val();
		
		//结束时间
		$('.end-time').datetimepicker({
			minView: "month", //选择日期后，不会再跳转去选择时分秒 
			language: 'zh-CN',
			format: 'yyyy-mm-dd',
			todayBtn: 1,
			autoclose: 1,
			endDate: NextNow,
		});
	});
	 
});

//获取当前时间并且格式化 成 YYYY-MM-DD HH:mm:ss
function getCurrentDate(){
	 var date = new Date();
	    var seperator1 = "-";
	    var seperator2 = ":";
	    var month = date.getMonth() + 1;
	    var strDate = date.getDate();
	    if (month >= 1 && month <= 9) {
	        month = "0" + month;
	    }
	    if (strDate >= 0 && strDate <= 9) {
	        strDate = "0" + strDate;
	    }
	    var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate
	            + " " + date.getHours() + seperator2 + date.getMinutes()
	            + seperator2 + date.getSeconds();
	    return currentdate;
}

function addDate(dd,dadd){
	var a = new Date(dd)
	a = a.valueOf()
	a = a + dadd * 24 * 60 * 60 * 1000
	a = new Date(a)
	return a;
	}

//重置
$("#reset").on('click',function(e){
	e.preventDefault();
	document.getElementById("projectNm")[0].selected=true
	
	var currentYear = new Date().getFullYear();
	var currentMonth =new Date().getMonth()+1;
	var preDay =new Date().getDate()-1;
	
	if (currentMonth<10){
		currentMonth="0"+currentMonth;
	}
	
	if (preDay<10){
		preDay="0"+preDay;
	}
	
	document.getElementById("beginTime").value=currentYear+'-'+currentMonth+'-'+preDay;
	document.getElementById("endTime").value=currentYear+'-'+currentMonth+'-'+preDay;
	$("checkusers").find("input[type=checkbox]").prop("checked", false);  
});

//导出
$("#export").on("click",function(e){
	
	if ($("#projectName").val()==''){
		alert("项目ID为空!");
		e.preventDefault();
		return false;
	}

	//记录项目的text
	$("#projectName").attr("value",$('#projectNm option:selected').text());

	var arrChk=$("input[name='checkuser']:checked"); 
	var selectuserid = "";
	 $(arrChk).each(function(){  
		  
		 selectuserid += this.value+",";             
	  
	 }); 
	
	 if ($.isEmptyObject(selectuserid)){
		 alert("请先选择人员再导出!");
		 return 
	 }
	 $("#ckeusers").attr("value",selectuserid.substring(0,selectuserid.length-1));
	 $('#checkusers').removeClass("showcheckuser");
	 $('#checkusers').addClass('checkuser');
	
	window.location.href="ExportProjectOtherNew.do?projectid="+$("#projectNm").val()+"&userid="+$("#userName").val()+
		"&beginTime="+$("#beginTime").val()+"&endTime="+$("#endTime").val()+"&ckeusers="+$("#ckeusers").val();

});