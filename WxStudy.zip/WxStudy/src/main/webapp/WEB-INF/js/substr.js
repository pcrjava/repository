function alinsubstr(selector,n) {
     $(selector).each(function () {
            var $it = $(this);
            var content=$.trim($it.text());
            var newc;
            if(content.length>n){
            	newc =content.substr(0,n)+"...";
            }
            $it.text(newc);
        });
}
function alinsubstr2(selector,n) {
     $(selector).each(function () {
            var $it = $(this);
            var content=$.trim($it.text());
            var newc;
            if(content.length>n){
            	newc =content.substr(0,n);
            }
            $it.text(newc);
        });
}