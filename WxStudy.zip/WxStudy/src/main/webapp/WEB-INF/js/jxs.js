var myprovince = "";
var mycity = "";
var mydistrict = "";
try {
	myprovince = remote_ip_info['province'];
	mycity = remote_ip_info['city'];
	mydistrict = remote_ip_info['district'];
} catch (e) {
	myprovince = "";
	mycity = "";
	mydistrict = "";
}
function showShi(obj){
	var subMenu2 = "<option value='0'>请选择市</option>";
	$.post("selectCityByProvince.html?",{province:obj},
			function (data){
				var city = eval(data);
				for(var i = 0;i<city.length;i++){
					if(city[i].replace("市" , "") == mycity){
						subMenu2 = subMenu2 + ("<option selected='selected'>"+city[i]+"</option>");
					}else{
						subMenu2 = subMenu2 + ("<option>"+city[i]+"</option>");
					}
				}  
				$("#shi").html(subMenu2);
				var subMenu3 = "<option value='0'>请选择经销商</option>";
				$("#jxsdm").html(subMenu3);
			});
}

//function showJxs(obj){
//	obj = obj.replace("市" , "");
//	var subMenu3 = "<option value='0'>请选择经销商</option>";
//	$.post("selectJxsByCity.html?",{city:obj+'市'},
//			function (data){
//				var Jxs = eval(data);
//				for(var i = 0;i<Jxs.length;i++){
//					subMenu3 = subMenu3 + ("<option value='"+Jxs[i].servicecode+","+Jxs[i].itemid+"'>"+Jxs[i].name+"</option>");
//				}  
//				$("#jxsdm").html(subMenu3);
//			});
//}

function qk(){
	$("#ZXTS_TS_SLF").val("0");
	$("#mess").html("");
}

$(function(){
	var subMenu = "<option value='0'>请选择省</option>";   
	$.post("selectProvince.html?",{name:myprovince},
			function (data){
				var province = eval(data);
				for(var i = 0;i<province.length;i++){
					if(myprovince == province[i]){
						subMenu = subMenu + ("<option selected='selected'>"+province[i]+"</option>");
					}else{
						subMenu = subMenu + ("<option>"+province[i]+"</option>");
					}
				}
				$("#sheng").html(subMenu);
				
				
				var subMenu2 = "<option value='0'>请选择市</option>";
				$.post("selectCityByProvince.html?",{province:myprovince},
						function (data){
							var city = eval(data);
							for(var i = 0;i<city.length;i++){
								if(city[i].replace("市" , "") == mycity){
									subMenu2 = subMenu2 + ("<option selected='selected'>"+city[i]+"</option>");
								}else{
									subMenu2 = subMenu2 + ("<option>"+city[i]+"</option>");
								}
							}  
							$("#shi").html(subMenu2);
							//var subMenu3 = "<option value='0'>请选择经销商</option>";
							//$("#jxsdm").html(subMenu3);
							
							
							//mycity = mycity.replace("市" , "");
							//var subMenu3 = "<option value='0'>请选择经销商</option>";
							//$.post("selectJxsByCity.html?",{city:mycity+'市'},
							//		function (data){
							//			var Jxs = eval(data);
							//			for(var i = 0;i<Jxs.length;i++){
							//				subMenu3 = subMenu3 + ("<option value='"+Jxs[i].servicecode+","+Jxs[i].itemid+"'>"+Jxs[i].name+"</option>");
							//			}  
							//			$("#jxsdm").html(subMenu3);
							//		});
							
							
							
				});
				
				
			});
});